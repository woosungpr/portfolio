package com.coupang.WEPAPP007.woosung;

import static org.junit.Assert.*;

import org.junit.Test;

public class kwList {

	@Test
	public void testMain() {
		kwSaleList kslst = new kwSaleList();
		kslst.main("레깅스");
		
	}

}
