package com.coupang.WEPAPP007.woosung;

import java.io.IOException;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import java.net.URLEncoder;
import java.util.Arrays;
import java.text.DecimalFormat;

public class kwSaleList{

	Product[] productArry = new Product[33];
	int idxPrd = 0;
	
	public void main(String keyword){

		String kwrd    = URLEncoder.encode(keyword);
		
		String url     = "http://www.coupang.com/search.pang?q=" + kwrd ; //쿠팡
		
	    String prdNameTag  = "strong.title em"; //제품명 관련 tag
	    String prdPriceTag = "em.prod-price span.price-detail strong em"; //제품가격 관련 tag
	    String prdCountTag = "span.condition em"; //판매 수량 관련 tag

		setSaleProduct("쿠팡",kwrd,url,prdNameTag,prdPriceTag,prdCountTag);
		
	    //티켓 몬스터
        url     = "http://www.ticketmonster.co.kr/search/?keyword_view="+kwrd+"&keyword="+kwrd+"&uis=b3dacb91&sarea=g&st=0";

	    prdNameTag  = "div.detail a"; //제품명 관련 tag
	    prdPriceTag = "div.detail div.amounts div.price p em"; //제품가격 관련 tag
	    prdCountTag = "div.detail span em"; //판매 수량 관련 tag
	    
        setSaleProduct("티몬",kwrd,url,prdNameTag,prdPriceTag,prdCountTag);
        
        Arrays.sort(productArry);
        
		for(Product prduct: productArry){
		   DecimalFormat Commas = new DecimalFormat("#,###");
		   String prd_cnt = (String)Commas.format(prduct.getQuantity());	
		   System.out.println(prduct.Company + "|" + prduct.getProductName() +	"|" + prduct.getProductPrice() +	"|" + prd_cnt);
		}
		
	 }	
		
	 void setSaleProduct(String compName, String kwrd,String url,String prdNameTag,String prdPriceTag,String prdCountTag){

		 	//System.out.println("url = " + url);
		 
			try {

			      Document doc = Jsoup.connect(url).get(); //웹에서 내용 가져오기
			      Elements prdName = doc.select(prdNameTag); //제품명
			      Elements prdPrice = doc.select(prdPriceTag); //제품가격
			      Elements prdCount   = doc.select(prdCountTag); //판매 수량
			      
			      int idx = 0;
			      for (Element row : prdName) {
			    	  //System.out.println(idx  + " productNm = " + prdName.get(idx).text());
			    	  //System.out.println(idx  + " prdPrice = " + prdPrice.get(idx).text());
			    	  //System.out.println(idx  + " prdCount = " + prdCount.get(idx).text());
			    	  String strCnt = prdCount.get(idx).text();
			    	  strCnt = strCnt.replaceAll(",", "");
			    	  productArry[idxPrd] = new Product(compName,prdName.get(idx).text(),prdPrice.get(idx).text(),Integer.parseInt(strCnt));
			    	  idx++;
			    	  idxPrd++;
			      }

			      
			} catch (IOException e) { //  
			      e.printStackTrace();
			}
		 
	 }
	 
	
	 public class Product implements Comparable<Product>{
		 
		    private String Company;
			private String ProductName;
			private String ProductPrice;
			private int quantity;
		 
			public Product(String company, String ProductName, String ProductPrice, int quantity) {
				super();
				this.Company    = company;
				this.ProductName = ProductName;
				this.ProductPrice = ProductPrice;
				this.quantity = quantity;
			}
		 
			
			public String getCompany() {
				return Company;
			}
			public void setCompany(String company) {
				this.Company = company;
			}

			public String getProductName() {
				return ProductName;
			}
			public void setProductName(String ProductName) {
				this.ProductName = ProductName;
			}
			public String getProductPrice() {
				return ProductPrice;
			}
			public void setProductPrice(String ProductPrice) {
				this.ProductPrice = ProductPrice;
			}
			public int getQuantity() {
				return quantity;
			}
			public void setQuantity(int quantity) {
				this.quantity = quantity;
			}

			public int compareTo(Product compareProduct) {
				int compareQuantity = ((Product) compareProduct).getQuantity(); 
		 
				//ascending order
				//return this.quantity - compareQuantity;
		 
				//descending order
				return compareQuantity - this.quantity;
			}	
			
		}
	 
	 
	    

}
