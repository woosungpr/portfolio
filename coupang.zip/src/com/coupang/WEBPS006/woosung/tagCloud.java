package com.coupang.WEBPS006.woosung;

import java.util.Arrays;
import java.util.Random;
import java.util.Scanner;
import java.util.InputMismatchException;

public class tagCloud {

	
	TagWord[] tagwordArry = null;
	
	public void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.print("�±��� ������ �Է� �Ͻÿ�: ");
		int cnt = 0;
		try { // 1.0 ���� �Ǽ��� �߸� �Է��� ��� ���� ó��
			cnt = sc.nextInt();
			
			 
	    } catch (InputMismatchException ime) {
	        System.err.println("����! ������ �ƴ� �Ǽ�/���ڸ� �Է��ϼ̱���: " + ime);
	        System.exit(1);
	    }
		
		//System.out.print("�±��� ���� cnt: " + cnt);
		
		setTagWord(cnt);
	}
	
	public void setTagWord(int count) {

		Random random = new Random();

		tagwordArry = new TagWord[count];
		
	    for (int i = 0; i < count; i++) {
		  for (int k = random.nextInt(10000000); k > 0; k--) {
			  int size = k / 1000;
			  tagwordArry[i] = new TagWord("�±�"+i, size , k);
			  break;
          }
	    }  
		
	    
        Arrays.sort(tagwordArry);
        System.out.println("");
		for(TagWord tagword: tagwordArry){
		   System.out.println("tagName: " + tagword.getTagName() +  "|" + "tagSize: " + tagword.getTagSize() + "|" + "tagCount: " + tagword.getTagCount() );
		}

	    
	}
	
	 public class TagWord implements Comparable<TagWord>{
		 
		    private String tagName;
			private int tagSize;
			private int tagCount;
		 
			public TagWord(String tagname, int tagsize, int tagcount) {
				super();
				this.tagName  = tagname;
				this.tagSize  = tagsize;
				this.tagCount = tagcount;
			}
		 

			public String getTagName() {
				return tagName;
			}


			public void setTagName(String tagName) {
				this.tagName = tagName;
			}


			public int getTagSize() {
				return tagSize;
			}


			public void setTagSize(int tagSize) {
				this.tagSize = tagSize;
			}


			public int getTagCount() {
				return tagCount;
			}


			public void setTagCount(int tagCount) {
				this.tagCount = tagCount;
			}


			public int compareTo(TagWord compareTagWord) {
				int compareSize = ((TagWord) compareTagWord).getTagSize(); 
		 
				//ascending order
				//return this.quantity - compareQuantity;
		 
				//descending order
				return compareSize - this.tagSize;
			}	
			
		}

}
