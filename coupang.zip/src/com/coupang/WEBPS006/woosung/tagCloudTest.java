package com.coupang.WEBPS006.woosung;

import static org.junit.Assert.*;

import org.junit.Test;

public class tagCloudTest {

	@Test
	public void testMain() {
		//tagCloud tagcloud = new tagCloud();
		//tagcloud.main(null);
		tagCloud2 tagcloud = new tagCloud2();
		tagcloud.main(null);

	}

}
