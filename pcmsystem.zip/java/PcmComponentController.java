package com.peru.minero;

import java.io.IOException;
import java.sql.Array;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.MessageSource;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.peru.minero.service.CommonService;
import com.peru.minero.service.PcmActivityService;
import com.peru.minero.service.PcmComponentService;
import com.peru.minero.utils.Utilities;
import com.peru.minero.vo.PcmComponentVO;
import com.peru.minero.vo.ValidateResultVO;

import oracle.jdbc.OracleTypes;



/**
 * @author yang woosung
 * 
 * * Creation date : 2024. 04. 11 ~
 * * screen ID : DE-221_UI-0204 
 * * programe ID : DE-231_PG-0000-001-06
				DE-231_PG-0000-001-32
				DE-231_PG-0204-001-33
				DE-231_PG-0204-004-34
				DE-231_PG-0204-005-35

 * 
 * PCM COMPONENTES DEL PLAN DE CIERRE (폐광 계획 구성 요소/Mine closure planning components) Controller 
 */


@Controller
public class PcmComponentController {
	
	private static final Logger logger = LoggerFactory.getLogger(PcmComponentController.class);
	
	@Value("${constants.idProcedimiento}")
	private String idProcedimiento;

	@Autowired
	private PcmComponentService pcmComponentService;

	@Autowired
	private PcmActivityService pcmActivityService;
	
	@Autowired
	private MessageSource messageSource;

	@Autowired
	private CommonService commonService;
	
	@Value("${db.schemas.npcm.w.name}")
	private String schemasName;
	@Value("${constants.idFuente}")
	private String idFuente;
	@Value("${idMenu.componente}")
	private String menuId;
	@Value("${file.componente.fileAnexo}")
	private String fileAnexo;
	
	//-----------------------------------------------
	/**
	* Method for Initializing the Screen
	* @param model
	* @param idClient
	* @param USUARIO_LOGIN
	* @param idEstudio
	* @param codigoExpediente
	* @param idMenu
	* @param mineraNombre
	* @return (String) "pcm/pcmComponent"
	*/
	@RequestMapping(value = "/pcmComponent", method = RequestMethod.GET)
	public String pcmComponent(Model model,
							@RequestParam("idClient")String idClient,
							@RequestParam("USUARIO_LOGIN")String userIdAndRuc,
							@RequestParam("idEstudio")String idEstudio,
							@RequestParam("codigoExpediente")String codigoExpediente,
							@RequestParam("idMenu") String idMenu,
							@RequestParam("mineraNombre")String mineraNombre) {
		logger.info("The Cotroller is {}.", "pcmComponent");
		
		model.addAttribute("Ln_IdProcedimiento", Integer.parseInt(idProcedimiento));
		model.addAttribute("Li_IdProcedimiento", Integer.parseInt(idProcedimiento));
		model.addAttribute("Ln_TipoEstudio", 7);
		model.addAttribute("idCategoria", 7);
		model.addAttribute("idTipoEvaluacion", 2);
		model.addAttribute("idClient", idClient);
		model.addAttribute("userIdAndRuc", userIdAndRuc);
		model.addAttribute("idEstudio", idEstudio);
		model.addAttribute("codigoExpediente", codigoExpediente);
		model.addAttribute("idMenu", idMenu);
		model.addAttribute("mineraNombre", mineraNombre);
		
		// getting validation information
		Map<String, Object> pamrams = new HashMap<String, Object>();
		pamrams.put("idEstudio", idEstudio);
		pamrams.put("idMenu", idMenu);
		pamrams.put("idFuente", idFuente);

		model.addAttribute("validationInfo", commonService.getValidationInfo(pamrams));
				
		
		return "pcm/pcmComponent";
	}
	
	//-----------------------------------------------
	/**
	* Method for Returning Component List Data of PCM
	* @param model
	* @param idEstudio
	* @param idComponente
	* @return (List<PcmComponentVO>) pcmComponentVOList
	*/
	@RequestMapping(value = "/getPcmComponentList", method = RequestMethod.POST)
	@ResponseBody
	public List<PcmComponentVO> getPcmComponentList(Model model,
			@RequestParam("idEstudio") int idEstudio,
			@RequestParam(value  = "idComponente", required = false) Integer idComponente) {

	    Map<String, Object> params = new HashMap<>();
	    params.put("idEstudio", idEstudio);
	    if( idComponente != null ) {
	    	params.put("idComponente", idComponente);
	    }else {
	        // Optional: If you don't want to include it in params when null
	        params.put("idComponente", null); // Uncomment if needed
	    }
	    
		List<PcmComponentVO> pcmComponentVOList = (List<PcmComponentVO>) pcmComponentService.getPcmComponentList(params);

		return pcmComponentVOList;
	}
	
	//-----------------------------------------------
	/**
	* Method for Updating Component Data of PCM
	* @param requestData
	* @param request
	* @return ResponseEntity<?>
	*/
	@RequestMapping(value = "/pcmComponent", method = RequestMethod.PUT)
	@ResponseBody
	public ResponseEntity<?> saveComponente(@RequestBody Map<String, Object> requestData, HttpServletRequest request) {
		try {
			requestData.put("Ls_Ip",  Utilities.getClientIp(request));
			
			pcmComponentService.savePcmComponent(requestData);
			
			Map<String, Object> response = new HashMap<>();
			response.put("success", true);
			return new ResponseEntity<>(response, HttpStatus.OK);

		} catch (Exception e) {
			e.printStackTrace();

			String message = messageSource.getMessage("error.internal_server_error", null,
					LocaleContextHolder.getLocale());
			Map<String, Object> errorResponse = new HashMap<>();
			errorResponse.put("success", false);
			errorResponse.put("message", message);
			return new ResponseEntity<>(errorResponse, HttpStatus.OK);
		}
	}
	
	//-----------------------------------------------
	/**
	* Method for Inserting New Component Data of PCM
	* @param components
	* @param request
	* @return ResponseEntity<Map<String, Object>>
	*/
	@RequestMapping(value = "/pcmComponent/nuevos", method = RequestMethod.POST)
	@ResponseBody
	public ResponseEntity<Map<String, Object>> saveNewPcmComponents(@RequestBody List<Map<String, Object>> components, HttpServletRequest request) {
		try {
			
			HttpStatus httpStatus = HttpStatus.OK;			
	        Map<String, Object> responseData = new HashMap<>();
	        responseData.put("status", "0" );
	        
	        pcmComponentService.savePcmComponents(components, Utilities.getClientIp(request));
	        
	        responseData.put("success", true);
	        
	        return new ResponseEntity<>(responseData, httpStatus);
	    } catch (Exception e) {
	    	e.printStackTrace();
	    	String message = messageSource.getMessage("error.internal_server_error", null,
					LocaleContextHolder.getLocale());
	    	
	        Map<String, Object> errorResponse = new HashMap<>();
	        errorResponse.put("status", -1);
	        errorResponse.put("description", message);
	        errorResponse.put("result", 0);
	        
	        return new ResponseEntity<>(errorResponse, HttpStatus.INTERNAL_SERVER_ERROR);
	    }
	}
 	
	//-----------------------------------------------
	/**
	* Method for Deleting the Current Component of PCM
	* @param requestData
	* @param request
	* @return ResponseEntity<?>
	*/
	@RequestMapping(value = "/pcmComponent/deleteComponenteActual", method = RequestMethod.POST)
	@ResponseBody
	public ResponseEntity<?> deleteComponenteActual(@RequestBody Map<String, Object> requestData, HttpServletRequest request) {
		try {
			ObjectMapper mapper = new ObjectMapper();
	        List<Integer> deleteIds = mapper.convertValue(requestData.get("deleteIds"), new TypeReference<List<Integer>>() {});
	        List<Integer> cierreIds = mapper.convertValue(requestData.get("cierreIds"), new TypeReference<List<Integer>>() {});

			cierreIds.forEach(cierreId -> {
				Map<String, Object> param = new HashMap<>();
				param.put("Ln_IdActividadCierre", cierreId);
			    
				pcmActivityService.deleteActividadesCierre(param);
			});
			
			deleteIds.forEach(deleteId -> {
				Map<String, Object> param = new HashMap<>();
				param.put("Ln_IdEstudio", requestData.get("idEstudio"));
			    param.put("Ln_IdTipo", null); // 필요에 따라 값 설정
			    param.put("Ln_IdSubTipo", null); // 필요에 따라 값 설정
			    param.put("Ln_IdTipoComponente", null); // 필요에 따라 값 설정
			    param.put("Ln_IdComponente", deleteId);
			    param.put("Ls_nombreComp", null); // 필요에 따라 값 설정
			    param.put("Ln_IdDatum", null); // 필요에 따라 값 설정
			    param.put("Ln_IdZona", null); // 필요에 따라 값 설정
			    param.put("Ls_GeometryWKT", null); // 필요에 따라 값 설정
			    param.put("Ls_CodOperacion", "D");
			    param.put("Ls_Usuario", "usuario");
			    param.put("Ls_Ip", "ip");
			    
				pcmComponentService.savePcmComponent(param);
			});

			Map<String, Object> response = new HashMap<>();
			response.put("success", true);
			return new ResponseEntity<>(response, HttpStatus.OK);

		} catch (Exception e) {
			e.printStackTrace();

			String message = messageSource.getMessage("error.internal_server_error", null,
					LocaleContextHolder.getLocale());
			Map<String, Object> errorResponse = new HashMap<>();
			errorResponse.put("success", false);
			errorResponse.put("message", message);
			return new ResponseEntity<>(errorResponse, HttpStatus.OK);
		}
	}
	
    //-----------------------------------------------
	/**
	* Method for Processing Area Component Map Data and Displaying on the Screen
	* @param model
	* @param jsonPayload
	* @return (String) "include/areaCompMap"
	* @throws Exception
	*/
 	@PostMapping("/pcmComponent/areaCompMap")
	public String areaCompMapPost(Model model, @RequestBody String jsonPayload) throws Exception{
		JSONObject jsonObject = new JSONObject(jsonPayload);
		Map<String, Object> jsonMap = jsonObject.toMap();
		
        model.addAttribute("info", jsonMap);

		return "include/areaCompMap";
	}
 	
	//-----------------------------------------------
	/**
	* Method for Processing Area Component Map Data and Displaying on the Screen
	* @param model
	* @param jsonPayload
	* @return (String) "include/areaMap"
	* @throws Exception
	*/
 	@PostMapping("/pcmComponent/areaMap")
	public String areaMapPost(Model model, @RequestBody String jsonPayload) throws Exception{
		JSONObject jsonObject = new JSONObject(jsonPayload);
		Map<String, Object> jsonMap = jsonObject.toMap();
		
        model.addAttribute("info", jsonMap);

		return "include/areaMap";
	}
 	
	//-----------------------------------------------
	/**
	* Method for Validating Component(Tab 2) of PCM
	* @param requestData
	* @param request
	* @return ResponseEntity<Map<String, Object>>
	*/
	@RequestMapping(value = "/pcmComponent/validate", method = RequestMethod.POST)
	@ResponseBody
	public ResponseEntity<Map<String, Object>> validate(@RequestBody Map<String, Object> requestData,
			HttpServletRequest request) {
		try {
			requestData.put("lsIpIngreso", Utilities.getClientIp(request));
			requestData.put("lsUsuario", Utilities.getSessionValue(request, "USUARIO_LOGIN"));
			requestData.put("lnIdFuente", idFuente);
			
			ValidateResultVO result = pcmComponentService.validate(requestData);
			
			Map<String, Object> responseData = new HashMap<>();
			responseData.put("status", result.getStatus());
			responseData.put("description", result.getDescription());
			responseData.put("result", result.getResult());

			HttpStatus httpStatus = (result.getStatus() != 3) ? HttpStatus.OK : HttpStatus.BAD_REQUEST;
			return new ResponseEntity<>(responseData, httpStatus);
		} catch (Exception e) {
			e.printStackTrace();
			String message = messageSource.getMessage("error.internal_server_error", null,
					LocaleContextHolder.getLocale());
			Map<String, Object> errorResponse = new HashMap<>();
			errorResponse.put("status", -1);
			errorResponse.put("description", message);
			errorResponse.put("result", 0);

			return new ResponseEntity<>(errorResponse, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	// -------------------------------------------------------------
	/**
	 * Method for Uploading CSV files
	 * @param file
	 * @param idEstudio
	 * @param request
	 * @return ResponseEntity<?>
	 */
	@PostMapping("/pcmComponent/upload-csv")
    @ResponseBody
    public ResponseEntity<?> uploadCSV(
    		@RequestParam("file") MultipartFile file,
            @RequestParam("idEstudio") String idEstudio,
    		HttpServletRequest request
    		) {
		Map<String, Object> paramMap  = new HashMap<>();
		Map<String, Object> responseData = new HashMap<>();
		try {
			String idCliente = Utilities.getSessionValue(request, "ID_CLIENTE");

			paramMap.put("idEstudio", idEstudio);
			paramMap.put("idCliente", Integer.parseInt(idCliente));
			paramMap.put("lsIpIngreso", Utilities.getClientIp(request));
			paramMap.put("lsUsuario", Utilities.getSessionValue(request, "USUARIO_LOGIN"));
			// insert csv file into table
			String tableName = String.format("%s.%s", schemasName, commonService.getDocumentoTableName(menuId));
	        
	        List<Integer> addedArchivoId = new ArrayList<>();
			addedArchivoId.add(insertMapRelatedFile(file, tableName, idEstudio, request));
			
	        responseData.put("success", true);

			return new ResponseEntity<>(responseData, HttpStatus.OK);
		} catch (Exception e) {
			e.printStackTrace();

			String message = messageSource.getMessage("error.internal_server_error", null,
					LocaleContextHolder.getLocale());
			responseData.put("message", message);

			return new ResponseEntity<>(responseData, HttpStatus.INTERNAL_SERVER_ERROR);
		}
    }
	
	// -------------------------------------------------------------
	/**
	 * Method for Uploading SHAPE files
	 * @param files
	 * @param idEstudio
	 * @param request
	 * @return ResponseEntity<?>
	 * @throws JsonMappingException
	 * @throws JsonProcessingException
	 */
	@PostMapping("/pcmComponent/upload-shape")
	@ResponseBody
	public ResponseEntity<?> uploadShape(
		    @RequestPart(value = "files", required = false) MultipartFile[] files,
	        @RequestParam("idEstudio") String idEstudio,
		    HttpServletRequest request) throws JsonMappingException, JsonProcessingException {
	
		Map<String, Object> responseData = new HashMap<>();
		
		try {
			List<Integer> addedArchivoId = new ArrayList<>();
			String tableName = String.format("%s.%s", schemasName, commonService.getDocumentoTableName(menuId));
			Arrays.stream(files).filter(file -> !file.isEmpty()).forEach(file -> {
				try {
					addedArchivoId.add(insertMapRelatedFile(file, tableName, idEstudio, request));
				} catch (Exception e) {
					e.printStackTrace();
				}
			});
			
	        responseData.put("success", true);
	
			return new ResponseEntity<>(responseData, HttpStatus.OK);
		} catch (Exception e) {
			e.printStackTrace();
	
			String message = messageSource.getMessage("error.internal_server_error", null,
					LocaleContextHolder.getLocale());
			responseData.put("message", message);
	
			return new ResponseEntity<>(responseData, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	// -------------------------------------------------------------
	/**
	 * Method for Inserting Map Related File Data
	 * @param file
	 * @param tableName
	 * @param request
	 * @return int
	 * @throws IOException
	 */
	private int insertMapRelatedFile(MultipartFile file, String tableName, String idEstudio, 
									HttpServletRequest request) throws IOException {
		String lsUsuario = Utilities.getSessionValue(request, "USUARIO_LOGIN");	
		String originFileName = file.getOriginalFilename();
		int idArchivo = getNewIdArchivo(tableName, idEstudio);
		
		Map<String, Object> fileParams = new HashMap<String, Object>();
		fileParams.put("idArchivo", idArchivo);
		
		fileParams.put("tableName", tableName);
		fileParams.put("idEstudio", Integer.parseInt(idEstudio));
		fileParams.put("idMenu", menuId);
		fileParams.put("idSeccion", fileAnexo);
		
		fileParams.put("documento", file.getBytes());
	    fileParams.put("nombreDocumento", originFileName);
	    fileParams.put("idTipoAdjunto", 3);	// mapas
	    fileParams.put("flgEstado", 1);
	    fileParams.put("usuIngreso", lsUsuario);
	    fileParams.put("ipIngreso", request.getRemoteAddr());
		
		commonService.registAdjuntarArchivoFileData(fileParams);
		
		return idArchivo;
	}
	
	// -------------------------------------------------------------
	/**
	 * Method for Creating New ID(IdArchivo) for the Attached File
	 * @param tableName
	 * @param idEstudio
	 * @return int
	 */
	private int getNewIdArchivo(String tableName, String idEstudio) {
		Map<String, Object> archivoMap = new HashMap<String, Object>();
		archivoMap.put("tableName", tableName);
		archivoMap.put("idEstudio", Integer.parseInt(idEstudio));
		archivoMap.put("idSeccion", fileAnexo);								
		archivoMap.put("idMenu", menuId);
		
		return commonService.getLatestIdArchivo(archivoMap);
	}
	
	//================================================
	@RequestMapping(value = "/pcmComponentOld", method = RequestMethod.GET)
	public String pcmComponentOld(Model model,
							@RequestParam("idClient")String idClient,
							@RequestParam("USUARIO_LOGIN")String userIdAndRuc,
							@RequestParam("idEstudio")String idEstudio,
							@RequestParam("codigoExpediente")String codigoExpediente,
							@RequestParam("idMenu") String idMenu,
							@RequestParam("mineraNombre")String mineraNombre) {
		logger.info("The Cotroller is {}.", "pcmComponent");
		
		model.addAttribute("Ln_IdProcedimiento", Integer.parseInt(idProcedimiento));
		model.addAttribute("Li_IdProcedimiento", Integer.parseInt(idProcedimiento));
		model.addAttribute("Ln_TipoEstudio", 7);
		model.addAttribute("idCategoria", 7);
		model.addAttribute("idTipoEvaluacion", 2);
		model.addAttribute("idClient", idClient);
		model.addAttribute("userIdAndRuc", userIdAndRuc);
		model.addAttribute("idEstudio", idEstudio);
		model.addAttribute("codigoExpediente", codigoExpediente);
		model.addAttribute("idMenu", idMenu);
		model.addAttribute("mineraNombre", mineraNombre);
		
		 return "pcm/pcmComponentOld";
	}

	// Enable DBMS_OUTPUT in Oracle
	public static void enableDbmsOutput(Connection conn) throws SQLException {
	    try (Statement stmt = conn.createStatement()) {
	        stmt.execute("BEGIN DBMS_OUTPUT.ENABLE(NULL); END;");
	    }
	}

	// Disable DBMS_OUTPUT in Oracle
	public static void disableDbmsOutput(Connection conn) throws SQLException {
	    try (Statement stmt = conn.createStatement()) {
	        stmt.execute("BEGIN DBMS_OUTPUT.DISABLE(); END;");
	    }
	}

	// Fetch DBMS_OUTPUT and print it in Java logs
	public static void fetchDbmsOutput(Connection conn) throws SQLException {
	    try{
	    
	    	// Enable DBMS_OUTPUT
	    	CallableStatement enableStmt = conn.prepareCall("{call DBMS_OUTPUT.ENABLE()}");
	    	enableStmt.execute();
	
	    	// Run your procedure or PL/SQL block that uses DBMS_OUTPUT.PUT_LINE
	
	    	// Retrieve the DBMS_OUTPUT buffer using GET_LINES
	    	CallableStatement getLinesStmt = conn.prepareCall("{call DBMS_OUTPUT.GET_LINES(?, ?)}");
	    	getLinesStmt.registerOutParameter(1, OracleTypes.ARRAY, "SYS.DBMSOUTPUT_LINESARRAY");
	    	getLinesStmt.registerOutParameter(2, java.sql.Types.INTEGER);
	    	getLinesStmt.execute();
	
	    	// Get the number of lines
	    	int numLines = getLinesStmt.getInt(2);
	
	    	// Get the output lines
	    	Array linesArray = getLinesStmt.getArray(1);
	    	String[] lines = (String[]) linesArray.getArray();
	
	    	// Print the lines
	    	for (String line : lines) {
	    	    System.out.println(line);
	    	}
	
	    } catch (SQLException e) {
	        e.printStackTrace(); // 또는 로그로 상세 오류 메시지 출력
	    }
	}

	public static void DBMSOUTPUT_LOG() {
	    String jdbcUrl = "jdbc:oracle:thin:@172.25.0.70:1521:MEM7"; // Oracle JDBC URL
	    String username = "prove_koika";
	    String password = "Prov3-K0ik@2024$";
	
	    try (Connection conn = DriverManager.getConnection(jdbcUrl, username, password)) {
	
	        // Enable DBMS_OUTPUT
	        enableDbmsOutput(conn);
	
	        // Execute some PL/SQL code that writes to DBMS_OUTPUT
	        try (Statement stmt = conn.createStatement()) {
	            stmt.execute("BEGIN DBMS_OUTPUT.PUT_LINE('Hello from DBMS_OUTPUT!'); END;");
	        }
	
	        // Fetch and log DBMS_OUTPUT content
	        fetchDbmsOutput(conn);
	
	        // Disable DBMS_OUTPUT
	        disableDbmsOutput(conn);
	
	    } catch (SQLException e) {
	        e.printStackTrace();
	    }
	}
}
