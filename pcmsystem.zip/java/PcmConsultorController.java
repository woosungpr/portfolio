package com.peru.minero;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.Field;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.sql.DataSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.MessageSource;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.innorix.transfer.InnorixUpload;
import com.peru.minero.service.PcmConsultorService;
import com.peru.minero.utils.Utilities;
import com.peru.minero.vo.PcmConsultorFileVO;
import com.peru.minero.vo.PcmConsultorVO;

/**
 * @author yang woosung 
 * 
 * * 작성일자 : 2024. 10. 17 ~
 * * 화면 ID : DE-221_UI-0901 
 * * 프로그램 ID : DE-231_PG-0901-013-66
 * 
 *  CASO A NUEVA INSCRIPCION(컨설턴트 신규 등록)  화면 controller
 * 
 */

@Controller
public class PcmConsultorController {
	
	private static final Logger logger = LoggerFactory.getLogger(PcmConsultorController.class);
	
	@Value("${constants.idProcedimiento}")
	private String idProcedimiento;
	
	@Autowired
	private PcmConsultorService pcmConsultorService;
	
    @Autowired
    private DataSource dataSource;
    
	@Value("${file.consultor.fileConsultor}")
	private String fileConsultorVal;
	
	private int globalProyectoseq = 0; 
	
	@Autowired
	private MessageSource messageSource;
	
	//-----------------------------------------------
	/**
	* Method for Initializing the Screen
	* @param model
	* @param ruc
	* @param request
	* @return (String) "pcm/pcmConsultorReg"
	*/
	@RequestMapping(value = "/pcmConsultorReg", method = RequestMethod.GET)
	public String pcmConsultorReg(Model model
								,@RequestParam(value = "ruc", required = false, defaultValue = "0") String ruc
								,HttpServletRequest request
			) {
		logger.info("The Controller is {}.", "pcmConsultorReg");
		
		model.addAttribute("Ln_IdProcedimiento", Integer.parseInt(idProcedimiento));
		model.addAttribute("Li_IdProcedimiento", Integer.parseInt(idProcedimiento));
		model.addAttribute("Ln_TipoEstudio", 7);
		model.addAttribute("idCategoria", 7);
		model.addAttribute("idTipoEvaluacion", 2);
		model.addAttribute("idCategoria", 7);
		model.addAttribute("iIngreso",  Utilities.getClientIp(request));
		model.addAttribute("iModifica", Utilities.getClientIp(request));
		model.addAttribute("ruc", ruc);
		
		return "pcm/pcmConsultorReg";
	}
	
	//-----------------------------------------------
	/**
	* Method for Initializing the Screen
	* @param model
	* @param ruc
	* @param request
	* @return (String) "pcm/pcmConsultorProfReg"
	*/
	@RequestMapping(value = "/pcmConsultorProfReg", method = RequestMethod.GET)
	public String pcmConsultorProfReg(Model model
								,HttpServletRequest request
								,@RequestParam(value = "ruc", required = false, defaultValue = "0") String ruc
			) {
		logger.info("The Controller is {}.", "pcmConsultorProfReg");
		
		model.addAttribute("Ln_IdProcedimiento", Integer.parseInt(idProcedimiento));
		model.addAttribute("Li_IdProcedimiento", Integer.parseInt(idProcedimiento));
		model.addAttribute("Ln_TipoEstudio", 7);
		model.addAttribute("idCategoria", 7);
		model.addAttribute("idTipoEvaluacion", 2);
		model.addAttribute("especialList", pcmConsultorService.getEspecialList());
		model.addAttribute("companyList",  pcmConsultorService.getCompanyList());
		model.addAttribute("iIngreso",  Utilities.getClientIp(request));
		model.addAttribute("iModifica", Utilities.getClientIp(request));
		model.addAttribute("reload", request.getParameter("reload"));
		model.addAttribute("dni", request.getParameter("dni"));
		model.addAttribute("idcole", request.getParameter("idcole"));
		model.addAttribute("iddni", request.getParameter("iddni"));
		model.addAttribute("idcert", request.getParameter("idcert"));
		model.addAttribute("idddjj", request.getParameter("idddjj"));
		model.addAttribute("ruc", ruc);
		
		return "pcm/pcmConsultorProfReg";
	}
	
	//-----------------------------------------------
	/**
	* Method for Retrieving the List of PCM Consultants and Displaying on the Screen
	* @param model
	* @param USUARIO_LOGIN
	* @param dni
	* @param currentPage
	* @param ruc
	* @return (String) "pcm/pcmConsultorList"
	*/
	@RequestMapping(value = "/pcmConsultorList", method = RequestMethod.GET)
	public String pcmConsultorList(Model model
								,@RequestParam(value = "USUARIO_LOGIN", required = false, defaultValue = "0") String userIdAndRuc
								,@RequestParam(value = "dni", required = false, defaultValue = "" ) String dni
								,@RequestParam(name="currentPage", defaultValue="1") int currentPage
								,@RequestParam(name="ruc", defaultValue="0") String ruc
			) {
		logger.info("The Controller is {}.", "pcmConsultorList");
	
	    if (!dni.matches("\\d+")) {
	        dni = null; // 유효하지 않은 경우 null로 설정
	    }
	    
		Map<String, Object> params = new HashMap<>();
	    params.put("dni", dni);
	    params.put("currentPage", currentPage);
	    
	    System.out.println("################### pcmConsultorList currentPage:" + currentPage + " ruc:" + ruc);
	    
	    makePagination(model, currentPage, ruc);
	    
	    model.addAttribute("ruc", ruc);
	    
	    params.put("ruc", ruc);
	    model.addAttribute("idRegistro", pcmConsultorService.getMaxIdRegistro(params));
	    
		return "pcm/pcmConsultorList";
	}
	
	//-----------------------------------------------
	/**
	* Method for Getting the Maximum ID(IdRegistro)
	* @param ruc
	* @return long
	*/
	public long getMaxIdRegistro(String ruc) {
	  	Map<String, Object> params = new HashMap<>();
	    params.put("ruc", ruc);
	
	    long maxId = pcmConsultorService.getMaxIdRegistro(params);
	 
	    return maxId;
	}
	
	//-----------------------------------------------
	/**
	* Method for Getting the Maximum ID(IdArchivo)
	* @param consultoraFileDatos
	* @return int
	*/
	public int getMaxIdArchivo(PcmConsultorFileVO consultoraFileDatos) {
	  	Map<String, Object> params = new HashMap<>();
	    params.put("idRegistro", consultoraFileDatos.getIdRegistro());
	    params.put("idConsultor", consultoraFileDatos.getIdConsultor());
	    params.put("archivoTipo", consultoraFileDatos.getArchivoTipo());
	    params.put("idArchivo", consultoraFileDatos.getIdArchivo());
	    
	    int maxId = pcmConsultorService.getMaxIdArchivo(params);
	 
	    return maxId;
	}	
	
	//-----------------------------------------------
	/**
	* Method for Getting the Maximum ID(IdArchivo)
	* @param consultoraFileDatos
	* @return int
	*/
	public int getMaxProyIdArchivo(PcmConsultorFileVO consultoraFileDatos) {
	  	Map<String, Object> params = new HashMap<>();
	    params.put("idRegistro", consultoraFileDatos.getIdRegistro());
	    params.put("idConsultor", consultoraFileDatos.getIdConsultor());
	    params.put("expEmpresa", consultoraFileDatos.getExpEmpresa());
	    params.put("archivoTipo", consultoraFileDatos.getArchivoTipo());
	    params.put("idArchivo", consultoraFileDatos.getIdArchivo());
	    
	    int maxId = pcmConsultorService.getMaxProyIdArchivo(params);
	 
	    return maxId;
	}	
	
	//-----------------------------------------------
	/**
	* Method for Getting the Maximum ID(IdConsultor)
	* @param id
	* @param dni
	* @return int
	*/
	public int getMaxIdConsultor(int id,String dni) {
	  	Map<String, Object> params = new HashMap<>();
	    params.put("idConsultor", id);
	    params.put("dni", dni);
	    
	    int maxId = pcmConsultorService.getMaxIdConsultor(params);
	 
	    return maxId;
	}	
	
	//-----------------------------------------------
	/**
	* Method for Getting the Maximum ID(EmpresaSeq)
	* @param id
	* @param dni
	* @param expEmpresa
	* @return int
	*/
	public int getMaxEmpresaSeq(int id,String dni,String expEmpresa) {
	  	Map<String, Object> params = new HashMap<>();
	    params.put("idConsultor", id);
	    params.put("dni", dni);
	    params.put("expEmpresa", expEmpresa);
	    
	    int maxSeq = pcmConsultorService.getMaxEmpresaSeq(params);
	 
	    return maxSeq;
	}
	
	//-----------------------------------------------
	/**
	* Method for Getting the Maximum ID(ProyectoSeq)
	* @param id
	* @param empresaSeq
	* @param proyectoSeq
	* @return int
	*/
	public int getMaxProyectoSeq(int id,int empresaSeq,int proyectoSeq) {
	  	Map<String, Object> params = new HashMap<>();
	    params.put("idConsultor", id);
	    params.put("empresaSeq", empresaSeq);
	    params.put("proyectoSeq", proyectoSeq);
	    
	    int maxSeq = pcmConsultorService.getMaxProyectoSeq(params);
	 
	    return maxSeq;
	}
	
	//-----------------------------------------------
	/**
	* Method for Getting the Maximum ID(ArchivoSeq)
	* @param consultoraFileDatos
	* @return int
	*/
	public int getMaxArchivoSeq(PcmConsultorFileVO consultoraFileDatos) {
	  	Map<String, Object> params = new HashMap<>();
	    params.put("idRegistro", consultoraFileDatos.getIdRegistro());
	    params.put("idConsultor", consultoraFileDatos.getIdConsultor());
	    params.put("expEmpresa", consultoraFileDatos.getExpEmpresa());
	    params.put("archivoTipo", consultoraFileDatos.getArchivoTipo());
	    params.put("idArchivo", consultoraFileDatos.getIdArchivo());
	    params.put("idArchivoSeq", consultoraFileDatos.getIdArchivoSeq());
	    
	    int maxSeq = pcmConsultorService.getMaxArchivoSeq(params);
	 
	    return maxSeq;
	}
	
	//-----------------------------------------------
	/**
	* Method for Getting the Maximum ID(IdArchivo)
	* @param consultoraFileDatos
	* @return int
	*/
	public int getDetPartMaxIdArchivo(PcmConsultorFileVO consultoraFileDatos) {
	  	Map<String, Object> params = new HashMap<>();
	    params.put("idRegistro", consultoraFileDatos.getIdRegistro());
	    params.put("idConsultor", consultoraFileDatos.getIdConsultor());
	    params.put("archivoTipo", consultoraFileDatos.getArchivoTipo());
	    params.put("idArchivo", consultoraFileDatos.getIdArchivo());
	    
	    int maxId = pcmConsultorService.getDetPartMaxIdArchivo(params);
	 
	    return maxId;
	}	
	
	//-----------------------------------------------
	/**
	* Method for Getting the Maximum ID(ArchivoSeq)
	* @param consultoraFileDatos
	* @return int
	*/
	public int getDetPartMaxArchivoSeq(PcmConsultorFileVO consultoraFileDatos) {
	  	Map<String, Object> params = new HashMap<>();
	    params.put("idRegistro",  consultoraFileDatos.getIdRegistro());
	    params.put("idConsultor", consultoraFileDatos.getIdConsultor());
	    params.put("archivoTipo", consultoraFileDatos.getArchivoTipo());
	    params.put("idArchivo",   consultoraFileDatos.getIdArchivo());

	    int maxSeq = pcmConsultorService.getDetPartMaxArchivoSeq(params);
	 
	    return maxSeq;
	}
	
	//-----------------------------------------------
	/**
	* Method for Printing PcmConsultorVO Object
	* @param consultoraDatos
	*/
	public void printAllFields(PcmConsultorVO consultoraDatos) {
	    try {
	        for (Field field : consultoraDatos.getClass().getDeclaredFields()) {
	            field.setAccessible(true); // private 필드에 접근 허용
	            System.out.println(field.getName() + ": " + field.get(consultoraDatos));
	        }
	    } catch (IllegalAccessException e) {
	        e.printStackTrace();
	    }
	}
	
	//-----------------------------------------------
	/**
	* Method for Printing Files Name
	* @param file
	*/
	public void printFileName(MultipartFile file) {
		System.out.println("Class type: " + file.getClass().getName());
	    String fullName = file.getOriginalFilename();
	    System.out.println("Actual fullName object: " + fullName);
	    System.out.println("fullName class type: " + (fullName != null ? fullName.getClass().getName() : "null"));
	    System.out.println("file.getSize(): " + file.getSize());
	    
	    
	    if (fullName != null) {
	        System.out.println("2 fullName: " + fullName);
	    } else {
	        System.out.println("3 File name is null.");
	    }
	}
	
	//-----------------------------------------------
	/**
	* Method for Uploading Consultant-Related Files
	* @param request
	* @param response
	* @param el
	* @param idEstudio
	* @param idRegistro
	* @param solicitud
	* @param nroExpediente
	* @param nombre
	* @param ruc
	* @param partida
	* @param repLegal
	* @param domicio
	* @param corElect1
	* @param corElect2
	* @param usuIngreso
	* @param ipIngreso
	* @param usuModifica
	* @param ipModifica
	*/
	@CrossOrigin
	@RequestMapping(value = "/pcmConsultorGuardar/upload", method = RequestMethod.POST)
	synchronized public void handleUpload(
											HttpServletRequest request, 
											HttpServletResponse response,
											@RequestParam("el") String uploadControlName,
											@RequestParam(value = "idEstudio", required = false, defaultValue = "0") Integer pidEstudio, // Integer로 변경하여 null 허용
											@RequestParam(value = "idRegistro", required = false) Long pidRegistro,
											@RequestParam(value = "solicitud", required = false) String psolicitud,
											@RequestParam(value = "nroExpediente", required = false) String pnroExpediente,
											@RequestParam(value = "ctupa", required = false) int ctupa,
											@RequestParam(value = "nombre", required = false) String pnombre,
											@RequestParam(value = "ruc", required = false) String pruc,
											@RequestParam(value = "partida", required = false) String ppartida,
											@RequestParam(value = "repLegal", required = false) String prepLegal,
											@RequestParam(value = "domicio", required = false) String pdomicio,
											@RequestParam(value = "corElect1", required = false) String pcorElect1,
											@RequestParam(value = "corElect2", required = false) String pcorElect2,
											@RequestParam(value = "usuIngreso", required = false) String pusuIngreso,
											@RequestParam(value = "ipIngreso", required = false) String pipIngreso,
											@RequestParam(value = "usuModifica", required = false) String pusuModifica,
											@RequestParam(value = "ipModifica", required = false) String pipModifica
											) {

		System.out.println(" /pcmConsultorGuardar/upload start");
		
	    // 디버깅 로그 추가
	    System.out.println("Received uploadControlName: " + uploadControlName);
	    System.out.println("Received idEstudio: " + pidEstudio);
	    
		PcmConsultorVO consultoraDatos = new PcmConsultorVO();
		
		Long gidRegistro = (long) 0; // 업로드 처리 후 생성된 gidRegistro 값을 설정
		
		try {
        
			// 업로드 완료에 대한 구분
            if (!"finalUpload".equals(uploadControlName)) {
            	
	        	String directory = request.getSession().getServletContext().getRealPath("/common/data/"); // 서버 상대경로
				int maxPostSize = 2147482624; // bytes
	
				System.out.println("########### request :" + request + " response :" + response + " maxPostSize :" + maxPostSize + " directory :" + directory);
				
				InnorixUpload uploader = new InnorixUpload(request, response, maxPostSize, directory);
	
				String _orig_filename = uploader.getParameter("_orig_filename"); // 원본 파일명
				String _new_filename = uploader.getParameter("_new_filename"); // 저장 파일명
				String _filepath = uploader.getParameter("_filepath"); // 파일 저장경로
				
				System.out.println(" _orig_filename :" + _orig_filename + " _new_filename :" + _new_filename + " _filepath :" + _filepath );
				
				uploader.run();
	
				// 개별파일 업로드 완료
				if (uploader.isUploadDone()) {
	
					String inputId   =  uploader.getParameter("inputId");
					
					Long idRegistro = Long.valueOf(uploader.getParameter("idRegistro"));
					String solicitud = uploader.getParameter("solicitud");
					String nroExpediente = uploader.getParameter("nroExpediente");
					String nombre = uploader.getParameter("nombre");
					String ruc = uploader.getParameter("ruc");
					String partida = uploader.getParameter("partida");
					String repLegal = uploader.getParameter("repLegal");
					String domicio = uploader.getParameter("domicio");
					String corElect1 = uploader.getParameter("corElect1");
					String corElect2 = uploader.getParameter("corElect2");
					String nombreProyecto = (uploader.getParameter("nombreProyecto") == null) ? "NOPROY" : uploader.getParameter("nombreProyecto");
					String usuIngreso = uploader.getParameter("usuIngreso");
					String ipIngreso = uploader.getParameter("ipIngreso");
					String usuModifica = uploader.getParameter("usuModifica");
					String ipModifica = uploader.getParameter("ipModifica");
					
					System.out.println("########## uploader idRegistro: " + uploader.getParameter("idRegistro"));
					System.out.println("########## uploadControlName: " + uploadControlName + " nombreProyecto :" + nombreProyecto + " ctupa :" + ctupa);
		        	System.out.println("########## idRegistro:" + idRegistro + " solicitud:" + solicitud + " nroExpediente:" + nroExpediente + " nombre:" + nombre + " ruc: " + ruc + " partida: " + partida);
		        	System.out.println("########## repLegal:" + repLegal + " domicio:" + domicio + " corElect1:" + corElect1 + " corElect2:" + corElect2 + " usuIngreso: " + usuIngreso + " ipIngreso: " + ipIngreso+ " usuModifica: " + usuModifica + " ipModifica: " + ipModifica);
		        	
		        	
		        	if(idRegistro == null || String.valueOf(idRegistro) == "" || idRegistro == 0) {
		        		idRegistro = getMaxIdRegistro(ruc);
		        		gidRegistro = idRegistro;
		        		
		        		System.out.println("after idRegistro: " + idRegistro);
		        	}
		        	
		        	consultoraDatos.setIdRegistro(idRegistro);
		        	consultoraDatos.setIdConsultor(-1);
		        	consultoraDatos.setNroExpediente(nroExpediente);
		        	consultoraDatos.setCtupa(ctupa);
		        	
		        	consultoraDatos.setNombre(nombre);
		        	consultoraDatos.setDomicio(domicio);
		        	consultoraDatos.setRepLegal(repLegal);
		        	consultoraDatos.setRuc(ruc);
		        	consultoraDatos.setPartida(partida);
		        	consultoraDatos.setCorElect1(corElect1);
		        	consultoraDatos.setCorElect2(corElect2);
		        	consultoraDatos.setNombreProyecto(nombreProyecto);
		        	consultoraDatos.setUsuIngreso(usuIngreso);
		        	consultoraDatos.setIpIngreso(ipIngreso);
		        	consultoraDatos.setUsuModifica(usuModifica);
		        	consultoraDatos.setIpModifica(ipModifica);
		        	consultoraDatos.setSolicitud(solicitud);
		        		
					// 서버에 저장된 파일의 데이터
					Path path = Paths.get(directory, _new_filename); // 서버경로 + 저장 파일명
					byte[] fileBytes = Files.readAllBytes(path);
					
					System.out.println("/pcmConsultorGuardar/upload uploadControlName = " + uploadControlName);
					
					saveConsultReqFileToDB(_orig_filename, inputId, fileBytes, consultoraDatos, request);
					
					// 서버에서 파일 삭제
					Files.delete(path);
				}
				
				System.out.println("========== file transfer " + System.currentTimeMillis() + " ==========");
				System.out.println("_orig_filename \t = " + _orig_filename);
				System.out.println("_new_filename \t = " + _new_filename);
				System.out.println("_filepath \t = " + _filepath);
				
				System.out.println("##### after gidRegistro: " + gidRegistro);
				
				if(gidRegistro != null && String.valueOf(gidRegistro) != "" && String.valueOf(gidRegistro) != "0") {
					uploader.setCustomValue("gidRegistro", String.valueOf(gidRegistro) ); // 클라이언트측으로 전달할 key,value값 설정 
					uploader.sendCustomValue();							 // 클라이언트측으로 key, value값 전달
				}
				
            }else if( "finalUpload".equals(uploadControlName) ) {
            	
				Long idRegistro = Long.valueOf(pidRegistro);
				String solicitud = psolicitud;
				String nroExpediente = pnroExpediente;
				String nombre = pnombre;
				String ruc = pruc;
				String partida = ppartida;
				String repLegal = prepLegal;
				String domicio = pdomicio;
				String corElect1 = pcorElect1;
				String corElect2 = pcorElect2;
				String usuIngreso = pusuIngreso;
				String ipIngreso = pipIngreso;
				String usuModifica = pusuModifica;
				String ipModifica = pipModifica;
				
				System.out.println("########## pidRegistro: " + pidRegistro);
				System.out.println("########## uploadControlName: " + uploadControlName);// + " idEstudio :" + idEstudio );
	        	System.out.println("########## pidRegistro:" + pidRegistro + " psolicitud:" + psolicitud + " pnroExpediente:" + pnroExpediente + " pnombre:" + pnombre + " pruc: " + pruc + " ppartida: " + ppartida);
	        	System.out.println("########## prepLegal:" + prepLegal + " pdomicio:" + pdomicio + " pcorElect1:" + pcorElect1 + " pcorElect2:" + pcorElect2 + " pusuIngreso: " + pusuIngreso + " pipIngreso: " + pipIngreso+ " pusuModifica: " + pusuModifica + " pipModifica: " + pipModifica);
	        	
	        	if(idRegistro == null || String.valueOf(idRegistro) == "" || idRegistro == 0) {
	        		idRegistro = getMaxIdRegistro(ruc);
	        		System.out.println("after idRegistro: " + idRegistro);
	        	}
	        	
	        	consultoraDatos.setIdRegistro(idRegistro);
	        	consultoraDatos.setNroExpediente(nroExpediente);
	        	consultoraDatos.setNombre(nombre);
	        	consultoraDatos.setDomicio(domicio);
	        	consultoraDatos.setRepLegal(repLegal);
	        	consultoraDatos.setRuc(ruc);
	        	consultoraDatos.setPartida(partida);
	        	consultoraDatos.setCorElect1(corElect1);
	        	consultoraDatos.setCorElect2(corElect2);
	        	consultoraDatos.setUsuIngreso(usuIngreso);
	        	consultoraDatos.setIpIngreso(ipIngreso);
	        	consultoraDatos.setUsuModifica(usuModifica);
	        	consultoraDatos.setIpModifica(ipModifica);
	        	
            	pcmConsultorService.mergeConsultoraDatos(consultoraDatos); // 최종 한 번만 실행
            	
            }
            
			// CORS 관련 헤더 추가
			response.setHeader("Access-Control-Allow-Origin", "*");
			response.setHeader("Access-Control-Allow-Credentials", "true");
			response.setHeader("Access-Control-Allow-Methods", "POST, OPTIONS");
			response.setHeader("Access-Control-Allow-Headers",
					"Authorization,DNT,X-Mx-ReqToken,Keep-Alive,User-Agent,X-Requested-With,If-Modified-Since,Cache-Control,Content-Type");
			
		} catch (Exception e) {
			 e.printStackTrace();
		}
		
	}
	
	//-----------------------------------------------
	/**
	* Method for Inserting or Updating Consultant-Related Files
	* @param filename
	* @param inputId
	* @param fileBytes
	* @param consultoraDatos
	* @param request
	*/
	private void saveConsultReqFileToDB(
									String filename, 
									String inputId,
									byte[] fileBytes, 
									PcmConsultorVO consultoraDatos,
									HttpServletRequest request) {
		
    	PcmConsultorFileVO blob = new PcmConsultorFileVO();
        blob.setIdRegistro(consultoraDatos.getIdRegistro());
        blob.setIdConsultor(consultoraDatos.getIdConsultor());
        blob.setExpEmpresa("NO");
        blob.setArchivoTipo(inputId); // input file id
        blob.setIdArchivo(consultoraDatos.getIdArchivo());
        System.out.println(" blob.getIdRegistro(): " + blob.getIdRegistro());
        
		int idArchivo = getMaxIdArchivo(blob);
		blob.setIdArchivo(idArchivo);
		blob.setIdArchivoSeq(1);
		
    	System.out.println("after blob.getIdArchivo(): " + blob.getIdArchivo() + " fileBytes:" + fileBytes.toString());
    	            	
        blob.setNombreArchivo(filename);
        blob.setNombreProyecto(consultoraDatos.getNombreProyecto());
        
        blob.setUsuIngreso(consultoraDatos.getUsuIngreso());
        blob.setIpIngreso(consultoraDatos.getIpIngreso());
        
        blob.setUsuModifica(consultoraDatos.getUsuModifica());
        blob.setIpModifica(consultoraDatos.getIpModifica());
        blob.setDocumento(fileBytes);
        
        System.out.println("################################################# 1 mergeConsultoraDocumentoBlob");
        try {
        	System.out.println("################################################# 2 mergeConsultoraDocumentoBlob");
        	pcmConsultorService.mergeConsultoraDocumentoBlob(blob);
        } catch (Exception e) {
        	System.out.println("################################################# mergeConsultoraDocumentoBlob Exception");
            e.printStackTrace();
        } finally {
        	System.out.println("################################################# 1 updateMergeFile");
        	try {
        		System.out.println("################################################# 2 updateMergeFile");
        		updateMergeFile(blob);
        		pcmConsultorService.mergeConsultoraRequisitos(consultoraDatos); 
        	}catch(SQLException e) {
        		e.printStackTrace();
        	} catch (Exception e) {
                e.printStackTrace();
            } 
        }
	}
	
	
	//-----------------------------------------------
	/**
	* Method for Retrieving PCM Consultant Data
	* @param ruc
	* @return PcmConsultorVO
	*/
	@RequestMapping(value = "/getPcmConsultoraDatos", method = RequestMethod.GET)
	@ResponseBody
	public PcmConsultorVO getPcmConsultoraDatos(@RequestParam("ruc") String ruc) {

		Map<String, Object> map = new HashMap<String, Object>();
		map.put("ruc", ruc);
		
		return pcmConsultorService.getPcmConsultoraDatos(ruc);
	}
	
	//-----------------------------------------------
	/**
	* Method for Uploading Consultant-Related Files
	* @param request
	* @param response
	* @param el
	* @param idEstudio
	* @param idRegistro
	* @param solicitud
	* @param nroExpediente
	* @param nombre
	* @param ruc
	* @param partida
	* @param repLegal
	* @param domicio
	* @param corElect1
	* @param corElect2
	* @param usuIngreso
	* @param ipIngreso
	* @param usuModifica
	* @param ipModifica
	*/
	@CrossOrigin
	@RequestMapping(value = "/pcmConsultorGuardar/modCasaDatos", method = RequestMethod.POST)
	synchronized public void handleModCasa(
											HttpServletRequest request, 
											HttpServletResponse response,
											@RequestParam("el") String uploadControlName,
											@RequestParam(value = "idEstudio", required = false, defaultValue = "0") Integer pidEstudio, // Integer로 변경하여 null 허용
											@RequestParam(value = "idRegistro", required = false) Long pidRegistro,
											@RequestParam(value = "idArchivo", required = false, defaultValue = "0") int pidArchivo,
											@RequestParam(value = "solicitud", required = false) String psolicitud,
											@RequestParam(value = "nroExpediente", required = false) String pnroExpediente,
											@RequestParam(value = "nombre", required = false) String pnombre,
											@RequestParam(value = "ruc", required = false) String pruc,
											@RequestParam(value = "partida", required = false) String ppartida,
											@RequestParam(value = "repLegal", required = false) String prepLegal,
											@RequestParam(value = "domicio", required = false) String pdomicio,
											@RequestParam(value = "corElect1", required = false) String pcorElect1,
											@RequestParam(value = "corElect2", required = false) String pcorElect2,
											@RequestParam(value = "usuIngreso", required = false) String pusuIngreso,
											@RequestParam(value = "ipIngreso", required = false) String pipIngreso,
											@RequestParam(value = "usuModifica", required = false) String pusuModifica,
											@RequestParam(value = "ipModifica", required = false) String pipModifica
											) {

		System.out.println(" /pcmConsultorGuardar/modCasaDatos start");
		
	    // 디버깅 로그 추가
	    System.out.println("modCasaDatos Received uploadControlName: " + uploadControlName);
	    System.out.println("modCasaDatos Received idEstudio: " + pidEstudio + " pidRegistro= " + pidRegistro + " pidArchivo=" + pidArchivo);
	     
		PcmConsultorVO consultoraDatos = new PcmConsultorVO();
		
		Long gidRegistro = (long) 0; // 업로드 처리 후 생성된 gidRegistro 값을 설정
		
		try {
        
			// 업로드 완료에 대한 구분
            if (!"finalUpload".equals(uploadControlName)) {
            	
	        	String directory = request.getSession().getServletContext().getRealPath("/common/data/"); // 서버 상대경로
				int maxPostSize = 2147482624; // bytes
	
				System.out.println("########### modCasaDatos request :" + request + " response :" + response + " maxPostSize :" + maxPostSize + " directory :" + directory);
				
				InnorixUpload uploader = new InnorixUpload(request, response, maxPostSize, directory);
	
				String _orig_filename = uploader.getParameter("_orig_filename"); // 원본 파일명
				String _new_filename = uploader.getParameter("_new_filename"); // 저장 파일명
				String _filepath = uploader.getParameter("_filepath"); // 파일 저장경로
				
				System.out.println("########### modCasaDatos _orig_filename :" + _orig_filename + " _new_filename :" + _new_filename + " _filepath :" + _filepath );
				
				uploader.run();
	
				// 개별파일 업로드 완료
				if (uploader.isUploadDone()) {
	
					String inputId   =  uploader.getParameter("inputId");
					
					Long idRegistro = Long.valueOf(uploader.getParameter("idRegistro"));
					String solicitud = uploader.getParameter("solicitud");
					String nroExpediente = uploader.getParameter("nroExpediente");
					String nombre = uploader.getParameter("nombre");
					String ruc = uploader.getParameter("ruc");
					String partida = uploader.getParameter("partida");
					String repLegal = uploader.getParameter("repLegal");
					String domicio = uploader.getParameter("domicio");
					String corElect1 = uploader.getParameter("corElect1");
					String corElect2 = uploader.getParameter("corElect2");
					String nombreProyecto = (uploader.getParameter("nombreProyecto") == null) ? "NOPROY" : uploader.getParameter("nombreProyecto");
					String usuIngreso = uploader.getParameter("usuIngreso");
					String ipIngreso = uploader.getParameter("ipIngreso");
					String usuModifica = uploader.getParameter("usuModifica");
					String ipModifica = uploader.getParameter("ipModifica");
					
					System.out.println("########## modCasaDatos uploader idRegistro: " + uploader.getParameter("idRegistro"));
					System.out.println("########## modCasaDatos uploadControlName: " + uploadControlName + " nombreProyecto :" + nombreProyecto );
		        	System.out.println("########## modCasaDatos idRegistro:" + idRegistro + " solicitud:" + solicitud + " nroExpediente:" + nroExpediente + " nombre:" + nombre + " ruc: " + ruc + " partida: " + partida);
		        	System.out.println("########## modCasaDatos repLegal:" + repLegal + " domicio:" + domicio + " corElect1:" + corElect1 + " corElect2:" + corElect2 + " usuIngreso: " + usuIngreso + " ipIngreso: " + ipIngreso+ " usuModifica: " + usuModifica + " ipIngreso: " + ipModifica);
		        	
		        	
		        	if(idRegistro == null || String.valueOf(idRegistro) == "" || idRegistro == 0) {
		        		idRegistro = getMaxIdRegistro(ruc);
		        		gidRegistro = idRegistro;
		        		
		        		System.out.println("modCasaDatos after idRegistro: " + idRegistro);
		        	}
		        	
		        	consultoraDatos.setIdRegistro(idRegistro);
		        	consultoraDatos.setIdConsultor(-1);
		        	consultoraDatos.setIdArchivo(pidArchivo);
		        	consultoraDatos.setNroExpediente(nroExpediente);
		        	consultoraDatos.setNombre(nombre);
		        	consultoraDatos.setDomicio(domicio);
		        	consultoraDatos.setRepLegal(repLegal);
		        	consultoraDatos.setRuc(ruc);
		        	consultoraDatos.setPartida(partida);
		        	consultoraDatos.setCorElect1(corElect1);
		        	consultoraDatos.setCorElect2(corElect2);
		        	consultoraDatos.setNombreProyecto(nombreProyecto);
		        	consultoraDatos.setUsuIngreso(usuIngreso);
		        	consultoraDatos.setIpIngreso(ipIngreso);
		        	consultoraDatos.setUsuModifica(usuModifica);
		        	consultoraDatos.setIpModifica(ipModifica);
		        	
	                System.out.println("File uploaded for control: " + uploadControlName);
					
		        	consultoraDatos.setSolicitud(solicitud);
	
		        	Path path = Paths.get(directory, _new_filename); // Server path + stored file name

		        	byte[] fileBytes = null;
		        	
		        	// Using InputStream to read file content
		        	try (InputStream inputStream = Files.newInputStream(path)) {
		        	    // Read all bytes from the inputStream into a byte array
		        	    ByteArrayOutputStream buffer = new ByteArrayOutputStream();
		        	    byte[] temp = new byte[1024]; // Buffer size for reading
		        	    int bytesRead;

		        	    while ((bytesRead = inputStream.read(temp)) != -1) {
		        	        buffer.write(temp, 0, bytesRead);
		        	    }

		        	    fileBytes = buffer.toByteArray(); // Convert to byte array
		        	    // fileBytes now contains the file content
		        	} catch (IOException e) {
		        	    e.printStackTrace(); // Handle the exception
		        	}

					
					
					System.out.println("modCasaDatos uploadControlName = " + uploadControlName);
					
					saveConsultReqFileToDB(_orig_filename, inputId, fileBytes, consultoraDatos, request);
					
					// 서버에서 파일 삭제
					Files.delete(path);
				}
				
				System.out.println("========== file transfer " + System.currentTimeMillis() + " ==========");
				System.out.println("_orig_filename \t = " + _orig_filename);
				System.out.println("_new_filename \t = " + _new_filename);
				System.out.println("_filepath \t = " + _filepath);
				
				System.out.println("##### after gidRegistro: " + gidRegistro);
				
				if(gidRegistro != null && String.valueOf(gidRegistro) != "" && String.valueOf(gidRegistro) != "0") {
					uploader.setCustomValue("gidRegistro", String.valueOf(gidRegistro) ); // 클라이언트측으로 전달할 key,value값 설정 
					uploader.sendCustomValue();							 // 클라이언트측으로 key, value값 전달
				}
				
            }else if( "finalUpload".equals(uploadControlName) ) {
            	
				Long idRegistro = Long.valueOf(pidRegistro);
				String solicitud = psolicitud;
				String nroExpediente = pnroExpediente;
				String nombre = pnombre;
				String ruc = pruc;
				String partida = ppartida;
				String repLegal = prepLegal;
				String domicio = pdomicio;
				String corElect1 = pcorElect1;
				String corElect2 = pcorElect2;
				String usuIngreso = pusuIngreso;
				String ipIngreso = pipIngreso;
				String usuModifica = pusuModifica;
				String ipModifica = pipModifica;
				
				System.out.println("########## pidRegistro: " + pidRegistro);
				System.out.println("########## uploadControlName: " + uploadControlName);// + " idEstudio :" + idEstudio );
	        	System.out.println("########## pidRegistro:" + pidRegistro + " psolicitud:" + psolicitud + " pnroExpediente:" + pnroExpediente + " pnombre:" + pnombre + " pruc: " + pruc + " ppartida: " + ppartida);
	        	System.out.println("########## prepLegal:" + prepLegal + " pdomicio:" + pdomicio + " pcorElect1:" + pcorElect1 + " pcorElect2:" + pcorElect2 + " pusuIngreso: " + pusuIngreso + " pipIngreso: " + pipIngreso+ " pusuModifica: " + pusuModifica + " pipModifica: " + pipModifica);
	        	
	        	
	        	if(idRegistro == null || String.valueOf(idRegistro) == "" || idRegistro == 0) {
	        		idRegistro = getMaxIdRegistro(ruc);
	        		System.out.println("after idRegistro: " + idRegistro);
	        	}
	        	
	        	consultoraDatos.setIdRegistro(idRegistro);
	        	consultoraDatos.setNroExpediente(nroExpediente);
	        	consultoraDatos.setNombre(nombre);
	        	consultoraDatos.setDomicio(domicio);
	        	consultoraDatos.setRepLegal(repLegal);
	        	consultoraDatos.setRuc(ruc);
	        	consultoraDatos.setPartida(partida);
	        	consultoraDatos.setCorElect1(corElect1);
	        	consultoraDatos.setCorElect2(corElect2);
	        	consultoraDatos.setUsuIngreso(usuIngreso);
	        	consultoraDatos.setIpIngreso(ipIngreso);
	        	consultoraDatos.setUsuModifica(usuModifica);
	        	consultoraDatos.setIpModifica(ipModifica);
            }
            
			// CORS 관련 헤더 추가
			response.setHeader("Access-Control-Allow-Origin", "*");
			response.setHeader("Access-Control-Allow-Credentials", "true");
			response.setHeader("Access-Control-Allow-Methods", "POST, OPTIONS");
			response.setHeader("Access-Control-Allow-Headers",
					"Authorization,DNT,X-Mx-ReqToken,Keep-Alive,User-Agent,X-Requested-With,If-Modified-Since,Cache-Control,Content-Type");
			
		} catch (Exception e) {
			 e.printStackTrace();
		}
		
	}
	
	//-----------------------------------------------
	/**
	* Method for Uploading Consultant-Related Files
	* @param request
	* @param response
	* @param el
	* @param idEstudio
	* @param idRegistro
	* @param idConsultor
	* @param nombre
	* @param apelPat
	* @param apelMat
	* @param especial
	* @param dni
	* @param idColegia
	* @param ruc
	* @param expEmpresa
	* @param empresaSeq
	* @param fechaIni
	* @param fechaFin
	* @param anosExp
	* @param proyectoSeq
	* @param nombreProyecto
	* @param idColeArchivo
	* @param idDniArchivo
	* @param idCertArchivo
	* @param idDdjjArchivo
	* @param usuIngreso
	* @param ipIngreso
	* @param usuModifica
	* @param ipModifica
	*/
	@CrossOrigin
	@RequestMapping(value = "/pcmConsultProfGuardar/upload", method = RequestMethod.POST)
	synchronized public void handleProfUpload(
											HttpServletRequest request, 
											HttpServletResponse response,
											@RequestParam("el") String uploadControlName,
											@RequestParam(value = "idEstudio", required = false, defaultValue = "0") Integer pidEstudio, // Integer로 변경하여 null 허용
											@RequestParam(value = "idRegistro", required = false, defaultValue = "0") Long pidRegistro,
											@RequestParam(value = "idConsultor", required = false, defaultValue = "0") Integer pidConsultor,
											@RequestParam(value = "nombres", required = false) String pnombres,
											@RequestParam(value = "apelPat", required = false) String papelPat,
											@RequestParam(value = "apelMat", required = false) String papelMat,
											@RequestParam(value = "especial", required = false) String pespecial,
											@RequestParam(value = "dni", required = false) String pdni,
											@RequestParam(value = "idColegia", required = false) String pidColegia,
											@RequestParam(value = "ruc", required = false) String pruc,
											@RequestParam(value = "expEmpresa", required = false) String pexpEmpresa,
											@RequestParam(value = "empresaSeq", required = false) String empresaSeq,
											@RequestParam(value = "fechaIni", required = false) String pfechaIni,
											@RequestParam(value = "fechaFin", required = false) String pfechaFin,
											@RequestParam(value = "anosExp", required = false) String panosExp,
											@RequestParam(value = "proyectoSeq", required = false, defaultValue = "0") Integer pproyectoSeq,
											@RequestParam(value = "nombreProyecto", required = false, defaultValue = "NOPROY") String pnombreProyecto,
											@RequestParam(value = "idColeArchivo", required = false, defaultValue = "0") Integer pidColeArchivo,
											@RequestParam(value = "idDniArchivo", required = false, defaultValue = "0")  Integer pidDniArchivo,
											@RequestParam(value = "idCertArchivo", required = false, defaultValue = "0") Integer pidCertArchivo,
											@RequestParam(value = "idDdjjArchivo", required = false, defaultValue = "0") Integer pidDdjjArchivo,
											@RequestParam(value = "usuIngreso", required = false) String pusuIngreso,
											@RequestParam(value = "ipIngreso", required = false) String pipIngreso,
											@RequestParam(value = "usuModifica", required = false) String pusuModifica,
											@RequestParam(value = "ipModifica", required = false) String pipModifica
											) {

		System.out.println(" /pcmConsultProfGuardar/upload start");
		
	    // 디버깅 로그 추가
	    System.out.println("Received uploadControlName: " + uploadControlName + " idEstudio: " + pidEstudio);
	    
		PcmConsultorVO consultorProfDatos = new PcmConsultorVO();
		
		Long gidRegistro = (long) 0; // 업로드 처리 후 생성된 gidRegistro 값을 설정
		int  gidConsultor = 0;
		
		int  gidArchivo = 0;
		
		try {
        
			// 업로드 완료에 대한 구분
            if (!"finalUpload".equals(uploadControlName)) {
            	
	        	String directory = request.getSession().getServletContext().getRealPath("/common/data/"); // 서버 상대경로
				int maxPostSize = 2147482624; // bytes
	
				System.out.println("########### request :" + request + " response :" + response + " maxPostSize :" + maxPostSize + " directory :" + directory);
				
				InnorixUpload uploader = new InnorixUpload(request, response, maxPostSize, directory);
	
				String _orig_filename = uploader.getParameter("_orig_filename"); // 원본 파일명
				String _new_filename = uploader.getParameter("_new_filename"); // 저장 파일명
				String _filepath = uploader.getParameter("_filepath"); // 파일 저장경로
				
				System.out.println(" _orig_filename :" + _orig_filename + " _new_filename :" + _new_filename + " _filepath :" + _filepath );
				
				uploader.run();
	
				// 개별파일 업로드 완료
				if (uploader.isUploadDone()) {
	
					String inputId   =  uploader.getParameter("inputId");
					
					Long idRegistro  = Long.valueOf(uploader.getParameter("idRegistro"));
					int  idConsultor = Integer.valueOf(uploader.getParameter("idConsultor"));
					String nombres = uploader.getParameter("nombres");
					String apelPat = uploader.getParameter("apelPat");
					String apelMat = uploader.getParameter("apelMat");
					String especial = uploader.getParameter("especial");
					String dni = uploader.getParameter("dni");
					String ruc = uploader.getParameter("ruc");
					int    proyectoSeq = (uploader.getParameter("proyectoSeq") == null) ? 0 : Integer.valueOf(uploader.getParameter("proyectoSeq"));
					String nombreProyecto = uploader.getParameter("nombreProyecto");
					
					String expEmpresa = uploader.getParameter("expEmpresa");
					
					String usuIngreso = uploader.getParameter("usuIngreso");
					String ipIngreso = uploader.getParameter("ipIngreso");
					String usuModifica = uploader.getParameter("usuModifica");
					String ipModifica = uploader.getParameter("ipModifica");
					
					System.out.println("########## uploader idRegistro: " + uploader.getParameter("idRegistro"));
					System.out.println("########## uploadControlName: " + uploadControlName + " expEmpresa :" + expEmpresa );
		        	System.out.println("########## idRegistro:" + idRegistro + " idConsultor:" + idConsultor + " nombres:" + nombres + " apelPat: " + apelPat + " apelMat: " + apelMat + " especial: " + especial + " dni: " + dni  + " ruc: " + ruc   );
		        	System.out.println("########## proyectoSeq: " + proyectoSeq + " nombreProyecto: " + nombreProyecto + " pproyectoSeq: " + pproyectoSeq + " pnombreProyecto: " + pnombreProyecto);
		        	System.out.println("########## usuIngreso: " + usuIngreso + " ipIngreso: " + ipIngreso+ " usuModifica: " + usuModifica + " ipModifica: " + ipModifica);
		        	
		        	if(idRegistro == null || String.valueOf(idRegistro) == "" || idRegistro == 0) {
		        		idRegistro  = getMaxIdRegistro(ruc);
		        		gidRegistro = idRegistro;
		        		System.out.println("after idRegistro: " + idRegistro);
		        	}
		        	
		        	if(String.valueOf(idConsultor) == "" || idConsultor == 0) {
		        		idConsultor = getMaxIdConsultor(idConsultor,dni);
		        		gidConsultor = idConsultor;		        		
		        		System.out.println("after idConsultor: " + idConsultor);
		        	}else {
		        		gidConsultor = idConsultor;
		        	}
		        	
		        	if(nombreProyecto ==  null || nombreProyecto == "") {
		        		nombreProyecto = "NOPROY";
		        	}

		        	consultorProfDatos.setIdRegistro(idRegistro);
		        	consultorProfDatos.setIdConsultor(gidConsultor);
		        	consultorProfDatos.setNombres(nombres);
		        	consultorProfDatos.setApelPat(apelPat);
		        	consultorProfDatos.setApelMat(apelMat);
		        	consultorProfDatos.setEspecialidad(especial);
		        	consultorProfDatos.setDni(dni);
		        	consultorProfDatos.setRuc(ruc);
		        	
		        	consultorProfDatos.setProyectoSeq(proyectoSeq);
		        	consultorProfDatos.setNombreProyecto(nombreProyecto);
		        	consultorProfDatos.setExpEmpresa(expEmpresa);
		        	
		        	consultorProfDatos.setUsuIngreso(usuIngreso);
		        	consultorProfDatos.setIpIngreso(ipIngreso);
		        	consultorProfDatos.setUsuModifica(usuModifica);
		        	consultorProfDatos.setIpModifica(ipModifica);
		        	
	                System.out.println("File uploaded for control: " + uploadControlName);
	
					// 서버에 저장된 파일의 데이터
					Path path = Paths.get(directory, _new_filename); // 서버경로 + 저장 파일명
					byte[] fileBytes = Files.readAllBytes(path);
					
					System.out.println("uploadControlName = " + uploadControlName);
					
					gidArchivo = saveConsultProfFileToDB(_orig_filename, inputId, uploadControlName, fileBytes, consultorProfDatos, request);
					System.out.println("##### /pcmConsultProfGuardar/upload after gidArchivo: " + gidArchivo);
					
					// 서버에서 파일 삭제
					Files.delete(path);
				}
				
				System.out.println("========== file transfer " + System.currentTimeMillis() + " ==========");
				System.out.println("_orig_filename \t = " + _orig_filename);
				System.out.println("_new_filename \t = " + _new_filename);
				System.out.println("_filepath \t = " + _filepath);
				
				
	        	if(pidRegistro == null || String.valueOf(pidRegistro) == "" || pidRegistro == 0) {
	        		System.out.println("########## /pcmConsultProfGuardar/upload uploadControlName: " + uploadControlName + " gidArchivo: " + gidArchivo);		
					uploader.setCustomValue("gidRegistro", String.valueOf(gidRegistro) ); // 클라이언트측으로 전달할 key,value값 설정 
	        	}
	        	
				if(String.valueOf(gidConsultor) != "" && String.valueOf(gidConsultor) != "0") {
					System.out.println("##########  /pcmConsultProfGuardar/upload uploadControlName: " + uploadControlName + " gidArchivo: " + gidArchivo);		
					uploader.setCustomValue("gidConsultor", String.valueOf(gidConsultor) ); // 클라이언트측으로 전달할 key,value값 설정 
				}
				
				if("coleCtrl".equals(uploadControlName)) {// && gidArchivo != 0 && String.valueOf(gidArchivo) != "0" ) {
					System.out.println("########## /pcmConsultProfGuardar/upload uploadControlName: " + uploadControlName + " gidArchivo: " + gidArchivo);		
					uploader.setCustomValue("gidColeArchivo", String.valueOf(gidArchivo) ); // 클라이언트측으로 전달할 key,value값 설정 
				}

				if("dniCtrl".equals(uploadControlName)) {// && gidArchivo != 0 && String.valueOf(gidArchivo) != "0" ) {
					System.out.println("########## /pcmConsultProfGuardar/upload uploadControlName: " + uploadControlName + " gidArchivo: " + gidArchivo);					
					uploader.setCustomValue("gidDniArchivo", String.valueOf(gidArchivo) ); // 클라이언트측으로 전달할 key,value값 설정 
				}

				if("certCtrl".equals(uploadControlName)) {// && gidArchivo != 0 && String.valueOf(gidArchivo) != "0" ) {
					System.out.println("########## /pcmConsultProfGuardar/upload uploadControlName: " + uploadControlName + " gidArchivo: " + gidArchivo);		
					uploader.setCustomValue("gidCertArchivo", String.valueOf(gidArchivo) ); // 클라이언트측으로 전달할 key,value값 설정 
				}
				
				if("ddjjCtrl".equals(uploadControlName)) {// && gidArchivo != 0 && String.valueOf(gidArchivo) != "0" ) {
					System.out.println("########## /pcmConsultProfGuardar/upload uploadControlName: " + uploadControlName + " gidArchivo: " + gidArchivo);		
					uploader.setCustomValue("gidDdjjArchivo", String.valueOf(gidArchivo) ); // 클라이언트측으로 전달할 key,value값 설정 
				}

				uploader.sendCustomValue();
				
            }else if( "finalUpload".equals(uploadControlName) ) {
            	
				Long idRegistro = Long.valueOf(pidRegistro);
				int  idConsultor = Integer.valueOf(pidConsultor);
				String nombres = pnombres;
				String apelPat = papelPat;
				String apelMat = papelMat;
				String especial = pespecial;
				String dni = pdni;
				String idColegia = pidColegia;
				String ruc = pruc;
				String expEmpresa = pexpEmpresa;
				
				int idColeArchivo = pidColeArchivo;
				int idDniArchivo = pidDniArchivo;
				int idCertArchivo = pidCertArchivo;
				int idDdjjArchivo = pidDdjjArchivo;
				
				String usuIngreso = pusuIngreso;
				String ipIngreso = pipIngreso;
				String usuModifica = pusuModifica;
				String ipModifica = pipModifica;

				System.out.println("########## uploadControlName: " + uploadControlName);// + " idEstudio :" + idEstudio );
				System.out.println("########## pidConsultor: " + pidConsultor);
	        	System.out.println("########## pidRegistro:" + pidRegistro + " pnombres:" + pnombres + " papelPat: " + papelPat + " papelMat: " + papelMat + " pespecial: " + pespecial + " pdni: " + pdni + " pidColegia: " + pidColegia + " pruc: " + pruc);
	        	System.out.println("########## pidColeArchivo: "+ pidColeArchivo + " pidDniArchivo: "+ pidDniArchivo + " pidCertArchivo: "+ pidCertArchivo + " pidDdjjArchivo:" + pidDdjjArchivo + " pexpEmpresa: " + pexpEmpresa);
	        	System.out.println("########## pfechaIni: " + pfechaIni + " pfechaFin: " + pfechaFin+ " panosExp: " + panosExp);
	        	
	        	System.out.println("########## pusuIngreso: " + pusuIngreso + " pipIngreso: " + pipIngreso+ " pusuModifica: " + pusuModifica + " pipModifica: " + pipModifica);
	        	
	        	
	        	if(String.valueOf(idConsultor) == "" || idConsultor == 0) {
	        		idConsultor = getMaxIdConsultor(idConsultor,dni);
	        		System.out.println("after idConsultor: " + idConsultor + " dni=" + dni);
	        	}
	        	
	        	consultorProfDatos.setIdRegistro(idRegistro);
	        	consultorProfDatos.setIdConsultor(idConsultor);
	        	consultorProfDatos.setNombres(nombres);
	        	consultorProfDatos.setIdColeArchivo(idColeArchivo);
	        	consultorProfDatos.setApelPat(apelPat);
	        	consultorProfDatos.setApelMat(apelMat);
	        	consultorProfDatos.setEspecialidad(especial);
	        	consultorProfDatos.setDni(dni);
	        	consultorProfDatos.setIdColegia(idColegia);
	        	consultorProfDatos.setIdDniArchivo(idDniArchivo);
	        	consultorProfDatos.setRuc(ruc);
	        	consultorProfDatos.setExpEmpresa(expEmpresa);
	        	consultorProfDatos.setFechaIni(pfechaIni);
	        	consultorProfDatos.setFechaFin(pfechaFin);
	        	consultorProfDatos.setAnosExp(panosExp);
	        	consultorProfDatos.setIdCertArchivo(idCertArchivo);
	        	consultorProfDatos.setIdDdjjArchivo(idDdjjArchivo);
	        	
	        	consultorProfDatos.setUsuIngreso(usuIngreso);
	        	consultorProfDatos.setIpIngreso(ipIngreso);
	        	consultorProfDatos.setUsuModifica(usuModifica);
	        	consultorProfDatos.setIpModifica(ipModifica);
	        	
            	pcmConsultorService.mergeConsultoraProf(consultorProfDatos); // 최종 한 번만 실행
            	
            }
            
			// CORS 관련 헤더 추가
			response.setHeader("Access-Control-Allow-Origin", "*");
			response.setHeader("Access-Control-Allow-Credentials", "true");
			response.setHeader("Access-Control-Allow-Methods", "POST, OPTIONS");
			response.setHeader("Access-Control-Allow-Headers",
					"Authorization,DNT,X-Mx-ReqToken,Keep-Alive,User-Agent,X-Requested-With,If-Modified-Since,Cache-Control,Content-Type");
			
		} catch (Exception e) {
			 e.printStackTrace();
		}
		
	}
	
	//-----------------------------------------------
	/**
	* Method for Inserting or Updating Consultant-Related Files
	* @param filename
	* @param inputId
	* @param uploadControlName
	* @param fileBytes
	* @param consultoraDatos
	* @param request
	* @return int
	*/
	private int saveConsultProfFileToDB(
									String filename, 
									String inputId,
									String uploadControlName,
									byte[] fileBytes, 
									PcmConsultorVO consultorProfDatos,
									HttpServletRequest request) {

		System.out.println("###### saveConsultProfFileToDB inputId: " + inputId);
		
    	PcmConsultorFileVO blob = new PcmConsultorFileVO();
        blob.setIdRegistro(consultorProfDatos.getIdRegistro());
        blob.setIdConsultor(consultorProfDatos.getIdConsultor());
        blob.setExpEmpresa(consultorProfDatos.getExpEmpresa());
        
        blob.setArchivoTipo(inputId); // input file id
        
        blob.setIdArchivo(consultorProfDatos.getIdArchivo());
        
        System.out.println(" blob.getIdRegistro(): " + blob.getIdRegistro());
        
    	if(blob.getIdArchivo() == null || String.valueOf(blob.getIdArchivo()) == "" || String.valueOf(blob.getIdArchivo()) == "0") {
    		blob.setIdArchivo(getMaxIdArchivo(blob));
    	}

    	if(blob.getIdArchivoSeq() == null || String.valueOf(blob.getIdArchivoSeq()) == "" || String.valueOf(blob.getIdArchivoSeq()) == "0") {
    		blob.setIdArchivoSeq(getMaxArchivoSeq(blob));
    	}
    	
    	System.out.println("after blob.getIdArchivo(): " + blob.getIdArchivo() + " blob.getIdArchivoSeq():" + blob.getIdArchivoSeq());
    	System.out.println("consultorProfDatos.getProyectoSeq(): " + consultorProfDatos.getProyectoSeq() + " consultorProfDatos.getNombreProyecto():" + consultorProfDatos.getNombreProyecto());
    	
        blob.setNombreArchivo(filename);
        
        blob.setProyectoSeq(consultorProfDatos.getProyectoSeq());
        blob.setNombreProyecto(consultorProfDatos.getNombreProyecto());
        
        blob.setUsuIngreso(consultorProfDatos.getUsuIngreso());
        blob.setIpIngreso(consultorProfDatos.getIpIngreso());
        
        blob.setUsuModifica(consultorProfDatos.getUsuModifica());
        blob.setIpModifica(consultorProfDatos.getIpModifica());

        // MyBatis나 다른 데이터베이스 작업에 byte[] 사용
        blob.setDocumento(fileBytes);

        int idArchivo = 0;
        
       	idArchivo = blob.getIdArchivo();
        
        
        try {
        	System.out.println("################################################# saveConsultProfFileToDB mergeConsultoraDocumentoBlob");
        	pcmConsultorService.mergeConsultoraDocumentoBlob(blob);
        } catch (Exception e) {
        	System.out.println("################################################# saveConsultProfFileToDB mergeConsultoraDocumentoBlob Exception");
            e.printStackTrace();
        } finally {
        	try {
        		System.out.println("################################################# saveConsultProfFileToDB updateMergeFile");
        		updateMergeFile(blob);
        	}catch(SQLException e) {
        		e.printStackTrace();
        	} catch (Exception e) {
                e.printStackTrace();
            } 
        }
        
        return idArchivo;
	}

	//-----------------------------------------------
	/**
	* Method for Updating Consultant-Related Files
	* @param PcmConsultorFileVO
	* @return int
	* @throws SQLException
	*/
	public void updateMergeFile(PcmConsultorFileVO blob) throws SQLException {
		String updateSql = 
				        " UPDATE DGAAMW.T_NPCPMD_CONSULTORA_DOCUMENTO_BLOB " +
			    	    " SET DOCUMENTO = ?, FEC_MODIFICA = SYSDATE, IP_MODIFICA = ? " +
			    	    " WHERE ID_REGISTRO = ? AND ID_CONSULTOR = ? AND ARCHIVO_TIPO = ? AND ID_ARCHIVO = ? AND ID_ARCHIVO_SEQ = ? ";

		Connection conn = dataSource.getConnection();
		conn.setAutoCommit(true);

		try (PreparedStatement pstmt = conn.prepareStatement(updateSql)) {

			// set the parameters
            pstmt.setBytes(1, blob.getDocumento()); // DOCUMENTO (BLOB) for the UPDATE part
            pstmt.setString(2, blob.getIpModifica()); // ID_REGISTRO for the source part
            pstmt.setFloat(3, blob.getIdRegistro()); // ARCHIVO_TIPO for the source part
            
            System.out.println("updateMergeFile blob.getIdConsultor(): " + blob.getIdConsultor());
            
            if(blob.getIdConsultor() == null || blob.getIdConsultor() == 0) {
            	pstmt.setInt(4, -1);
            }else {
            	pstmt.setInt(4, blob.getIdConsultor());
            }
            pstmt.setString(5, blob.getArchivoTipo());
            pstmt.setInt(6, blob.getIdArchivo());
            pstmt.setInt(7, blob.getIdArchivoSeq());
            
            // 설정된 쿼리와 파라미터 출력
            // 파라미터가 설정된 쿼리 출력
            String queryWithParams = updateSql
                    .replaceFirst("\\?", String.valueOf(blob.getDocumento()))
                    .replaceFirst("\\?", "'" + blob.getIpModifica() + "'")
                    .replaceFirst("\\?", "" + blob.getIdRegistro() + "")
                    .replaceFirst("\\?", "" + blob.getIdConsultor() + "")
                    .replaceFirst("\\?", "'" + String.valueOf(blob.getArchivoTipo()) + "'")
            		.replaceFirst("\\?", "" + String.valueOf(blob.getIdArchivo()) + "")
            		.replaceFirst("\\?", "" + String.valueOf(blob.getIdArchivoSeq()) + "");
            
            System.out.println("updateMergeFile PreparedStatement Query: " + queryWithParams);
            // Execute the statement
            pstmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
            throw new RuntimeException("DGAAMW.T_NPCPMD_CONSULTORA_DOCUMENTO_BLOB DOCUMENTO Update error", e);
        }finally{
        	conn.close();
        }	
    }
	
	//-----------------------------------------------
	/**
	* Method for Uploading Consultant-Related Files
	* @param request
	* @param response
	* @param el
	* @param idEstudio
	* @param idRegistro
	* @param idConsultor
	* @param dni
	* @param expEmpresa
	* @param empresaSeq
	* @param fechaIni
	* @param fechaFin
	* @param anosExp
	* @param idCertArchivo
	* @param idDdjjArchivo
	* @param usuIngreso
	* @param ipIngreso
	* @param usuModifica
	* @param ipModifica
	*/
	@CrossOrigin
	@RequestMapping(value = "/pcmConsultProyectoGuardar/upload", method = RequestMethod.POST)
	synchronized public void handleProyectoUpload(
											HttpServletRequest request, 
											HttpServletResponse response,
											@RequestParam("el") String uploadControlName,
											@RequestParam(value = "idEstudio", required = false, defaultValue = "0") Integer pidEstudio, // Integer로 변경하여 null 허용
											@RequestParam(value = "idRegistro", required = false, defaultValue = "0") Long pidRegistro,
											@RequestParam(value = "idConsultor", required = false, defaultValue = "0") Integer pidConsultor,
											@RequestParam(value = "dni", required = false) String pdni,
											@RequestParam(value = "empresaSeq", required = false) Integer pempresaSeq,
											@RequestParam(value = "expEmpresa", required = false) String pexpEmpresa,
											@RequestParam(value = "proyectoSeq", required = false) Integer pproyectoSeq,
											@RequestParam(value = "fechaIni", required = false) String pfechaIni,
											@RequestParam(value = "fechaFin", required = false) String pfechaFin,
											@RequestParam(value = "anosExp", required = false) String panosExp,											
											@RequestParam(value = "idCertArchivo", required = false, defaultValue = "0") Integer pidCertArchivo,
											@RequestParam(value = "idDdjjArchivo", required = false, defaultValue = "0") Integer pidDdjjArchivo,
											@RequestParam(value = "usuIngreso", required = false) String pusuIngreso,
											@RequestParam(value = "ipIngreso", required = false) String pipIngreso,
											@RequestParam(value = "usuModifica", required = false) String pusuModifica,
											@RequestParam(value = "ipModifica", required = false) String pipModifica
											) {

		System.out.println(" /pcmConsultProyectoGuardar/upload start");
		
	    // 디버깅 로그 추가
	    System.out.println(" /pcmConsultProyectoGuardar/upload uploadControlName: " + uploadControlName + " idEstudio: " + pidEstudio);
	    
		PcmConsultorVO consultorProfDatos = new PcmConsultorVO();
		
		Long gidRegistro = (long) 0; // 업로드 처리 후 생성된 gidRegistro 값을 설정
		int  gidConsultor = 0;
		
		int  gidArchivo = 0;
		
		try {
        
			// 업로드 완료에 대한 구분
            if (!"finalUpload".equals(uploadControlName)) {
            	
	        	String directory = request.getSession().getServletContext().getRealPath("/common/data/"); // 서버 상대경로
				int maxPostSize = 2147482624; // bytes
	
				System.out.println("########### request :" + request + " response :" + response + " maxPostSize :" + maxPostSize + " directory :" + directory);
				
				InnorixUpload uploader = new InnorixUpload(request, response, maxPostSize, directory);
	
				String _orig_filename = uploader.getParameter("_orig_filename"); // 원본 파일명
				String _new_filename = uploader.getParameter("_new_filename"); // 저장 파일명
				String _filepath 	 = uploader.getParameter("_filepath"); // 파일 저장경로
				String _el           = uploader.getParameter("el");              // 컨트롤 엘리먼트 ID
				
				System.out.println(" pcmConsultProyectoGuardar _el :"+_el+" _orig_filename :" + _orig_filename + " _new_filename :" + _new_filename + " _filepath :" + _filepath );
				
				uploader.run();
	
				// 개별파일 업로드 완료
				if (uploader.isUploadDone()) {
	
					System.out.println("########## pcmConsultProyectoGuardar uploader.isUploadDone() pidRegistro : " + pidRegistro +"  pidConsultor :" + pidConsultor);
					
					String inputId   =  uploader.getParameter("inputId");
					
					Long idRegistro  = Long.valueOf(uploader.getParameter("idRegistro"));
					int  idConsultor = Integer.valueOf(uploader.getParameter("idConsultor"));
					String dni        = uploader.getParameter("dni");
					String ruc		  = uploader.getParameter("ruc");
					int empresaSeq	  = Integer.valueOf(uploader.getParameter("empresaSeq"));
					String expEmpresa = uploader.getParameter("expEmpresa");
					String usuIngreso = uploader.getParameter("usuIngreso");
					String ipIngreso = uploader.getParameter("ipIngreso");
					String usuModifica = uploader.getParameter("usuModifica");
					String ipModifica = uploader.getParameter("ipModifica");
					String detPartFileYn  = uploader.getParameter("detPartFileYn");
					int    rowcnt         = (uploader.getParameter("rowcnt") == null) ? 0 : Integer.valueOf(uploader.getParameter("rowcnt"));
					int    proyectoSeq    = (uploader.getParameter("proyectoSeq") == null) ? 0 : Integer.valueOf(uploader.getParameter("proyectoSeq"));
					String expProyecto    = (uploader.getParameter("expProyecto") == null) ? "" : uploader.getParameter("expProyecto");
					String nombreProyecto = (uploader.getParameter("nombreProyecto") == null) ? "" : uploader.getParameter("nombreProyecto");
					
					String controlName = uploader.getParameter("controlName");
					
		        	if(idRegistro == null || String.valueOf(idRegistro) == "" || idRegistro == 0) {
		        		idRegistro  = getMaxIdRegistro(ruc);
		        		gidRegistro = idRegistro;
		        		System.out.println("after idRegistro: " + idRegistro);
		        	}
	
		        	if(String.valueOf(idConsultor) == "" || idConsultor == 0) {
		        		idConsultor = getMaxIdConsultor(idConsultor,dni);
		        		gidConsultor = idConsultor;		        		
		        		System.out.println("after idConsultor: " + idConsultor);
		        	}
		        	
		        	consultorProfDatos.setIdRegistro(idRegistro);
		        	consultorProfDatos.setIdConsultor(idConsultor);
		        	consultorProfDatos.setDni(dni);
		        	consultorProfDatos.setEmpresaSeq(empresaSeq);
		        	consultorProfDatos.setExpEmpresa(expEmpresa);

		        	consultorProfDatos.setUsuIngreso(usuIngreso);
		        	consultorProfDatos.setIpIngreso(ipIngreso);
		        	consultorProfDatos.setUsuModifica(usuModifica);
		        	consultorProfDatos.setIpModifica(ipModifica);
		        	
		        	consultorProfDatos.setIdArchivoTipo(inputId);
		        	consultorProfDatos.setDetPartFileYn(detPartFileYn);
		        	consultorProfDatos.setProyectoSeq(proyectoSeq);
		        	consultorProfDatos.setExpProyecto(expProyecto);
		        	consultorProfDatos.setNombreProyecto(nombreProyecto);

					System.out.println("########## uploader idRegistro: " + uploader.getParameter("idRegistro") + " controlName: " + controlName);
					System.out.println("########## uploadControlName: " + uploadControlName + " proyectoSeq :" + proyectoSeq + " nombreProyecto :" + nombreProyecto );
		        	System.out.println("########## idRegistro:" + idRegistro + " idConsultor:" + idConsultor + " dni: " + dni  + " expEmpresa: " + expEmpresa + " empresaSeq: " + empresaSeq  + " detPartFileYn: " + detPartFileYn );
		        	System.out.println("########## usuIngreso: " + usuIngreso + " ipIngreso: " + ipIngreso+ " usuModifica: " + usuModifica + " ipModifica: " + ipModifica);
		        	System.out.println("########## consultorProfDatos.getProyectoSeq(): " + consultorProfDatos.getProyectoSeq() + " consultorProfDatos.getNombreProyecto(): " + consultorProfDatos.getNombreProyecto());
		        	System.out.println("########## consultorProfDatos.getNombreProyecto(): " + consultorProfDatos.getNombreProyecto() );
	
					// 서버에 저장된 파일의 데이터
					Path path = Paths.get(directory, _new_filename); // 서버경로 + 저장 파일명
					byte[] fileBytes = Files.readAllBytes(path);
					
					System.out.println("File uploaded for control uploadControlName = " + uploadControlName + " rowcnt = " + rowcnt);
					
					gidArchivo = saveConsultProyectoFileToDB(_orig_filename, inputId, uploadControlName, fileBytes, consultorProfDatos, request);
					
					System.out.println("##### /pcmConsultProyectoGuardar/upload after gidArchivo: " + gidArchivo);

					// 서버에서 파일 삭제
					Files.delete(path);
				}
				
				System.out.println("========== file transfer " + System.currentTimeMillis() + " ==========");
				System.out.println("_orig_filename \t = " + _orig_filename);
				System.out.println("_new_filename \t = " + _new_filename);
				System.out.println("_filepath \t = " + _filepath);
				
				
	        	if(pidRegistro == null || String.valueOf(pidRegistro) == "" || pidRegistro == 0) {
					uploader.setCustomValue("gidRegistro", String.valueOf(gidRegistro) ); // 클라이언트측으로 전달할 key,value값 설정 
	        	}
	        	
				if(String.valueOf(gidConsultor) != "" && String.valueOf(gidConsultor) != "0") {
					uploader.setCustomValue("gidConsultor", String.valueOf(gidConsultor) ); // 클라이언트측으로 전달할 key,value값 설정 
				}
				
				
				if((uploadControlName).indexOf("proyCtrl") > -1) {// && gidArchivo != 0 && String.valueOf(gidArchivo) != "0" ) {
					System.out.println("########## 1 /pcmConsultProyectoGuardar/upload uploadControlName: " + uploadControlName + " gidArchivo: " + gidArchivo);					
					uploader.setCustomValue("gidProyArchivo", String.valueOf(gidArchivo) ); // 클라이언트측으로 전달할 key,value값 설정
				}
				
				if("ddjjCtrl".equals(uploadControlName) && gidArchivo != 0 && String.valueOf(gidArchivo) != "0" ) {
					uploader.setCustomValue("gidDdjjArchivo", String.valueOf(gidArchivo) ); // 클라이언트측으로 전달할 key,value값 설정 
				}
				
				if("certCtrl".equals(uploadControlName) && gidArchivo != 0 && String.valueOf(gidArchivo) != "0" ) {
					uploader.setCustomValue("gidCertArchivo", String.valueOf(gidArchivo) ); // 클라이언트측으로 전달할 key,value값 설정 
				}

				uploader.sendCustomValue();
            }
            
			// CORS 관련 헤더 추가
			response.setHeader("Access-Control-Allow-Origin", "*");
			response.setHeader("Access-Control-Allow-Credentials", "true");
			response.setHeader("Access-Control-Allow-Methods", "POST, OPTIONS");
			response.setHeader("Access-Control-Allow-Headers",
					"Authorization,DNT,X-Mx-ReqToken,Keep-Alive,User-Agent,X-Requested-With,If-Modified-Since,Cache-Control,Content-Type");
			
		} catch (Exception e) {
			 e.printStackTrace();
		}
		
	}
	
	//-----------------------------------------------
	/**
	* Method for Uploading Files Related to Projects Handled by the Consultant
	* @param payload
	* @param request
	* @param response
	* @throws IOException
	*/
	@CrossOrigin
	@RequestMapping(value = "/pcmConsultProyectoGuardar/finalupload", method = RequestMethod.POST)
	synchronized public void handleProyectoFinalUpload(
			  								@RequestBody Map<String, Object> payload, // JSON 데이터 수신
											HttpServletRequest request, 
											HttpServletResponse response
											)  throws IOException  {

		System.out.println(" /pcmConsultProyectoGuardar/finalupload start");
		
		// JSON 데이터 추출
		Map<String, Object> expPostObj = (Map<String, Object>) payload.get("expPostObj");

	    String uploadControlName = (String) payload.get("el");
	    Integer   pidEstudio     = (Integer) payload.get("idEstudio");
	    Long 	  pidRegistro 	 = Long.valueOf((String) payload.get("idRegistro"));
	    Integer	  pidConsultor   = Integer.valueOf((String) payload.get("idConsultor")); 
	    String    pdni			 = (String) payload.get("dni");
	    int       pempresaSeq    = Integer.valueOf((String) payload.get("empresaSeq"));
	    String    pexpEmpresa	 = (String) payload.get("expEmpresa");
	    int       pproyectoSeq	 = (payload.get("proyectoSeq") == null) ? 0 : Integer.valueOf((String) payload.get("proyectoSeq"));
	    
	    String    pfechaIni		 = (String) payload.get("fechaIni");
	    String    pfechaFin		 = (String) payload.get("fechaFin");
	    String    panosExp		 = (String) payload.get("anosExp");
	    String    pusuIngreso	 = (String) payload.get("usuIngreso");
	    String    pipIngreso	 = (String) payload.get("ipIngreso");
	    String    pusuModifica	 = (String) payload.get("usuModifica");
	    String    pipModifica	 = (String) payload.get("ipModifica");
	    
	    // 디버깅 로그 추가
	    System.out.println("/pcmConsultProyectoGuardar/finalupload uploadControlName: " + uploadControlName + " idEstudio: " + pidEstudio);
	    
		PcmConsultorVO consultorProfDatos = new PcmConsultorVO();
		
		try {
            if( "finalUpload".equals(uploadControlName) ) {
            	
				Long idRegistro  = Long.valueOf(pidRegistro);
				int  idConsultor = Integer.valueOf(pidConsultor);
				String dni = pdni;
				int    empresaSeq = pempresaSeq;
				String expEmpresa = pexpEmpresa;
				int    proyectoSeq = pproyectoSeq;
				String usuIngreso 	= pusuIngreso;
				String ipIngreso 	= pipIngreso;
				String usuModifica	= pusuModifica;
				String ipModifica 	= pipModifica;

				System.out.println("########## uploadControlName: " + uploadControlName);// + " idEstudio :" + idEstudio );
				System.out.println("########## pidConsultor: " + pidConsultor);
	        	System.out.println("########## pidRegistro:" + pidRegistro + " pdni: " + pdni + " pempresaSeq: " + pempresaSeq + " pexpEmpresa: " + pexpEmpresa + " pproyectoSeq: " + pproyectoSeq);
	        	System.out.println("########## pusuIngreso: " + pusuIngreso + " pfechaFin: " + pfechaFin+ " panosExp: " + panosExp + " pipModifica: " + pipModifica);
	        	
	        	if(String.valueOf(idConsultor) == "" || idConsultor == 0) {
	        		idConsultor = getMaxIdConsultor(idConsultor,dni);
	        		System.out.println("after idConsultor: " + idConsultor + " dni=" + dni);
	        	}
	        	
	        	consultorProfDatos.setIdRegistro(idRegistro);
	        	consultorProfDatos.setIdConsultor(idConsultor);
	        	consultorProfDatos.setDni(dni);
	        	consultorProfDatos.setEmpresaSeq(empresaSeq);
	        	consultorProfDatos.setExpEmpresa(expEmpresa);
	        	consultorProfDatos.setProyectoSeq(proyectoSeq);
	        	consultorProfDatos.setFechaIni(pfechaIni);
	        	consultorProfDatos.setFechaFin(pfechaFin);
	        	consultorProfDatos.setAnosExp(panosExp);
	        	
	        	System.out.println("/pcmConsultProyectoGuardar/finalupload empresaSeq : " + empresaSeq);
	        	if(String.valueOf(empresaSeq) == "" || empresaSeq == 0) {
	        		//empresaSeq = 1;
	        		empresaSeq= getMaxEmpresaSeq(idConsultor, dni, expEmpresa);
	        		System.out.println("after /pcmConsultProyectoGuardar/finalupload empresaSeq : " + empresaSeq);
	        		consultorProfDatos.setEmpresaSeq(empresaSeq);
	        	}
	        	
	        	consultorProfDatos.setProyectoSeq(getMaxProyectoSeq(idConsultor,empresaSeq,pproyectoSeq));
	        	
	        	consultorProfDatos.setUsuIngreso(usuIngreso);
	        	consultorProfDatos.setIpIngreso(ipIngreso);
	        	consultorProfDatos.setUsuModifica(usuModifica);
	        	consultorProfDatos.setIpModifica(ipModifica);
	        	
	        	int[] idx = {0};
	        	
	        	if(expPostObj != null) {
	        		
	        		int[] ridx = {0}; // 배열을 사용하여 변경 가능하도록 설정
	        		
	                consultorProfDatos.setExpProyecto("");
	                consultorProfDatos.setNombreProyecto("");
	                consultorProfDatos.setProyectoSeq(-1);
	                consultorProfDatos.setIdArchivo(-1);
	                
	        		expPostObj.forEach((key, value) -> {

	        			System.out.println("############## " + ridx[0] + " pcmConsultProyectoGuardar expPostObj key : " + key + " value : " + value);

							if((key).indexOf("expProyecto") > -1) {
			                	consultorProfDatos.setExpProyecto(value.toString());	
			                }
			                if((key).indexOf("nombreProyecto") > -1) {
			                	consultorProfDatos.setNombreProyecto(value.toString());
			                }
			                if((key).indexOf("proyectoSeq") > -1) {
			                	consultorProfDatos.setProyectoSeq(Integer.valueOf(value.toString()));
			                }
			                if((key).indexOf("idProyArchivo") > -1) {
			                	consultorProfDatos.setIdArchivo(Integer.valueOf(value.toString()));
			                	consultorProfDatos.setIdDetPart(Integer.valueOf(value.toString()));
			                }
			                
			                if( consultorProfDatos.getExpProyecto() != null && !"".equals(consultorProfDatos.getExpProyecto()) ) {
				                if( consultorProfDatos.getNombreProyecto() != null && !"".equals(consultorProfDatos.getNombreProyecto()) ) {			                
					                if( Integer.valueOf(consultorProfDatos.getProyectoSeq()) != null && consultorProfDatos.getProyectoSeq() != -1 ) {			                
						                if( Integer.valueOf(consultorProfDatos.getIdArchivo()) != null  && consultorProfDatos.getIdArchivo() != -1  ) {			                
							                	idx[0] = 1;
						                }
					                }    
				                }
			                } 
				                
							System.out.println("############## 4 0 consultorProfDatos.getIdArchivo() : " + consultorProfDatos.getIdArchivo() + " idx[0]:" + idx[0]); 
						    System.out.println("###### ridx[0]:" + ridx[0] + " consultorProfDatos.getExpProyecto():" + consultorProfDatos.getExpProyecto() + " consultorProfDatos.getNombreProyecto():" + consultorProfDatos.getNombreProyecto());
						    System.out.println("###### consultorProfDatos.getProyectoSeq():" + consultorProfDatos.getProyectoSeq());
							System.out.println("############## 4 0 1 consultorProfDatos.getIdArchivo():" + consultorProfDatos.getIdArchivo() + " consultorProfDatos.getIdDetPart():" + consultorProfDatos.getIdDetPart());						                	
				                
			                if(idx[0] == 1) {
			                	consultorProfDatos.setIdDetPart(consultorProfDatos.getIdArchivo());
							    System.out.println("###### ridx[0]:" + ridx[0] + " consultorProfDatos.getExpProyecto():" + consultorProfDatos.getExpProyecto() + " consultorProfDatos.getNombreProyecto():" + consultorProfDatos.getNombreProyecto());
							    System.out.println("###### consultorProfDatos.getIdConsultor():" + consultorProfDatos.getIdConsultor() + " consultorProfDatos.getEmpresaSeq():" + consultorProfDatos.getEmpresaSeq() + " consultorProfDatos.getProyectoSeq():" + consultorProfDatos.getProyectoSeq());
								System.out.println("############## 5 1 consultorProfDatos.getIdArchivo():" + consultorProfDatos.getIdArchivo() + " consultorProfDatos.getIdDetPart():" + consultorProfDatos.getIdDetPart());						                	
						                	
							    pcmConsultorService.mergeConsultoraExperiencia(consultorProfDatos);				                	
			                	
				                consultorProfDatos.setExpProyecto("");
				                consultorProfDatos.setNombreProyecto("");
				                consultorProfDatos.setProyectoSeq(-1);
				                consultorProfDatos.setIdArchivo(-1);
						                
				                idx[0] = 0;
			                }
			                ridx[0]++;
		        		});
		        		
	        			System.out.println("############## 4 1 expPostObj.size() : " + expPostObj.size() + " ridx[0]:" + ridx[0]); 
	        		
	        			if(expPostObj.size() > 0 && ridx[0] == 0 ) {
		        			System.out.println("############## 4 2 consultorProfDatos.getExpProyecto():" + consultorProfDatos.getExpProyecto() + " consultorProfDatos.getNombreProyecto():" + consultorProfDatos.getNombreProyecto() + " consultorProfDatos.getIdDetPart():" + consultorProfDatos.getIdDetPart());	        		
			        		pcmConsultorService.mergeConsultoraExperiencia(consultorProfDatos);
		        		}
	        		
	        	} else {
	        		System.out.println("############## 5 2 consultorProfDatos.getExpProyecto():" + consultorProfDatos.getExpProyecto() + " consultorProfDatos.getNombreProyecto():" + consultorProfDatos.getNombreProyecto() + " consultorProfDatos.getIdDetPart():" + consultorProfDatos.getIdDetPart());	        		
	        		pcmConsultorService.mergeConsultoraExperiencia(consultorProfDatos);
	        	}// if(expPostObj != null) 
	        	
	        	globalProyectoseq = 0;
	        	
            }//end if( "finalUpload".equals(uploadControlName) ) 
            
	        response.setStatus(HttpServletResponse.SC_OK); // 200 OK
	        response.setContentType("application/json");
	        response.getWriter().write("{\"message\": \"Upload successful\"}");
			
		} catch (Exception e) {
			e.printStackTrace();
	        response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR); // 500 Error
	        response.setContentType("application/json");
	        response.getWriter().write("{\"error\": \"Server error occurred\"}");
		}
	
	}
	
	//-----------------------------------------------
	/**
	* Method for Inserting or Updating Files Related to Projects Handled by the Consultant
	* @param filename
	* @param inputId
	* @param uploadControlName
	* @param fileBytes
	* @param consultorProfDatos
	* @param request
	* @return int
	*/
	private int saveConsultProyectoFileToDB(
									String filename, 
									String inputId,
									String uploadControlName,
									byte[] fileBytes, 
									PcmConsultorVO consultorProfDatos,
									HttpServletRequest request) {

    	PcmConsultorFileVO blob = new PcmConsultorFileVO();
        blob.setIdRegistro(consultorProfDatos.getIdRegistro());
        blob.setIdConsultor(consultorProfDatos.getIdConsultor());
        blob.setExpEmpresa(consultorProfDatos.getExpEmpresa());
        blob.setArchivoTipo(inputId);
        blob.setDetPartFileYn(consultorProfDatos.getDetPartFileYn());
        
        System.out.println("########## saveConsultProyectoFileToDB blob.getIdRegistro(): " + blob.getIdRegistro() + " blob.getIdConsultor(): " + blob.getIdConsultor() + " consultorProfDatos.getDetPartFileYn():" + consultorProfDatos.getDetPartFileYn());
        System.out.println("########## saveConsultProyectoFileToDB consultorProfDatos.getDetPartFileYn():" + consultorProfDatos.getDetPartFileYn() + " consultorProfDatos.getIdArchivo():" + consultorProfDatos.getIdArchivo() + " consultorProfDatos.getIdArchivoSeq():" + consultorProfDatos.getIdArchivoSeq());
        System.out.println("########## saveConsultProyectoFileToDB consultorProfDatos.getExpProyecto():" + consultorProfDatos.getExpProyecto() + " consultorProfDatos.getNombreProyecto():" + consultorProfDatos.getNombreProyecto() );
        System.out.println("########## saveConsultProyectoFileToDB consultorProfDatos.getProyectoSeq():" + consultorProfDatos.getProyectoSeq() + " consultorProfDatos.getExpEmpresa(): " + consultorProfDatos.getExpEmpresa() ); 
        
    	if(Integer.valueOf(consultorProfDatos.getIdArchivo()) == 0 || String.valueOf(consultorProfDatos.getIdArchivo()) == "" || String.valueOf(consultorProfDatos.getIdArchivo()) == "null") {
    		if("YES".equals(consultorProfDatos.getDetPartFileYn())) {
    			
    			PcmConsultorVO currArchivo = getDetPartArchivoInfo(consultorProfDatos);
    			System.out.println("########## 0 saveConsultProyectoFileToDB currArchivo.getIdArchivo():" + currArchivo.getIdArchivo());
    			
    			PcmConsultorFileVO blob1 = new PcmConsultorFileVO();
    			blob1.setIdRegistro(consultorProfDatos.getIdRegistro());
    			blob1.setIdConsultor(consultorProfDatos.getIdConsultor());
    			blob1.setExpEmpresa(consultorProfDatos.getExpEmpresa());
    			blob1.setArchivoTipo(consultorProfDatos.getIdArchivoTipo());
    			blob1.setIdArchivo(currArchivo.getIdArchivo());
    			
    			blob.setIdArchivo(getMaxProyIdArchivo(blob1));
    		}else {	
    			blob.setIdArchivo(getMaxIdArchivo(blob));
    		}	
    			
    		System.out.println("1 saveConsultProyectoFileToDB after blob.getIdArchivo(): " + blob.getIdArchivo() );
    	}else {
    		blob.setIdArchivo(consultorProfDatos.getIdArchivo());
    		System.out.println("2 saveConsultProyectoFileToDB after blob.getIdArchivo(): " + blob.getIdArchivo() );
    	}

    	if(Integer.valueOf(consultorProfDatos.getIdArchivoSeq()) == 0 || String.valueOf(consultorProfDatos.getIdArchivoSeq()) == "" || String.valueOf(consultorProfDatos.getIdArchivoSeq()) == "null") {
    		if("YES".equals(consultorProfDatos.getDetPartFileYn())) {
    			PcmConsultorVO currArchivo = getDetPartArchivoInfo(consultorProfDatos);

    			System.out.println("########## 3 saveConsultProyectoFileToDB currArchivo.getIdArchivoSeq():" + currArchivo.getIdArchivoSeq());
    			PcmConsultorFileVO blob1 = new PcmConsultorFileVO();
    			
    			blob1.setIdRegistro(consultorProfDatos.getIdRegistro());
    			blob1.setIdConsultor(consultorProfDatos.getIdConsultor());
    			blob1.setArchivoTipo(consultorProfDatos.getIdArchivoTipo());
    			blob1.setIdArchivo(currArchivo.getIdArchivo());
    			blob1.setIdArchivoSeq(currArchivo.getIdArchivoSeq());
    			
    			blob.setIdArchivoSeq(1);
    		}else {
    			blob.setIdArchivoSeq(getMaxArchivoSeq(blob));
    		}
    		
    		System.out.println("4 saveConsultProyectoFileToDB after blob.getIdArchivoSeq(): " + blob.getIdArchivoSeq());
    	}else {
    		blob.setIdArchivoSeq(consultorProfDatos.getIdArchivoSeq());
    		System.out.println("5 saveConsultProyectoFileToDB after blob.getIdArchivoSeq(): " + blob.getIdArchivoSeq());
    	}
    	
    	blob.setProyectoSeq(consultorProfDatos.getProyectoSeq());
    	blob.setNombreProyecto(consultorProfDatos.getNombreProyecto());
    	
        blob.setNombreArchivo(filename);
        
        blob.setUsuIngreso(consultorProfDatos.getUsuIngreso());
        blob.setIpIngreso(consultorProfDatos.getIpIngreso());
        
        blob.setUsuModifica(consultorProfDatos.getUsuModifica());
        blob.setIpModifica(consultorProfDatos.getIpModifica());

        // MyBatis나 다른 데이터베이스 작업에 byte[] 사용
        blob.setDocumento(fileBytes);

        int idArchivo = 0;
        
       	idArchivo = blob.getIdArchivo();        
       	
        try {
        	System.out.println("################################################# saveConsultProyectoFileToDB mergeConsultoraDocumentoBlob idArchivo :" + idArchivo);
        	
        	pcmConsultorService.mergeConsultoraDocumentoBlob(blob);
        	
        } catch (Exception e) {
        	System.out.println("################################################# saveConsultProyectoFileToDB mergeConsultoraDocumentoBlob Exception");
            e.printStackTrace();
        } finally {
        	try {
        		System.out.println("################################################# saveConsultProyectoFileToDB updateMergeFile");
        		updateMergeFile(blob);
        	}catch(SQLException e) {
        		e.printStackTrace();
        	} catch (Exception e) {
                e.printStackTrace();
            } 
        }
        
        return idArchivo;
	}
	
	
	//-----------------------------------------------
	/**
	* Method for Inserting or Updating Files Related to Projects Handled by the Consultant
	* @param filename
	* @param inputId
	* @param uploadControlName
	* @param fileBytes
	* @param consultorProfDatos
	* @param request
	* @return int
	*/
	private int saveConsultModiProyectoFileToDB(
									String filename, 
									String inputId,
									String uploadControlName,
									byte[] fileBytes, 
									PcmConsultorVO consultorProfDatos,
									HttpServletRequest request) {

    	PcmConsultorFileVO blob = new PcmConsultorFileVO();
        blob.setIdRegistro(consultorProfDatos.getIdRegistro());
        blob.setIdConsultor(consultorProfDatos.getIdConsultor());
        blob.setExpEmpresa(consultorProfDatos.getExpEmpresa());
        
        blob.setArchivoTipo(inputId);
        blob.setDetPartFileYn(consultorProfDatos.getDetPartFileYn());
        
        System.out.println("########## saveConsultModiProyectoFileToDB blob.getIdRegistro(): " + blob.getIdRegistro() + " blob.getIdConsultor(): " + blob.getIdConsultor() + " consultorProfDatos.getDetPartFileYn():" + consultorProfDatos.getDetPartFileYn());
        System.out.println("########## saveConsultModiProyectoFileToDB consultorProfDatos.getDetPartFileYn():" + consultorProfDatos.getDetPartFileYn() + " consultorProfDatos.getIdArchivo():" + consultorProfDatos.getIdArchivo() + " consultorProfDatos.getIdArchivoSeq():" + consultorProfDatos.getIdArchivoSeq());
        System.out.println("########## saveConsultModiProyectoFileToDB consultorProfDatos.getExpProyecto():" + consultorProfDatos.getExpProyecto() + " consultorProfDatos.getNombreProyecto():" + consultorProfDatos.getNombreProyecto() );

    	blob.setIdArchivo(consultorProfDatos.getIdArchivo());
    	System.out.println("1 saveConsultModiProyectoFileToDB after blob.getIdArchivo(): " + blob.getIdArchivo() );
    	
		blob.setIdArchivoSeq(consultorProfDatos.getIdArchivoSeq());
		System.out.println("5 saveConsultModiProyectoFileToDB after blob.getIdArchivoSeq(): " + blob.getIdArchivoSeq());
    	
    	blob.setProyectoSeq(consultorProfDatos.getProyectoSeq());
    	blob.setNombreProyecto(consultorProfDatos.getNombreProyecto());
    	
        blob.setNombreArchivo(filename);
        
        blob.setUsuIngreso(consultorProfDatos.getUsuIngreso());
        blob.setIpIngreso(consultorProfDatos.getIpIngreso());
        
        blob.setUsuModifica(consultorProfDatos.getUsuModifica());
        blob.setIpModifica(consultorProfDatos.getIpModifica());

        // MyBatis나 다른 데이터베이스 작업에 byte[] 사용
        blob.setDocumento(fileBytes);

        int idArchivo = 0;
        
       	idArchivo = blob.getIdArchivo();        
       	
        try {
        	System.out.println("################################################# saveConsultModiProyectoFileToDB mergeConsultoraDocumentoBlob idArchivo :" + idArchivo);
        	
        	pcmConsultorService.mergeConsultoraDocumentoBlob(blob);
        	
        } catch (Exception e) {
        	System.out.println("################################################# saveConsultModiProyectoFileToDB mergeConsultoraDocumentoBlob Exception");
            e.printStackTrace();
        } finally {
        	try {
        		System.out.println("################################################# saveConsultModiProyectoFileToDB updateMergeFile");
        		updateMergeFile(blob);
        	}catch(SQLException e) {
        		e.printStackTrace();
        	} catch (Exception e) {
                e.printStackTrace();
            } 
        }
        
        return idArchivo;
	}
	
	
	//-----------------------------------------------
	/**
	* Method for Retrieving PCM Consultant Profile Data
	* @param dni
	* @param idcole
	* @param iddni
	* @param idcert
	* @param idddjj
	* @return PcmConsultorVO
	*/
	@RequestMapping(value = "/getProfDet", method = RequestMethod.POST)
	@ResponseBody
	public PcmConsultorVO getPcmProfDet(@RequestParam("dni") String dni, @RequestParam("idcole") int idcole, @RequestParam("iddni") int iddni
			 , @RequestParam("idcert") int idcert, @RequestParam("idddjj") int idddjj) {

		Map<String, Object> map = new HashMap<String, Object>();
		map.put("dni", dni);
		map.put("idColeArchivo", idcole);
		map.put("idDniArchivo",  iddni);
		map.put("idCertArchivo", idcert);
		map.put("idDdjjArchivo", idddjj);
		
	    System.out.println("Received dni: " + dni + " idcole: " + idcole + " iddni: " + iddni + " idcert: " + idcert + " idddjj: " + idddjj);
	    
		return pcmConsultorService.getPcmProfDet(map);
	}
	
	//-----------------------------------------------
	/**
	* Method for Retrieving Detailed File Data
	* @param consultorProfDatos
	* @return PcmConsultorVO
	*/
	public PcmConsultorVO getDetPartArchivoInfo(PcmConsultorVO consultorProfDatos) {
		Map<String, Object> map = new HashMap<String, Object>();
		
	    map.put("idRegistro",  consultorProfDatos.getIdRegistro());
		map.put("idConsultor", consultorProfDatos.getIdConsultor()); 
		map.put("idArchivoTipo", consultorProfDatos.getIdArchivoTipo());
		map.put("idArchivo",   consultorProfDatos.getIdArchivo());
		map.put("idArchivoSeq",  consultorProfDatos.getIdArchivoSeq());
		
	    System.out.println("getDetPartArchivoInfo Received idArchivo: " + consultorProfDatos.getIdArchivo() + " idArchivoSeq: " + consultorProfDatos.getIdArchivoSeq());
	    
		return pcmConsultorService.getDetPartArchivoInfo(map);
	}
	
	//-----------------------------------------------
	/**
	* Method for Deleting Consultant Data
	* @param requestList
	* @return ResponseEntity<?>
	*/
	@RequestMapping(value = "/deleteConsultInfo", method = RequestMethod.POST)
	@ResponseBody
	public ResponseEntity<?> deleteConsultInfo(@RequestBody List<PcmConsultorVO> requestList) {
		try {
            for (PcmConsultorVO request : requestList) {
                // 삭제 로직 (예: 데이터베이스에서 삭제)
                System.out.println("1 idRegistro: " + request.getIdRegistro());
                System.out.println("1 expEmpresa: " + request.getExpEmpresa());
                // 예시: consultService.deleteById(request.getIdRegistro(), request.getIdConsultor());
                Map<String, Object> map = new HashMap<String, Object>();
    			map.put("idConsultor", request.getIdConsultor());
    			
    			pcmConsultorService.deleteConsultExpriencia(map);
            }
            
            for (PcmConsultorVO request : requestList) {
                // 삭제 로직 (예: 데이터베이스에서 삭제)
                System.out.println("2 idRegistro: " + request.getIdRegistro());
                System.out.println("2 idConsultor: " + request.getIdConsultor());
                // 예시: consultService.deleteById(request.getIdRegistro(), request.getIdConsultor());
                Map<String, Object> map = new HashMap<String, Object>();
    			map.put("idRegistro", request.getIdRegistro());
    			map.put("idConsultor", request.getIdConsultor());
    			
    			pcmConsultorService.deleteConsultDocumento(map);
            }
            
            for (PcmConsultorVO request : requestList) {
                // 삭제 로직 (예: 데이터베이스에서 삭제)
                System.out.println("3 idConsultor: " + request.getIdConsultor());
                System.out.println("3 ruc: " + request.getRuc());
                // 예시: consultService.deleteById(request.getIdRegistro(), request.getIdConsultor());
                Map<String, Object> map = new HashMap<String, Object>();
    			map.put("idConsultor", request.getIdConsultor());
    			map.put("ruc", request.getRuc());
    			
    			pcmConsultorService.deleteConsultProfesional(map);
            }
            
            return ResponseEntity.ok("La fila seleccionada ha sido eliminada.");
        } catch (Exception e) {
        	e.printStackTrace();
            return ResponseEntity.status(500).body("Se produjo un error durante la eliminación.");
        }
	}
	
	//-----------------------------------------------
	/**
	* Method for Retrieving PCM Consultant Profile and Displaying on the Screen
	* @param model
	* @param request
	* @param idRegistro
	* @param idConsultor
	* @param expEmpresa
	* @param dni
	* @param ruc
	* @return (String) "pcm/pcmConsultorProfMod"
	*/
	@RequestMapping(value = "/pcmConsultorProfMod", method = RequestMethod.GET)
	public String pcmConsultorProfMod(Model model
								,HttpServletRequest request
								,@RequestParam("idRegistro") String idRegistro
								,@RequestParam("idConsultor") String idConsultor
								,@RequestParam("expEmpresa") String expEmpresa
								,@RequestParam("dni") String dni
								,@RequestParam("ruc") String ruc
			) {
		logger.info("The Controller is {}.", "pcmConsultorProfReg");
		
		System.out.println("################## /pcmConsultorProfMod idRegistro = " + idRegistro + " idConsultor = " + idConsultor  + " expEmpresa = " + expEmpresa + " dni = " + dni + " ruc = " + ruc);

		model.addAttribute("especialList", pcmConsultorService.getEspecialList());
		model.addAttribute("companyList",  pcmConsultorService.getCompanyList());

		Map<String, Object> map = new HashMap<String, Object>();

		map.put("idRegistro", idRegistro);
		map.put("idConsultor", idConsultor);
		map.put("expEmpresa", expEmpresa);
		map.put("dni", dni);
		map.put("ruc", ruc);

		model.addAttribute("profDetInfo",  	 pcmConsultorService.getPcmModProfDet(map));
		model.addAttribute("profDetExpList", pcmConsultorService.getPcmProfExpList(map));
		model.addAttribute("iIngreso",  Utilities.getClientIp(request));
		model.addAttribute("iModifica", Utilities.getClientIp(request));
		model.addAttribute("reload", request.getParameter("reload"));
		model.addAttribute("dni", request.getParameter("dni"));
		model.addAttribute("idcole", request.getParameter("idcole"));
		model.addAttribute("iddni", request.getParameter("iddni"));
		model.addAttribute("idcert", request.getParameter("idcert"));
		model.addAttribute("idddjj", request.getParameter("idddjj"));
		model.addAttribute("idRegistro", idRegistro);
		model.addAttribute("idConsultor", idConsultor);
		model.addAttribute("ruc", ruc);
		
		return "pcm/pcmConsultorProfMod";
	}

	//-----------------------------------------------
	/**
	* Method for Retrieving the List of Projects Assigned to the Consultant
	* @param idConsultor
	* @param dni
	* @param expEmpresa
	* @param idRegistro
	* @return List<PcmConsultorVO>
	*/
	@RequestMapping(value = "/getProyDetList", method = RequestMethod.POST)
	@ResponseBody
	public List<PcmConsultorVO> getPcmProfProyList(@RequestParam("idConsultor") int idConsultor, @RequestParam("dni") String dni
			,@RequestParam("expEmpresa") String expEmpresa, @RequestParam("idRegistro") Long idRegistro) {

		Map<String, Object> map = new HashMap<String, Object>();
		map.put("idConsultor", idConsultor);
		map.put("dni", dni);
		map.put("expEmpresa",  expEmpresa);
		map.put("idRegistro", idRegistro);
		
	    System.out.println("############## getPcmProfProyList Received idConsultor: " + idConsultor + " dni: " + dni + " expEmpresa: " + expEmpresa);
	    
	    // 서비스 호출
	    List<PcmConsultorVO> result = pcmConsultorService.getPcmProfProyList(map);

	    // 로그 추가
	    System.out.println("############## Result: " + result);
	    
		return result;
	}
	
	//-----------------------------------------------
	/**
	* Method for Uploading Files Related to Projects Handled by the Consultant
	* @param request
	* @param response
	* @param el
	* @param idEstudio
	* @param idRegistro
	* @param idConsultor
	* @param dni
	* @param empresaSeq
	* @param expEmpresa
	* @param proyectoSeq
	* @param fechaIni
	* @param fechaFin
	* @param anosExp
	* @param idCertArchivo
	* @param idDdjjArchivo
	* @param usuIngreso
	* @param ipIngreso
	* @param usuModifica
	* @param ipModifica
	*/
	@CrossOrigin
	@RequestMapping(value = "/pcmConsultProyectoModi/upload", method = RequestMethod.POST)
	synchronized public void handleProyectoModiUpload(
											HttpServletRequest request, 
											HttpServletResponse response,
											@RequestParam("el") String uploadControlName,
											@RequestParam(value = "idEstudio", required = false, defaultValue = "0") Integer pidEstudio, // Integer로 변경하여 null 허용
											@RequestParam(value = "idRegistro", required = false, defaultValue = "0") Long pidRegistro,
											@RequestParam(value = "idConsultor", required = false, defaultValue = "0") Integer pidConsultor,
											@RequestParam(value = "dni", required = false) String pdni,
											@RequestParam(value = "empresaSeq", required = false) Integer pempresaSeq,
											@RequestParam(value = "expEmpresa", required = false) String pexpEmpresa,
											@RequestParam(value = "proyectoSeq", required = false) Integer pproyectoSeq,
											@RequestParam(value = "fechaIni", required = false) String pfechaIni,
											@RequestParam(value = "fechaFin", required = false) String pfechaFin,
											@RequestParam(value = "anosExp", required = false) String panosExp,											
											@RequestParam(value = "idCertArchivo", required = false, defaultValue = "0") Integer pidCertArchivo,
											@RequestParam(value = "idDdjjArchivo", required = false, defaultValue = "0") Integer pidDdjjArchivo,
											@RequestParam(value = "usuIngreso", required = false) String pusuIngreso,
											@RequestParam(value = "ipIngreso", required = false) String pipIngreso,
											@RequestParam(value = "usuModifica", required = false) String pusuModifica,
											@RequestParam(value = "ipModifica", required = false) String pipModifica
											) {

		System.out.println(" /pcmConsultProyectoModi/upload start");
		
	    // 디버깅 로그 추가
	    System.out.println(" /pcmConsultProyectoModi/upload uploadControlName: " + uploadControlName + " idEstudio: " + pidEstudio);
	    
		PcmConsultorVO consultorProfDatos = new PcmConsultorVO();
		
		Long gidRegistro = (long) 0; // 업로드 처리 후 생성된 gidRegistro 값을 설정
		int  gidConsultor = 0;
		
		int  gidArchivo = 0;
		
		try {
        
			// 업로드 완료에 대한 구분
            if (!"finalUpload".equals(uploadControlName)) {
            	
	        	String directory = request.getSession().getServletContext().getRealPath("/common/data/"); // 서버 상대경로
				int maxPostSize = 2147482624; // bytes
	
				System.out.println("########### request :" + request + " response :" + response + " maxPostSize :" + maxPostSize + " directory :" + directory);
				
				InnorixUpload uploader = new InnorixUpload(request, response, maxPostSize, directory);
	
				String _orig_filename = uploader.getParameter("_orig_filename"); // 원본 파일명
				String _new_filename = uploader.getParameter("_new_filename"); // 저장 파일명
				String _filepath 	 = uploader.getParameter("_filepath"); // 파일 저장경로
				String _el           = uploader.getParameter("el");              // 컨트롤 엘리먼트 ID
				
				System.out.println(" pcmConsultProyectoModi _el :"+_el+" _orig_filename :" + _orig_filename + " _new_filename :" + _new_filename + " _filepath :" + _filepath );
				
				uploader.run();
	
				// 개별파일 업로드 완료
				if (uploader.isUploadDone()) {
	
					System.out.println("########## pcmConsultProyectoModi uploader.isUploadDone() ");
					
					String inputId   =  uploader.getParameter("inputId");
					
					Long idRegistro  = Long.valueOf(uploader.getParameter("idRegistro"));
					int  idConsultor = Integer.valueOf(uploader.getParameter("idConsultor"));
					String dni        = uploader.getParameter("dni");
					String ruc		  = uploader.getParameter("ruc");
					int empresaSeq	  = Integer.valueOf(uploader.getParameter("empresaSeq"));
					String expEmpresa = uploader.getParameter("expEmpresa");
					String usuIngreso = uploader.getParameter("usuIngreso");
					String ipIngreso = uploader.getParameter("ipIngreso");
					String usuModifica = uploader.getParameter("usuModifica");
					String ipModifica = uploader.getParameter("ipModifica");
					String detPartFileYn  = uploader.getParameter("detPartFileYn");
					int    rowcnt         = (uploader.getParameter("rowcnt") == null) ? 0 : Integer.valueOf(uploader.getParameter("rowcnt"));
					int    proyectoSeq    = Integer.valueOf(uploader.getParameter("proyectoSeq"));
					String nombreProyecto = uploader.getParameter("nombreProyecto");
					int idArchivo    = Integer.valueOf(uploader.getParameter("idArchivo"));
					int idArchivoSeq = Integer.valueOf(uploader.getParameter("idArchivoSeq"));
					
					String controlName = uploader.getParameter("controlName");
										
		        	if(idRegistro == null || String.valueOf(idRegistro) == "" || idRegistro == 0) {
		        		idRegistro  = getMaxIdRegistro(ruc);
		        		gidRegistro = idRegistro;
		        		System.out.println("after idRegistro: " + idRegistro);
		        	}
	
		        	if(String.valueOf(idConsultor) == "" || idConsultor == 0) {
		        		idConsultor = getMaxIdConsultor(idConsultor,dni);
		        		gidConsultor = idConsultor;		        		
		        		System.out.println("after idConsultor: " + idConsultor);
		        	}
		        	
		        	consultorProfDatos.setIdRegistro(idRegistro);
		        	consultorProfDatos.setIdConsultor(idConsultor);
		        	consultorProfDatos.setDni(dni);
		        	consultorProfDatos.setEmpresaSeq(empresaSeq);
		        	consultorProfDatos.setExpEmpresa(expEmpresa);

		        	consultorProfDatos.setUsuIngreso(usuIngreso);
		        	consultorProfDatos.setIpIngreso(ipIngreso);
		        	consultorProfDatos.setUsuModifica(usuModifica);
		        	consultorProfDatos.setIpModifica(ipModifica);
		        	
		        	consultorProfDatos.setIdArchivoTipo(inputId);
		        	consultorProfDatos.setDetPartFileYn(detPartFileYn);
		        	consultorProfDatos.setProyectoSeq(proyectoSeq);
		        	consultorProfDatos.setNombreProyecto(nombreProyecto);

		        	consultorProfDatos.setIdArchivo(idArchivo);
		        	consultorProfDatos.setIdArchivoSeq(idArchivoSeq);
		        	
					System.out.println("########## uploader idRegistro: " + uploader.getParameter("idRegistro") + " controlName: " + controlName);
					System.out.println("########## uploadControlName: " + uploadControlName + " proyectoSeq :" + proyectoSeq + " nombreProyecto :" + nombreProyecto );
		        	System.out.println("########## idRegistro:" + idRegistro + " idConsultor:" + idConsultor + " dni: " + dni  + " expEmpresa: " + expEmpresa + " empresaSeq: " + empresaSeq  + " detPartFileYn: " + detPartFileYn );
		        	System.out.println("########## usuIngreso: " + usuIngreso + " ipIngreso: " + ipIngreso+ " usuModifica: " + usuModifica + " ipModifica: " + ipModifica);
		        	System.out.println("########## consultorProfDatos.getIdArchivo(): " + consultorProfDatos.getIdArchivo() + " consultorProfDatos.getIdArchivoSeq(): " + consultorProfDatos.getIdArchivoSeq());
		        	System.out.println("########## consultorProfDatos.getProyectoSeq(): " + consultorProfDatos.getProyectoSeq() + " consultorProfDatos.getNombreProyecto(): " + consultorProfDatos.getNombreProyecto());

	
					// 서버에 저장된 파일의 데이터
					Path path = Paths.get(directory, _new_filename); // 서버경로 + 저장 파일명
					byte[] fileBytes = Files.readAllBytes(path);
					
					System.out.println("File uploaded for control uploadControlName = " + uploadControlName + " rowcnt = " + rowcnt);
					
					gidArchivo = saveConsultModiProyectoFileToDB(_orig_filename, inputId, uploadControlName, fileBytes, consultorProfDatos, request);
					
					System.out.println("##### /pcmConsultProyectoModi/upload after gidArchivo: " + gidArchivo);

					// 서버에서 파일 삭제
					Files.delete(path);
				}
				
				System.out.println("========== file transfer " + System.currentTimeMillis() + " ==========");
				System.out.println("_orig_filename \t = " + _orig_filename);
				System.out.println("_new_filename \t = " + _new_filename);
				System.out.println("_filepath \t = " + _filepath);
				
				
	        	if(pidRegistro == null || String.valueOf(pidRegistro) == "" || pidRegistro == 0) {
					uploader.setCustomValue("gidRegistro", String.valueOf(gidRegistro) ); // 클라이언트측으로 전달할 key,value값 설정 
	        	}
	        	
				if(String.valueOf(gidConsultor) != "" && String.valueOf(gidConsultor) != "0") {
					uploader.setCustomValue("gidConsultor", String.valueOf(gidConsultor) ); // 클라이언트측으로 전달할 key,value값 설정 
				}
				
				
				if((uploadControlName).indexOf("proyCtrl") > -1) {// && gidArchivo != 0 && String.valueOf(gidArchivo) != "0" ) {
					System.out.println("########## 1 /pcmConsultProyectoGuardar/upload uploadControlName: " + uploadControlName + " gidArchivo: " + gidArchivo);					
					uploader.setCustomValue("gidProyArchivo", String.valueOf(gidArchivo) ); // 클라이언트측으로 전달할 key,value값 설정
				}
				
				if("ddjjCtrl".equals(uploadControlName) && gidArchivo != 0 && String.valueOf(gidArchivo) != "0" ) {
					uploader.setCustomValue("gidDdjjArchivo", String.valueOf(gidArchivo) ); // 클라이언트측으로 전달할 key,value값 설정 
				}
				
				if("certCtrl".equals(uploadControlName) && gidArchivo != 0 && String.valueOf(gidArchivo) != "0" ) {
					uploader.setCustomValue("gidCertArchivo", String.valueOf(gidArchivo) ); // 클라이언트측으로 전달할 key,value값 설정 
				}

				uploader.sendCustomValue();
            }
            
			// CORS 관련 헤더 추가
			response.setHeader("Access-Control-Allow-Origin", "*");
			response.setHeader("Access-Control-Allow-Credentials", "true");
			response.setHeader("Access-Control-Allow-Methods", "POST, OPTIONS");
			response.setHeader("Access-Control-Allow-Headers",
					"Authorization,DNT,X-Mx-ReqToken,Keep-Alive,User-Agent,X-Requested-With,If-Modified-Since,Cache-Control,Content-Type");
			
		} catch (Exception e) {
			 e.printStackTrace();
		}
		
	}

	//-----------------------------------------------
	/**
	* Method for Uploading Files Related to Projects Handled by the Consultant
	* @param payload
	* @param request
	* @param response
	* @throws IOException
	*/
	@CrossOrigin
	@RequestMapping(value = "/pcmConsultProyectoModifi/finalupload", method = RequestMethod.POST)
	synchronized public void handleProyectoModFinalUpload(
			  								@RequestBody Map<String, Object> payload, // JSON 데이터 수신
											HttpServletRequest request, 
											HttpServletResponse response
											)  throws IOException  {

		System.out.println(" /pcmConsultProyectoModifi/finalupload start");
		
		// JSON 데이터 추출
		Map<String, Object> expPostObj1 = (Map<String, Object>) payload.get("expPostObj1");

	    String uploadControlName = (String) payload.get("el");
	    String inputId 			 = (String) payload.get("inputId");
	    
	    //Integer   pidEstudio     = (Integer) payload.get("idEstudio");
	    Long 	  pidRegistro 	 = Long.valueOf((String) payload.get("idRegistro"));
	    Integer	  pidConsultor   = Integer.valueOf((String) payload.get("idConsultor")); 
	    String    pdni			 = (String) payload.get("dni");
	    int       pempresaSeq    = Integer.valueOf((String) payload.get("empresaSeq"));
	    String    pexpEmpresa	 = (String) payload.get("expEmpresa");
	    int       pproyectoSeq	 = (payload.get("proyectoSeq") == null) ? 0 : Integer.valueOf((String) payload.get("proyectoSeq"));
	    
	    String    pfechaIni		 = (String) payload.get("fechaIni");
	    String    pfechaFin		 = (String) payload.get("fechaFin");
	    String    panosExp		 = (String) payload.get("anosExp");

	    String    pusuIngreso	 = (String) payload.get("usuIngreso");
	    String    pipIngreso	 = (String) payload.get("ipIngreso");
	    String    pusuModifica	 = (String) payload.get("usuModifica");
	    String    pipModifica	 = (String) payload.get("ipModifica");
	    
	    // 디버깅 로그 추가
	    System.out.println(" /pcmConsultProyectoModifi/finalupload uploadControlName: " + uploadControlName + " inputId: " + inputId);
	    
		PcmConsultorVO consultorProfDatos = new PcmConsultorVO();
		
		try {
            if( "finalUpload".equals(uploadControlName) ) {

				System.out.println("########## pcmConsultProyectoModifi uploadControlName: " + uploadControlName);
				System.out.println("########## pcmConsultProyectoModifi pidConsultor: " + pidConsultor);
	        	System.out.println("########## pcmConsultProyectoModifi pidRegistro:" + pidRegistro + " pdni: " + pdni + " pempresaSeq: " + pempresaSeq + " pexpEmpresa: " + pexpEmpresa + " pproyectoSeq: " + pproyectoSeq);
	        	System.out.println("########## pcmConsultProyectoModifi pusuIngreso: " + pusuIngreso + " pfechaFin: " + pfechaFin+ " panosExp: " + panosExp + " pipModifica: " + pipModifica);

				Long idRegistro  = Long.valueOf(pidRegistro);
				int  idConsultor = Integer.valueOf(pidConsultor);

				String dni = pdni;
				int    empresaSeq = pempresaSeq;//선택된 경력회사 순번
				String expEmpresa = pexpEmpresa;//선택된 경력회사명
				int    proyectoSeq = pproyectoSeq;
				
				String usuIngreso 	= pusuIngreso;
				String ipIngreso 	= pipIngreso;
				String usuModifica	= pusuModifica;
				String ipModifica 	= pipModifica;
	        	
	        	consultorProfDatos.setIdRegistro(idRegistro);
	        	consultorProfDatos.setIdConsultor(idConsultor);
	        	consultorProfDatos.setDni(dni);
	        	consultorProfDatos.setEmpresaSeq(empresaSeq);
	        	consultorProfDatos.setExpEmpresa(expEmpresa);
	        	consultorProfDatos.setFechaIni(pfechaIni);
	        	consultorProfDatos.setFechaFin(pfechaFin);
	        	consultorProfDatos.setAnosExp(panosExp);
	        	consultorProfDatos.setUsuIngreso(usuIngreso);
	        	consultorProfDatos.setIpIngreso(ipIngreso);
	        	consultorProfDatos.setUsuModifica(usuModifica);
	        	consultorProfDatos.setIpModifica(ipModifica);
	        	
	        	 // 데이터 처리 예시
	        	int[] rowIdx = {0};
	        	
	        	int[] idx = {0};
	        	
	        	if(expPostObj1 != null) {
	        		
	        		int[] ridx = {0}; // 배열을 사용하여 변경 가능하도록 설정
	        		
	                consultorProfDatos.setExpProyecto("");
	                consultorProfDatos.setNombreProyecto("");
	                consultorProfDatos.setProyectoSeq(-1);
	                consultorProfDatos.setIdArchivo(-1);
	                consultorProfDatos.setIdArchivoSeq(-1);
	                
	        		expPostObj1.forEach((key, value) -> {

	        			System.out.println("############## " + ridx[0] + " pcmConsultProyectoModifi expPostObj1 key : " + key + " value : " + value);
	    	  
		                if((key).indexOf("expProyecto") > -1) {
		                	consultorProfDatos.setExpProyecto(value.toString());	
		                }
		                if((key).indexOf("nombreProyecto") > -1) {
		                	consultorProfDatos.setNombreProyecto(value.toString());
		                }
		                if((key).indexOf("proyectoSeq") > -1) {
		                	consultorProfDatos.setProyectoSeq(Integer.valueOf(value.toString()));
		                }
		                if((key).indexOf("idArchivo") > -1 && (key).indexOf("idArchivoSeq") < 0) {
		                	consultorProfDatos.setIdArchivo(Integer.valueOf(value.toString()));
		                	consultorProfDatos.setIdDetPart(Integer.valueOf(value.toString()));
		                }
		                if((key).indexOf("idArchivoSeq") > -1) {
		                	consultorProfDatos.setIdArchivoSeq(Integer.valueOf(value.toString()));
		                }

		                if( consultorProfDatos.getExpProyecto() != null && consultorProfDatos.getExpProyecto() != null ) {
			                if( consultorProfDatos.getNombreProyecto() != null && !"".equals(consultorProfDatos.getNombreProyecto()) ) {			                
				                if( Integer.valueOf(consultorProfDatos.getProyectoSeq()) != null && consultorProfDatos.getProyectoSeq() != -1 ) {			                
					                if( Integer.valueOf(consultorProfDatos.getIdArchivo()) != null  && consultorProfDatos.getIdArchivo() != -1  ) {			                
						                if( Integer.valueOf(consultorProfDatos.getIdArchivoSeq()) != null  && consultorProfDatos.getIdArchivoSeq() != -1  ) {	
						                	idx[0] = 1;
						                }
					                }
				                }    
			                }
		                } 

		                System.out.println("################ 1 idx[0]: " + idx[0] + " consultorProfDatos.getIdArchivo():" + consultorProfDatos.getIdArchivo());
		                System.out.println("###### 1 ridx[0]:" + ridx[0] + " consultorProfDatos.getIdConsultor():" + consultorProfDatos.getIdConsultor() + " consultorProfDatos.getEmpresaSeq():" + consultorProfDatos.getEmpresaSeq() + " consultorProfDatos.getExpEmpresa():" + consultorProfDatos.getExpEmpresa());
		                System.out.println("###### 1 consultorProfDatos.getExpProyecto():" + consultorProfDatos.getExpProyecto() + " consultorProfDatos.getNombreProyecto():" + consultorProfDatos.getNombreProyecto() + " consultorProfDatos.getProyectoSeq():" + consultorProfDatos.getProyectoSeq());
		                System.out.println("############## 5 1 consultorProfDatos.getIdDetPart():" + consultorProfDatos.getIdDetPart() + " empNameCompYn: " + consultorProfDatos.getEmpNameCompYn());

			            if(idx[0] == 1) {
			            	System.out.println("################ 2 idx[0]: " + idx[0] + " 2 consultorProfDatos.getIdArchivo():" + consultorProfDatos.getIdArchivo());
			            	System.out.println("###### 2 ridx[0]:" + ridx[0] + " consultorProfDatos.getIdConsultor():" + consultorProfDatos.getIdConsultor() + " consultorProfDatos.getEmpresaSeq():" + consultorProfDatos.getEmpresaSeq() + " consultorProfDatos.getExpEmpresa():" + consultorProfDatos.getExpEmpresa());
			            	System.out.println("###### 2 consultorProfDatos.getExpProyecto():" + consultorProfDatos.getExpProyecto() + " consultorProfDatos.getNombreProyecto():" + consultorProfDatos.getNombreProyecto() + " consultorProfDatos.getProyectoSeq():" + consultorProfDatos.getProyectoSeq());
			            	System.out.println("############## 5 2 consultorProfDatos.getIdDetPart():" + consultorProfDatos.getIdDetPart() + " empNameCompYn: " + consultorProfDatos.getEmpNameCompYn());
			                	
						    pcmConsultorService.mergeConsultoraExperiencia(consultorProfDatos);				                	
		                	
				            if("detPartFile".equals(inputId)) {
					            PcmConsultorFileVO blob = new PcmConsultorFileVO();
					            
					            blob.setIdRegistro(consultorProfDatos.getIdRegistro());
					            blob.setIdConsultor(consultorProfDatos.getIdConsultor());
					            blob.setExpEmpresa(consultorProfDatos.getExpEmpresa());
					            blob.setArchivoTipo(inputId); // input file id
					            blob.setIdArchivo(consultorProfDatos.getIdArchivo());
					            blob.setIdArchivoSeq(consultorProfDatos.getIdArchivoSeq());
					            blob.setProyectoSeq(consultorProfDatos.getProyectoSeq());
					            blob.setUsuModifica(usuModifica);
					            blob.setIpModifica(ipModifica);										            
					            
					            blob.setNombreProyecto(consultorProfDatos.getNombreProyecto());
					            
					            pcmConsultorService.updateConsultoraDocumentoBlob(blob);
				            }
				            
		                	ridx[0]++;
			                consultorProfDatos.setExpProyecto("");
			                consultorProfDatos.setNombreProyecto("");
			                consultorProfDatos.setProyectoSeq(-1);
			                consultorProfDatos.setIdArchivo(-1);
			                consultorProfDatos.setIdArchivoSeq(-1);
						                      
			            }//end if(idx[0] == 1) {
			            
	      				idx[0] = 0;
	      				
	        		});//end expPostObj1.forEach((key, value)
	        		
	        		
	        		System.out.println("############## 4 1 expPostObj1_1.size() : " + expPostObj1.size() + " ridx[0]:" + ridx[0]);
	        		
	        		if(expPostObj1.size() > 0 && ridx[0] == 0 ) {
	        			System.out.println("############## 4 2 consultorProfDatos.getExpProyecto():" + consultorProfDatos.getExpProyecto() + " consultorProfDatos.getNombreProyecto():" + consultorProfDatos.getNombreProyecto() + " consultorProfDatos.getIdDetPart():" + consultorProfDatos.getIdDetPart());	        		
		        		pcmConsultorService.mergeConsultoraExperiencia(consultorProfDatos);
	        		}
	        		
	        	}else {
	        		System.out.println("############## 5 3 consultorProfDatos.getExpProyecto():" + consultorProfDatos.getExpProyecto() + " consultorProfDatos.getNombreProyecto():" + consultorProfDatos.getNombreProyecto() + " consultorProfDatos.getIdDetPart():" + consultorProfDatos.getIdDetPart());	        		
	        		pcmConsultorService.mergeConsultoraExperiencia(consultorProfDatos);
	        	}// if(expPostObj != null) 
            }//end if( "finalUpload".equals(uploadControlName) ) 
            
	        response.setStatus(HttpServletResponse.SC_OK); // 200 OK
	        response.setContentType("application/json");
	        response.getWriter().write("{\"message\": \"Upload successful\"}");
			
		} catch (Exception e) {
			e.printStackTrace();
	        response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR); // 500 Error
	        response.setContentType("application/json");
	        response.getWriter().write("{\"error\": \"Server error occurred\"}");
		}
	
	}
	
	//-----------------------------------------------
	/**
	* Method for Retrieving the PCM Consultant List and Creating Pagination
	* @param model
	* @param currentPage
	* @param ruc
	*/
	private void makePagination(Model model, int currentPage,String ruc) {
	    Map<String, Object> totalMap = new HashMap<>();

	    int totalNumber = pcmConsultorService.getPcmConsultorListTot(totalMap);
	    int countPerPage = 20; // 한 페이지에 표시할 항목 수
	    int totalPage = (totalNumber % countPerPage == 0) ? totalNumber / countPerPage : totalNumber / countPerPage + 1;
	    int startNo = (currentPage - 1) * countPerPage + 1;
	    int endNo = currentPage * countPerPage;

	    // 페이지 번호 그룹 계산
	    int pageGroupSize = 20; // 한 번에 표시할 페이지 링크 수
	    int pageGroup = (currentPage - 1) / pageGroupSize; // 현재 페이지의 그룹 번호

	    int startPageNo = pageGroup * pageGroupSize + 1; // 시작 페이지 번호
	    int endPageNo = startPageNo + pageGroupSize - 1; // 종료 페이지 번호
	    endPageNo = Math.min(endPageNo, totalPage); // 총 페이지를 넘지 않도록 조정

	    boolean prev = startPageNo > 1; // 이전 버튼 활성화 여부
	    boolean next = endPageNo < totalPage; // 다음 버튼 활성화 여부

	    Map<String, Object> pageMap = new HashMap<>();
	    pageMap.put("currentPage", currentPage);
	    pageMap.put("ruc", ruc);
	    
	    model.addAttribute("pcmConsultorList", pcmConsultorService.getPcmConsultorList(pageMap));
	    model.addAttribute("currentPage", currentPage);
	    model.addAttribute("totalNumber", totalNumber);
	    model.addAttribute("countPerPage", countPerPage);
	    model.addAttribute("totalPage", totalPage);
	    model.addAttribute("startNo", startNo);
	    model.addAttribute("endNo", endNo);
	    model.addAttribute("startPageNo", startPageNo);
	    model.addAttribute("endPageNo", endPageNo);
	    model.addAttribute("prev", prev);
	    model.addAttribute("next", next);
	}
	
	//-----------------------------------------------
	/**
	* Method for Deleting Consultant Experience.
	* @param selectedData
	* @return ResponseEntity<?>
	*/
	@RequestMapping(value = "/deleteExpProy", method = RequestMethod.POST)
	@ResponseBody
    public ResponseEntity<?> deleteExpProy(@RequestBody List<PcmConsultorVO> selectedData) {
        try {
            // 선택된 데이터 삭제 처리
            for (PcmConsultorVO data : selectedData) {
				Map<String, Object> map = new HashMap<String, Object>();
				map.put("idConsultor", Integer.valueOf(data.getIdConsultor()));
				map.put("expEmpresa", data.getExpEmpresa());
				map.put("proyectoSeq", Integer.valueOf(data.getProyectoSeq()));
				
                // 서비스 호출하여 데이터 삭제
                pcmConsultorService.deleteConsultExpriencia(map);
            }

            for (PcmConsultorVO data : selectedData) {
				Map<String, Object> map = new HashMap<String, Object>();
				map.put("idRegistro", data.getIdRegistro());
				map.put("idConsultor", Integer.valueOf(data.getIdConsultor()));
				map.put("expEmpresa", data.getExpEmpresa());
				map.put("idArchivoTipo", data.getIdArchivoTipo());
				map.put("idArchivo", Integer.valueOf(data.getIdArchivo()));
				map.put("idArchivoSeq", Integer.valueOf(data.getIdArchivoSeq()));
				
                // 서비스 호출하여 데이터 삭제
                pcmConsultorService.deleteConsultDocumento(map);
            }

            // 성공 응답
            return ResponseEntity.ok("Datos eliminados con éxito.");
        } catch (Exception e) {
        	e.printStackTrace();
            // 에러 응답
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                                 .body("Error al eliminar los datos.");
        }
    }
	
	//-----------------------------------------------
	/**
	* Method for Deleting Consultant Experience.
	* @param selectedData
	* @return ResponseEntity<?>
	*/
	@RequestMapping(value = "/deleteEmpresaProy", method = RequestMethod.POST)
	@ResponseBody
    public ResponseEntity<?> deleteEmpresaProy(@RequestBody List<PcmConsultorVO> selectedData) {
        try {
            // 선택된 데이터 삭제 처리
            for (PcmConsultorVO data : selectedData) {
				Map<String, Object> map = new HashMap<String, Object>();
				map.put("idConsultor", Integer.valueOf(data.getIdConsultor()));
				map.put("expEmpresa", data.getExpEmpresa());
				
                // 서비스 호출하여 데이터 삭제
                pcmConsultorService.deleteConsultExpriencia(map);
            }

            for (PcmConsultorVO data : selectedData) {
				Map<String, Object> map = new HashMap<String, Object>();
				map.put("idRegistro", data.getIdRegistro());
				map.put("idConsultor", Integer.valueOf(data.getIdConsultor()));
				map.put("expEmpresa", data.getExpEmpresa());
				
                // 서비스 호출하여 데이터 삭제
                pcmConsultorService.deleteConsultDocumento(map);
            }

            
            // 성공 응답
            return ResponseEntity.ok("Datos eliminados con éxito.");
        } catch (Exception e) {
        	e.printStackTrace();
            // 에러 응답
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                                 .body("Error al eliminar los datos.");
        }
    }
	
	//-----------------------------------------------
	/**
	* Method for Converting JSON String to Map
	* @param jsonString
	* @return Map<String, Object>
	*/
	public Map<String, Object> getJSONStringToMap(String jsonString){ 
		System.out.println("################ getJSONStringToMap jsonString:" + jsonString);	
	    // ObjectMapper를 사용하여 JSON 문자열을 Map으로 변환
	    ObjectMapper objectMapper = new ObjectMapper();
	    Map<String, Object> expPostObj = null;
		try {
            if (jsonString == null || jsonString.trim().isEmpty()) {
                throw new IllegalArgumentException("JSON string is null or empty");
            }
			expPostObj = objectMapper.readValue(jsonString, Map.class);
		} catch (JsonMappingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (JsonProcessingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	    return expPostObj; 
	}
	
	//-----------------------------------------------
	/**
	* Method for Sending Consultant Data to Intranet
	* @param selectedData
	* @param request
	* @return ResponseEntity<?>
	*/
	@RequestMapping(value = "/enviarEmpresaInfo", method = RequestMethod.POST)
	@ResponseBody
	@Transactional // 트랜잭션 관리
    public ResponseEntity<?> enviarEmpresaInfo(@RequestBody List<PcmConsultorVO> selectedData, HttpServletRequest request) {
		
        try {

            for (PcmConsultorVO data : selectedData) {
				Map<String, Object> map = new HashMap<String, Object>();
				map.put("idRegistro", Long.valueOf(data.getIdRegistro()));
				
				pcmConsultorService.deleteDgaamConsultoraDatos(map);				
                // 서비스 호출
                pcmConsultorService.insertDgaamConsultoraDatos(map);
            }

            for (PcmConsultorVO data : selectedData) {
				Map<String, Object> map = new HashMap<String, Object>();
				map.put("idRegistro", Long.valueOf(data.getIdRegistro()));
				map.put("solicitud", data.getSolicitud());
				
				pcmConsultorService.deleteDgaamConsultoraRequistios(map);
                // 서비스 호출
                pcmConsultorService.insertDgaamConsultoraRequistios(map);
            }
            
            for (PcmConsultorVO data : selectedData) {
				Map<String, Object> map = new HashMap<String, Object>();
				map.put("idRegistro", Long.valueOf(data.getIdRegistro()));
				map.put("idConsultor", Long.valueOf(data.getIdConsultor()));
				
				pcmConsultorService.deleteDgaamConsultoraDocumento(map);
                // 서비스 호출
                pcmConsultorService.insertDgaamConsultoraDocumento(map);
            }
            
            
            
            // 성공 응답
			Map<String, Object> response = new HashMap<>();
			response.put("success", true);
			return new ResponseEntity<>(response, HttpStatus.OK);
			
        } catch (Exception e) {
        	e.printStackTrace();
        	
			String message = messageSource.getMessage("error.internal_server_error", null,LocaleContextHolder.getLocale());
			Map<String, Object> errorResponse = new HashMap<>();
			errorResponse.put("success", false);
			errorResponse.put("message", message);
			return new ResponseEntity<>(errorResponse, HttpStatus.OK);
        }
    }
	
	//-----------------------------------------------
	/**
	* Method for Sending Consultant Data to Intranet
	* @param requestData
	* @param request
	* @return ResponseEntity<?>
	*/
	@RequestMapping(value = "/enviarConsultorInfo", method = RequestMethod.POST)
	@ResponseBody
	@Transactional
	public ResponseEntity<?> enviarConsultorInfo(@RequestBody Map<String, Object> requestData, HttpServletRequest request) {
		try {
			ObjectMapper mapper = new ObjectMapper();
			
	        List<Integer> consultIds  = mapper.convertValue(requestData.get("consultIds"), new TypeReference<List<Integer>>() {});
	        List<Long> registroIds = mapper.convertValue(requestData.get("registroIds"), new TypeReference<List<Long>>() {});
	        List<String> rucs = mapper.convertValue(requestData.get("rucs"), new TypeReference<List<String>>() {});
	        List<String> exps = mapper.convertValue(requestData.get("exps"), new TypeReference<List<String>>() {});
	        List<String> dnis = mapper.convertValue(requestData.get("dnis"), new TypeReference<List<String>>() {});
	        
	        int[] idx = {0};
	        
	        
	        
	        consultIds.forEach(consultId -> {
				Map<String, Object> param = new HashMap<>();
				
				System.out.println("############### enviarConsultorInfo "+idx[0]+" String.valueOf(registroIds.get(idx[0])): " + String.valueOf(registroIds.get(idx[0])) + " consultId:" + consultId );
				System.out.println("############### enviarConsultorInfo "+idx[0]+" rucs.get(idx[0]): " + rucs.get(idx[0]) );

				param.put("idRegistro", String.valueOf(registroIds.get(idx[0])));
			    param.put("idConsultor", consultId);
			    param.put("ruc", rucs.get(idx[0]));
			    //param.put("expEmpresa",  String.valueOf(exps.get(idx[0])));
			    //param.put("dni", dnis.get(idx[0]));
			    
			    pcmConsultorService.deleteDgaamConsultoraDocumento(param);
			    pcmConsultorService.insertDgaamConsultoraDocumento(param);
			    
			    pcmConsultorService.deleteDgaamConsultExpriencia(param);
			    pcmConsultorService.insertDgaamConsultExpriencia(param);

			    pcmConsultorService.deleteDgaamConsultProfesional(param);
			    pcmConsultorService.insertDgaamConsultProfesional(param);

			    //pcmConsultorService.savePcmComponent(param);
			    
			    idx[0]++;
			});


			Map<String, Object> response = new HashMap<>();
			response.put("success", true);
			return new ResponseEntity<>(response, HttpStatus.OK);

		} catch (Exception e) {
			e.printStackTrace();

			String message = messageSource.getMessage("error.internal_server_error", null,LocaleContextHolder.getLocale());
			Map<String, Object> errorResponse = new HashMap<>();
			errorResponse.put("success", false);
			errorResponse.put("message", message);
			return new ResponseEntity<>(errorResponse, HttpStatus.OK);
		}
	}
	
	//-----------------------------------------------
	/**
	* Method for Retrieving the Count of Consultant(PROFESIONAL) for a Given RUC
	* @param ruc
	* @return PcmConsultorVO
	*/
	@RequestMapping(value = "/getEspecialCntByRuc", method = RequestMethod.GET)
	@ResponseBody
	public PcmConsultorVO getEspecialCntByRuc(@RequestParam("ruc") String ruc) {

		Map<String, Object> map = new HashMap<String, Object>();
		map.put("ruc", ruc);
		
		return pcmConsultorService.getEspecialCntByRuc(map);
	}
	
	//-----------------------------------------------
	/**
	* Method for SP_ENVIAR_CONSULTORA
	* @param requestData
	* @param request
	* @return ResponseEntity<?>
	*/
	@RequestMapping(value = "/enviarConsultora", method = RequestMethod.POST)
	@ResponseBody
	@Transactional // 트랜잭션 관리	
	public ResponseEntity<?> enviarConsultora(
									/*HttpServletRequest request,
									@RequestParam("idRegistro") int idRegistro,
									@RequestParam("ctupa") int ctupa,
									@RequestParam("ruc") String ruc,
									@RequestParam("userIdAndRuc") String userIdAndRuc
									) {*/
		@RequestBody Map<String, Object> requestData, HttpServletRequest request) {
		PcmConsultorVO vo = new PcmConsultorVO();
		
		try {

			//ObjectMapper mapper = new ObjectMapper();
			
	        String idRegistro = (String) requestData.get("idRegistro");
	        int ctupa = Integer.parseInt((String) requestData.get("ctupa"));
	        String ruc = (String) requestData.get("ruc");
	        String userIdAndRuc = (String) requestData.get("userIdAndRuc");
		
	    	System.out.println("idRegistro="+idRegistro+" ctupa="+ctupa+" ruc="+ruc+" userIdAndRuc="+userIdAndRuc);
	    	
	        Map<String, Object> map = new HashMap<>();
	        
        	map.put("Ln_IdMaestra", idRegistro);
        	map.put("Ln_CTupa", ctupa); 
        	map.put("Ls_Ruc", ruc);
        	map.put("Ln_IdTipoEnvio", 1);
	        map.put("Ls_Usuario", userIdAndRuc);
	        map.put("Ls_Ip", request.getRemoteAddr());
	        
	        vo = pcmConsultorService.enviarConsultora(map);
	        
	        // 성공 응답
			Map<String, Object> response = new HashMap<>();
			response.put("success", true);
			response.put("message", vo.getDescription());
			return new ResponseEntity<>(response, HttpStatus.OK);
	    			
        } catch (Exception e) {
        	e.printStackTrace();
        	
			String message = messageSource.getMessage("error.internal_server_error", null,LocaleContextHolder.getLocale());
			Map<String, Object> errorResponse = new HashMap<>();
			errorResponse.put("success", false);
			errorResponse.put("message", message + " " + vo.getDescription());
			return new ResponseEntity<>(errorResponse, HttpStatus.OK);
        }
	}

}

