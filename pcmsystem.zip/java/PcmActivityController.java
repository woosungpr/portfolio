package com.peru.minero;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.peru.minero.service.CommonService;
import com.peru.minero.service.PcmActivityService;
import com.peru.minero.utils.Utilities;
import com.peru.minero.vo.PcmActivityVO;

/**
 * @author yang woosung
 * 
 * * 작성일자 : 2024. 04. 11 ~
 * * 화면 ID : DE-221_UI-0207
 * * 프로그램 ID : DE-231_PG-0000-001-06
				DE-231_PG-0000-001-32
				DE-231_PG-0207-004-39
				
 * PCM ACTIVIDADES DE CIERRE (폐광 활동) Controller
 */


@Controller
public class PcmActivityController {
	
	private static final Logger logger  = LoggerFactory.getLogger(PcmActivityController.class);
	
	@Value("${constants.idProcedimiento}")
	private String idProcedimiento;
	
	@Autowired
	private CommonService commonService;
	
	@Autowired
	private PcmActivityService pcmActivityService;

	
	// -------------------------------------------------------------
	/**
	 *  Method for Initializing the Screen.
	 *  @param model
	 *  @param idClient
	 *  @param USUARIO_LOGIN
	 *  @param idEstudio
	 *  @param codigoExpediente
	 *  @param idMenu
	 *  @param mineraNombre
	 *  @return (String) "pcm/pcmActivity"
	 */
	@RequestMapping(value = "/pcmActivity", method = RequestMethod.GET)
	public String pcmActivity(Model model,
							@RequestParam("idClient")String idClient,
							@RequestParam("USUARIO_LOGIN")String userIdAndRuc,
							@RequestParam("idEstudio")String idEstudio,
							@RequestParam("codigoExpediente")String codigoExpediente,
							@RequestParam("idMenu") String idMenu,
							@RequestParam("mineraNombre")String mineraNombre
		) {
		logger.info("The Cotroller is {}.", "pcmActivity");
		
		Map<String, Object> map = new HashMap<>();
        map.put("idEstudio", idEstudio);
        map.put("idMenu", idMenu);
        map.put("idFuente", 98);
		
        model.addAttribute("validateMsg", commonService.getCommonValidateMessage(map));
		
        //
		model.addAttribute("Ln_IdProcedimiento", Integer.parseInt(idProcedimiento));
		model.addAttribute("Li_IdProcedimiento", Integer.parseInt(idProcedimiento));
		model.addAttribute("Ln_TipoEstudio", 7);
		model.addAttribute("idCategoria", 7);
		model.addAttribute("idTipoEvaluacion", 2);
		model.addAttribute("idClient", idClient);
		model.addAttribute("userIdAndRuc", userIdAndRuc);
		model.addAttribute("idEstudio", idEstudio);
		model.addAttribute("codigoExpediente", codigoExpediente);
		model.addAttribute("idMenu", idMenu);
		model.addAttribute("mineraNombre", mineraNombre);
		
		
		return "pcm/pcmActivity";
	}
	
	// -------------------------------------------------------------
	/**
	 *  Method for Getting PCM Activity List Data
	 *  @param model
	 *  @param idEstudio
	 *  @param idActividad
	 *  @return (List<PcmActivityVO>) pcmActivityVOList
	 */
	@RequestMapping(value = "/getPcmActivityList", method = RequestMethod.POST)
	@ResponseBody
	public List<PcmActivityVO> getPcmActivityList(Model model,
			@RequestParam("idEstudio") int idEstudio,
			@RequestParam(value  = "idActividad", required = false) Integer idActividad) {

		 
	    Map<String, Object> params = new HashMap<>();
	    params.put("idEstudio", idEstudio);
	    List<PcmActivityVO> pcmActivityVOList = null;
	    
	    try {
	    	
		    if( idActividad != null ) {
		    	params.put("idActividad", idActividad);
		    }else {
		        // Optional: If you don't want to include it in params when null
		        params.put("idActividad", null); // Uncomment if needed
		    }
		    
			pcmActivityVOList = (List<PcmActivityVO>) pcmActivityService.getPcmActivityList(params);
			
	    } catch (Exception e) {
			e.printStackTrace();
	    }
	    
		return pcmActivityVOList;
	}
	
	// -------------------------------------------------------------
	/**
	 *  Method for Inserting PCM Activity Data
	 *  @param requestData
	 *  @param request
	 *  @return ResponseEntity<Map<String, Object>>
	 */
	@RequestMapping(value = "/pcmActivity/save", method = RequestMethod.POST)
	@ResponseBody
	public ResponseEntity<Map<String, Object>> savePcmActivity(@RequestBody Map<String, Object> requestData, HttpServletRequest request) {
		try {
			
			requestData.put("Ls_Ip", Utilities.getClientIp(request));
			
			Map<String, Object> params = new HashMap<>();
			
			params.put("idEstudio",    requestData.get("Ln_IdEstudio"));
			params.put("idComponente", requestData.get("Ln_IdComponente"));
			params.put("idActividad",  requestData.get("Ln_IdActividad"));
			params.put("idEtapa",      requestData.get("Ln_IdEtapa"));
			
			int cieCnt = pcmActivityService.getPcmActCieCnt(params);
			
			if(cieCnt > 0){
				requestData.put("Ls_CodOperacion", "I");
			}else {
				requestData.put("Ls_CodOperacion", "U");
			}
			
	        // pcmActivityService를 통해 sp_actividades_iud 메서드 호출
			PcmActivityVO result = pcmActivityService.savePcmActivity(requestData);
	        
			HttpStatus httpStatus = HttpStatus.OK;
			
	        // 응답 데이터 구성
	        Map<String, Object> responseData = new HashMap<>();
	        if(result != null) {
		        responseData.put("status",      result.getResponseIdStatus() );
		        responseData.put("description", result.getResponseDescripcion());
		        responseData.put("maestra",     result.getResponseMaestra() );
		        
		        logger.info("========== sp_actividades_iud RESPONSE_ID_STATUS "    + result.getResponseIdStatus());
		        logger.info("========== sp_actividades_iud RESPONSE_DESCRIPCION " + result.getResponseDescripcion());
		        logger.info("========== sp_actividades_iud RESPONSE_MAESTRA "     + result.getResponseMaestra());
		        
		        // HTTP 상태 코드 결정
		        Integer responseIdStatus = result.getResponseIdStatus();  // Null 체크

		        if (responseIdStatus != null) {
		            httpStatus = (responseIdStatus == 0) ? HttpStatus.OK : HttpStatus.BAD_REQUEST;
		        } else {
		            // responseIdStatus가 null일 경우 기본값 설정 또는 예외 처리
		            httpStatus = HttpStatus.BAD_REQUEST;  // 기본적으로 BAD_REQUEST로 처리
		            logger.error("responseIdStatus is null.");
		        }
	        }
	        
	        return new ResponseEntity<>(responseData, httpStatus);
	        
	    } catch (Exception e) {
	    	e.printStackTrace();
	        // 예외 처리
	        Map<String, Object> errorResponse = new HashMap<>();
	        errorResponse.put("status", -1);
	        errorResponse.put("description", "내부 서버 오류가 발생했습니다.");
	        errorResponse.put("result", 0);
	        
	        return new ResponseEntity<>(errorResponse, HttpStatus.INTERNAL_SERVER_ERROR);
	    }
	}
	
	
	@GetMapping("/pcmActivityOld")
    public String getPcmProjectAreaOld() {
		 return "pcm/pcmActivityOld";
    }
	
	
}
