"""
SafeStore AI · Vision 모듈
무인매장 영상 기반 이상행동/화재/사람 감지
"""
