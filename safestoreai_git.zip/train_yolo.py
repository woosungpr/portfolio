from ultralytics import YOLO

if __name__ == "__main__":

    model = YOLO("yolov8n.pt")

    model.train(
        data=r"C:\Users\Admin\Desktop\fire_dataset\data.yaml",
        epochs=100,
        imgsz=640,
        batch=16,
        workers=0,      # 먼저 0으로 테스트
        device=0,
        cache=True,
        project="runs_fire",
        name="fire_start_detection"
    )

    print("학습 완료")