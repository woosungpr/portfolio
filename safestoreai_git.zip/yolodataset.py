import cv2
import xml.etree.ElementTree as ET
from pathlib import Path

VIDEO_DIR = r"C:\Users\Admin\Downloads\238-2.실내(편의점,_매장)_사람_이상행동_데이터\01-1.정식개방데이터\Training\01.원천데이터"
XML_DIR = r"C:\Users\Admin\Downloads\238-2.실내(편의점,_매장)_사람_이상행동_데이터\01-1.정식개방데이터\Training\02.라벨링데이터"

OUT_IMG = r"C:\Users\Admin\Desktop\fire_dataset\images\train"
OUT_LBL = r"C:\Users\Admin\Desktop\fire_dataset\labels\train"

WIDTH = 1920
HEIGHT = 1080

Path(OUT_IMG).mkdir(parents=True, exist_ok=True)
Path(OUT_LBL).mkdir(parents=True, exist_ok=True)

classes = {
    "fire_start": 0,
    "fire_end": 1
}

for xml_file in Path(XML_DIR).glob("*.xml"):

    tree = ET.parse(xml_file)
    root = tree.getroot()

    mp4_file = Path(VIDEO_DIR) / (xml_file.stem + ".mp4")

    if not mp4_file.exists():
        continue

    cap = cv2.VideoCapture(str(mp4_file))

    tracks = []

    for track in root.findall("track"):

        label = track.attrib.get("label")

        if label not in classes:
            continue

        for box in track.findall("box"):

            frame_no = int(box.attrib["frame"])

            xtl = float(box.attrib["xtl"])
            ytl = float(box.attrib["ytl"])
            xbr = float(box.attrib["xbr"])
            ybr = float(box.attrib["ybr"])

            tracks.append(
                (frame_no, label, xtl, ytl, xbr, ybr)
            )

    for frame_no, label, xtl, ytl, xbr, ybr in tracks:

        cap.set(cv2.CAP_PROP_POS_FRAMES, frame_no)

        ret, frame = cap.read()

        if not ret:
            continue

        img_name = f"{xml_file.stem}_{frame_no:04d}.jpg"

        cv2.imwrite(
            str(Path(OUT_IMG) / img_name),
            frame
        )

        x_center = ((xtl + xbr) / 2) / WIDTH
        y_center = ((ytl + ybr) / 2) / HEIGHT

        w = (xbr - xtl) / WIDTH
        h = (ybr - ytl) / HEIGHT

        cls = classes[label]

        with open(
            Path(OUT_LBL) / img_name.replace(".jpg", ".txt"),
            "w"
        ) as f:

            f.write(
                f"{cls} {x_center} {y_center} {w} {h}\n"
            )

    cap.release()

print("변환 완료")
