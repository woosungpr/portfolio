""""
============================================================
Step 3. 실시간 감지 - YOLO Pose + 학습된 분류기
============================================================
"""

import os
import cv2
import math
import time
import joblib
import collections
import numpy as np
import torch
from ultralytics import YOLO

from PIL import Image
from PIL import ImageDraw
from PIL import ImageFont

# from fastapi import FastAPI
# from fastapi.responses import StreamingResponse
# app = FastAPI()

latest_frame = None
ai_running = False

# 화재/연기 연속 감지 카운터
smoke_count = 0
fire_count = 0
assault_count = 0

# 화재/연기 최종 확정 후 유지(hold)를 위한 마지막 박스/시각
last_fire_boxes  = []
last_fire_time   = 0.0
last_smoke_boxes = []
last_smoke_time  = 0.0

pose_model = None
seg_model = None
fire_model = []
tracker = None
cfg = None


def reset_detection_state():
    """새 영상 파일로 전환될 때, 이전 영상에서 누적된 화재/연기/폭행 상태를 초기화.
    (CCTV 실시간 스트림 재연결 시에는 호출하지 않음 - 진행 중인 감지가 끊기지 않도록)"""
    global smoke_count, fire_count, assault_count
    global last_fire_boxes, last_fire_time, last_smoke_boxes, last_smoke_time

    smoke_count   = 0
    fire_count    = 0
    assault_count = 0
    last_fire_boxes  = []
    last_fire_time   = 0.0
    last_smoke_boxes = []
    last_smoke_time  = 0.0

    # 사람 추적 상태(이전 영상의 pid별 이력)도 새 영상에 영향 주지 않도록 초기화
    if tracker is not None:
        tracker.prev_kps.clear()
        tracker.pred_hist.clear()
        tracker.last_alert.clear()
        tracker.alert_state.clear()
        if hasattr(tracker, "pos_hist"):
            tracker.pos_hist.clear()


FONT = None

# 전역 감지 상태 (dashboard가 polling으로 읽음)
detection_status = {
    "pose_fall":   False,   # 쓰러짐
    # "pose_loiter": False,   # 배회
    "fire":        False,   # 화재
    # "smoke":       False,   # 연기
    "assault":     False,   # 추가
    "intrusion":   False,   # 추가
}

# ============================================================
# 설정
# ============================================================
class Config:
    INTRUSION_START_HOUR = 0   # 테스트: 항상 사람 감지
    INTRUSION_END_HOUR   = 24

    DATASET_DIR = r"data\abnormal"

    YOLO_POSE_MODEL = "ml/model/yolov8m-pose.pt"
    YOLO_SEG_MODEL  = "ml/model/yolov8n-seg.pt"
    YOLO_FIRE_MODELS = [
        "ml/model/fire_best.pt",
        # "ml/model/fire_best1.pt",  # 사람 형태 오탐(흰옷/불 든 사람)이 심해 임시 제외
    ]

    # ── 화재 감지 기준 최종 최적화 (초기 방화 영상 대응) ──
    FIRE_CONF_THRESHOLD  = 0.4  
    SMOKE_CONF_THRESHOLD = 0.85   
    FIRE_MIN_AREA        = 2000   # 면적은 현재 5000 이상으로 들어오므로 2000 유지
    FIRE_STREAK_NEED     = 2      # ★ 3 -> 2로 완화 (2프레임만 들어와도 바로 박스 고정)
    SMOKE_STREAK_NEED    = 5
    FIRE_HOLD_SECONDS    = 2.0    # ★ 화재 확정 후, 탐지가 잠깐 끊겨도 이 시간(초) 동안은 표시 유지
    SMOKE_HOLD_SECONDS   = 2.0

    MODEL_DIR  = "ml/model"
    CLASSIFIER = "xgboost"

    CONF_PERSON    = 0.50      # 추가
    CONF_THRESHOLD = 0.15 #0.10
    # LOITER_THRESHOLD = 0.5
    ALERT_DURATION = 3.0
    HISTORY_LEN    = 10

    SAVE_EVENTS = True
    SAVE_DIR    = "output/realtime_events"
    
    # 영상 소스: 라즈베리파이 Cloudflare URL (또는 로컬 IP)
    # None이면 기존 mp4 파일 루프 모드로 동작
    CCTV_URL = "https://retirement-downloading-editor-hair.trycloudflare.com/video"
    # CCTV_URL = None  # mp4 파일 모드로 돌릴 때
    
    # 폭행 감지: 두 사람 이상 + 박스 겹침 + 빠른 손목 움직임
    ASSAULT_IOU_THRESHOLD  = 0.05   # 박스 겹침 비율 (단순 근접/보행 오탐 방지로 상향)
    ASSAULT_WRIST_SPEED    = 0.10   # 손목 속도 임계값 (일반 보행/제스처 오탐 방지로 상향)
    ASSAULT_MIN_PERSONS    = 2      # 최소 인원수
    ASSAULT_STREAK_NEED    = 3      # 연속 프레임 조건 충족 시에만 폭행으로 최종 판정
    
    # 사람 감지: 영업시간 외 사람 감지
    INTRUSION_START_HOUR   = 22     # 사람 감지 시작 시각 (22시)
    INTRUSION_END_HOUR     = 7      # 사람 감지 종료 시각 (07시)
    
    
# ============================================================
# 특징 추출 (step1과 동일 로직)
# ============================================================

KP = {
    "nose":0,
    "l_shoulder":5, "r_shoulder":6,
    "l_elbow":7,    "r_elbow":8,
    "l_wrist":9,    "r_wrist":10,
    "l_hip":11,     "r_hip":12,
    "l_knee":13,    "r_knee":14,
    "l_ankle":15,   "r_ankle":16,
}


def safe_angle(a, b, c) -> float:
    ax, ay = a[0]-b[0], a[1]-b[1]
    cx, cy = c[0]-b[0], c[1]-b[1]
    dot = ax*cx + ay*cy
    mag = math.hypot(ax,ay) * math.hypot(cx,cy)
    if mag < 1e-3: return 0.0
    return math.degrees(math.acos(max(-1.0, min(1.0, dot/mag))))


def extract_features(kps: np.ndarray, prev_kps=None) -> dict:
    valid = [(kps[i][0]>0 or kps[i][1]>0) for i in range(17)]
    all_x = [kps[i][0] for i in range(17) if valid[i]]
    all_y = [kps[i][1] for i in range(17) if valid[i]]

    x_min = min(all_x) if all_x else 0
    x_max = max(all_x) if all_x else 1
    y_min = min(all_y) if all_y else 0
    y_max = max(all_y) if all_y else 1
    x_range = (x_max-x_min) or 1
    y_range = (y_max-y_min) or 1

    feat = {}
    kp_names = ["nose","l_eye","r_eye","l_ear","r_ear",
                "l_shoulder","r_shoulder","l_elbow","r_elbow",
                "l_wrist","r_wrist","l_hip","r_hip",
                "l_knee","r_knee","l_ankle","r_ankle"]

    for i, name in enumerate(kp_names):
        if valid[i]:
            feat[f"{name}_x"] = (kps[i][0]-x_min)/x_range
            feat[f"{name}_y"] = (kps[i][1]-y_min)/y_range
        else:
            feat[f"{name}_x"] = -1.0
            feat[f"{name}_y"] = -1.0

    ls=kps[5]; rs=kps[6]; lh=kps[11]; rh=kps[12]
    if all(valid[i] for i in [5,6,11,12]):
        s_mid=((ls[0]+rs[0])/2,(ls[1]+rs[1])/2)
        h_mid=((lh[0]+rh[0])/2,(lh[1]+rh[1])/2)
        dx=h_mid[0]-s_mid[0]; dy=h_mid[1]-s_mid[1]
        feat["body_angle"] = abs(math.degrees(math.atan2(abs(dx),abs(dy)+1e-3)))
    else:
        feat["body_angle"] = -1.0

    w=x_max-x_min; h=y_max-y_min
    feat["body_aspect"]   = w/(h+1e-3)
    feat["body_height"]   = y_range/(x_range+1e-3)
    feat["shoulder_width"]= math.hypot(rs[0]-ls[0],rs[1]-ls[1])/(x_range+1e-3) if valid[5] and valid[6] else -1.0
    feat["center_y"]      = (sum(all_y)/len(all_y)-y_min)/(y_range+1e-3) if all_y else -1.0

    feat["head_shoulder_diff"] = (ls[1]-kps[0][1])/(y_range+1e-3) if valid[0] and valid[5] else -1.0

    feat["l_elbow_angle"] = safe_angle(kps[5],kps[7],kps[9])  if all(valid[i] for i in [5,7,9])  else -1.0
    feat["r_elbow_angle"] = safe_angle(kps[6],kps[8],kps[10]) if all(valid[i] for i in [6,8,10]) else -1.0
    feat["l_knee_angle"]  = safe_angle(kps[11],kps[13],kps[15]) if all(valid[i] for i in [11,13,15]) else -1.0
    feat["r_knee_angle"]  = safe_angle(kps[12],kps[14],kps[16]) if all(valid[i] for i in [12,14,16]) else -1.0

    if prev_kps is not None:
        lw=math.hypot(kps[9][0]-prev_kps[9][0], kps[9][1]-prev_kps[9][1])
        rw=math.hypot(kps[10][0]-prev_kps[10][0],kps[10][1]-prev_kps[10][1])
        feat["l_wrist_speed"]  = lw/(x_range+1e-3)
        feat["r_wrist_speed"]  = rw/(x_range+1e-3)
        feat["max_wrist_speed"]= max(lw,rw)/(x_range+1e-3)
    else:
        feat["l_wrist_speed"] = feat["r_wrist_speed"] = feat["max_wrist_speed"] = -1.0

    feat["ankle_y_diff"] = abs(kps[15][1]-kps[16][1])/(y_range+1e-3) if valid[15] and valid[16] else -1.0
    feat["bbox_aspect"]  = -1.0

    return feat


# ============================================================
# 슬라이딩 윈도우 예측 (연속 N프레임 이상 이상이면 경보)
# ============================================================

class PersonTracker:
    def __init__(self, cfg: Config, feat_cols, classifier):
        self.cfg        = cfg
        self.feat_cols  = feat_cols
        self.classifier = classifier
        self.prev_kps   = {}          # pid → kps
        self.pred_hist  = {}          # pid → deque of proba
        self.last_alert = {}          # pid → time
        self.alert_state= {}          # pid → bool
        self.pos_hist = {}   # pid → deque of (cx, cy)  ← 추가

    def predict(self, pid: int, kps: np.ndarray, box) -> dict:
        prev = self.prev_kps.get(pid)
        feat = extract_features(kps, prev)
        self.prev_kps[pid] = kps.copy()

        # bbox aspect 추가
        bw = float(box[2]-box[0]); bh = float(box[3]-box[1])
        feat["bbox_aspect"] = bw/(bh+1e-3)

        # 특징 벡터 정렬
        x = np.array([feat.get(c,-1.0) for c in self.feat_cols], dtype=np.float32)
        x = np.where(x < 0, 0.0, x).reshape(1,-1)

        # 확률 예측
        try:
            proba = self.classifier.predict_proba(x)[0]
            # print("proba =", proba)
            prob_abnormal = proba[1] if len(proba) > 1 else proba[0]
        except:
            prob_abnormal = 0.0

        # 슬라이딩 윈도우
        if pid not in self.pred_hist:
            self.pred_hist[pid] = collections.deque(maxlen=self.cfg.HISTORY_LEN)
        self.pred_hist[pid].append(prob_abnormal)

        avg_prob = float(np.mean(self.pred_hist[pid]))
        is_alert = avg_prob >= self.cfg.CONF_THRESHOLD

        # print(
        #     f"PID={pid} "
        #     f"현재={prob_abnormal:.3f} "
        #     f"평균={avg_prob:.3f}"
        # )

        now = time.time()
        if is_alert:
            self.last_alert[pid]  = now
            self.alert_state[pid] = True
        elif pid in self.last_alert:
            if now - self.last_alert[pid] > self.cfg.ALERT_DURATION:
                self.alert_state[pid] = False

        # if avg_prob > 0.05:
            # print(
            #     f"[ALERT 후보] "
            #     f"PID={pid} "
            #     f"prob={avg_prob:.3f}"
            # )
    
        # 중심점 이력 저장
        cx = (box[0] + box[2]) / 2
        cy = (box[1] + box[3]) / 2
        if pid not in self.pos_hist:
            self.pos_hist[pid] = collections.deque(maxlen=30)  # 30프레임
        self.pos_hist[pid].append((cx, cy))

        # 이동 거리 계산
        move_dist = 0.0
        ph = self.pos_hist[pid]
        if len(ph) >= 2:
            dx = ph[-1][0] - ph[0][0]
            dy = ph[-1][1] - ph[0][1]
            move_dist = math.hypot(dx, dy)
            
        return {
            "pid":        pid,
            "prob":       avg_prob,
            "is_alert":   self.alert_state.get(pid, False),
            "feat":       feat,
            "move_dist":  move_dist,   # ← 추가
        }


def overlay_mask(img, mask, color, alpha=0.40):
    # out = img.copy()
    # m   = mask.astype(bool)
    # out[m] = (out[m]*(1-alpha)+np.array(color)*alpha).astype(np.uint8)
    # cnts,_ = cv2.findContours(mask.astype(np.uint8),cv2.RETR_EXTERNAL,cv2.CHAIN_APPROX_SIMPLE)
    # cv2.drawContours(out,cnts,-1,color,2)
    # return out
    return img


# ============================================================
# 프레임 처리
# ============================================================

ALERT_COLOR  = (0, 0, 255)
NORMAL_COLOR = (80, 200, 80)
MID_COLOR    = (0, 165, 255)

import math

def detect_assault(person_boxes: dict, person_alerts: dict, cfg: Config) -> bool:
    """
    거리 기반 + 손목 속도 기반 폭행 감지 (IoU 오류 완벽 우회)
    """
    try:
        pids = list(person_boxes.keys())
        if len(pids) < getattr(cfg, 'ASSAULT_MIN_PERSONS', 2):
            return False

        for i in range(len(pids)):
            for j in range(i + 1, len(pids)):
                pidA, pidB = pids[i], pids[j]
                
                boxA = person_boxes[pidA]
                boxB = person_boxes[pidB]
                if len(boxA) < 4 or len(boxB) < 4:
                    continue
                
                # 1. 두 사람 박스의 중심점(Center) 계산
                centerA_x = (float(boxA[0]) + float(boxA[2])) / 2.0
                centerA_y = (float(boxA[1]) + float(boxA[3])) / 2.0
                centerB_x = (float(boxB[0]) + float(boxB[2])) / 2.0
                centerB_y = (float(boxB[1]) + float(boxB[3])) / 2.0
                
                # 2. 중심점 사이의 픽셀 거리 계산
                dist = math.sqrt((centerA_x - centerB_x)**2 + (centerA_y - centerB_y)**2)
                
                # 디버깅 로그 출력
                # print(f"[폭행감지-루프] PID {pidA}↔{pidB} 중심점 거리={dist:.1f}px")

                # 3. 기준 거리 이내인지 확인 (예: 화면 해상도에 따라 300~400픽셀 이내)
                # 테스트를 위해 우선 400픽셀로 넉넉하게 잡거나 cfg에 ASSAULT_DIST_THRESHOLD를 추가하세요.
                max_dist = getattr(cfg, 'ASSAULT_DIST_THRESHOLD', 400.0)
                if dist > max_dist:
                    continue
                
                # print(f"★ [폭행조건-근접통과] PID {pidA}↔{pidB} 근접 확인! (거리: {dist:.1f}px)")

                # 4. 손목 속도 확인
                for pid in (pidA, pidB):
                    res = person_alerts.get(pid)
                    if res is None:
                        continue
                    
                    feat = res.get("feat", {})
                    wrist_speed = feat.get("max_wrist_speed", 0.0)
                    
                    # print(f"   -> PID {pid}의 현재 wrist_speed={wrist_speed:.3f}")

                    # 테스트 통과를 위해 속도 임계값도 콘솔 확인 후 필요시 낮춰줍니다.
                    wrist_thresh = getattr(cfg, 'ASSAULT_WRIST_SPEED', 2.0)
                    if wrist_speed >= wrist_thresh:
                        # print(f"🚨 [폭행감지 최종 확정!!] PID {pid} 속도={wrist_speed:.3f}")
                        return True

    except Exception as e:
        print(f"[detect_assault 오류 방지]: {e}")
        
    return False


# def calc_iou(boxA, boxB):
#     """
#     box = [xmin, ymin, xmax, ymax] 형태의 겹침 비율(IoU) 계산
#     안전하게 파이썬 기본 float 데이터로 변환 후 연산하여 멈춤 현상 방지
#     """
#     try:
#         # GPU 텐서나 넘파이 타입일 가능성을 배제하기 위해 추출 및 변환
#         xA = max(float(boxA[0]), float(boxB[0]))
#         yA = max(float(boxA[1]), float(boxB[1]))
#         xB = min(float(boxA[2]), float(boxB[2]))
#         yB = min(float(boxA[3]), float(boxB[3]))

#         # 교집합 면적
#         interArea = max(0.0, xB - xA) * max(0.0, yB - yA)

#         # 각 박스의 면적
#         boxAArea = (float(boxA[2]) - float(boxA[0])) * (float(boxA[3]) - float(boxA[1]))
#         boxBArea = (float(boxB[2]) - float(boxB[0])) * (float(boxB[3]) - float(boxB[1]))

#         # 합집합 면적
#         unionArea = boxAArea + boxBArea - interArea
#         if unionArea <= 0:
#             return 0.0

#         return interArea / unionArea
#     except Exception as e:
#         # 혹시 모를 좌표 데이터 에러 발생 시 프로그램이 멈추지 않도록 예외 처리
#         print(f"[IoU 에러 발생] {e}")
#         return 0.0



# def detect_assault(person_boxes: dict, person_alerts: dict, cfg: Config) -> bool:
#     """
#     폭행 감지 휴리스틱 (안전성 강화 버전)
#     """
#     try:
#         pids = list(person_boxes.keys())
        
#         # 사람이 2명 미만이면 바로 리턴
#         if len(pids) < getattr(cfg, 'ASSAULT_MIN_PERSONS', 2):
#             return False

#         for i in range(len(pids)):
#             for j in range(i + 1, len(pids)):
#                 pidA, pidB = pids[i], pids[j]
                
#                 # 박스 데이터 데이터 검증
#                 if len(person_boxes[pidA]) < 4 or len(person_boxes[pidB]) < 4:
#                     continue
                    
#                 iou = calc_iou(person_boxes[pidA], person_boxes[pidB])

#                 # [디버깅 로그] 콘솔창에 IoU가 실제로 찍히는지 확인하세요!
#                 # 만약 이 로그가 아예 안 찍힌다면 이 함수 자체가 호출이 안 되고 있는 것입니다.
#                 print(f"[폭행감지-루프] PID {pidA}↔{pidB} IoU 계산결과={iou:.3f}")

#                 # 💡 감지 테스트를 위해 기준을 대폭 낮춤 (예: 0.05 이상만 겹쳐도 통과)
#                 # 실제 환경에 맞게 cfg.ASSAULT_IOU_THRESHOLD를 0.1 정도로 낮춰 잡는 것을 권장합니다.
#                 thresh = getattr(cfg, 'ASSAULT_IOU_THRESHOLD', 0.1)
#                 if iou < thresh:
#                     continue

#                 # 박스 겹침 조건 통과 시 로그
#                 print(f"★ [폭행조건-IoU통과] PID {pidA}↔{pidB}가 기준({thresh}) 이상 겹침!")

#                 # 손목 속도 확인
#                 for pid in (pidA, pidB):
#                     res = person_alerts.get(pid)
#                     if res is None:
#                         continue
                    
#                     feat = res.get("feat", {})
#                     wrist_speed = feat.get("max_wrist_speed", 0.0)
                    
#                     print(f"   -> PID {pid}의 현재 wrist_speed={wrist_speed:.3f}")

#                     # 💡 테스트를 위해 손목 속도가 조금이라도 있으면 감지되도록 해보거나, 
#                     # 조건이 너무 엄격하면 cfg.ASSAULT_WRIST_SPEED 값을 낮춰주세요.
#                     wrist_thresh = getattr(cfg, 'ASSAULT_WRIST_SPEED', 2.0)
#                     if wrist_speed >= wrist_thresh:
#                         print(f"🚨 [폭행감지 최종 조건 충족!!] PID {pid} 속도={wrist_speed:.3f}")
#                         return True

#     except Exception as e:
#         print(f"[detect_assault 내부 오류 발생 - 영상 멈춤 방지]: {e}")
        
#     return False


def detect_intrusion(person_alerts: dict, cfg: Config) -> bool:
    """
    사람 감지:
      - 사람이 감지된 상태에서 영업시간 외(22시~07시)이면 True
      - 테스트 시에는 INTRUSION_START_HOUR/END_HOUR를 조정해서 확인
    """
    if not person_alerts:
        return False

    import datetime
    hour = datetime.datetime.now().hour
    # 22시 이후 또는 07시 이전
    return hour >= cfg.INTRUSION_START_HOUR or hour < cfg.INTRUSION_END_HOUR


def is_fallen(kps: np.ndarray) -> bool:
    """
    쓰러짐 판단 룰:
      - 어깨와 엉덩이의 y좌표 차이가 작고 (수평에 가까움)
      - 발목이 어깨보다 높거나 비슷한 높이
    """
    valid = [(kps[i][0] > 0 or kps[i][1] > 0) for i in range(17)]

    # 어깨, 엉덩이, 발목 유효성 체크
    if not all(valid[i] for i in [5, 6, 11, 12]):
        return False

    l_shoulder_y = kps[5][1]
    r_shoulder_y = kps[6][1]
    l_hip_y      = kps[11][1]
    r_hip_y      = kps[12][1]

    shoulder_y = (l_shoulder_y + r_shoulder_y) / 2
    hip_y      = (l_hip_y + r_hip_y) / 2

    # 몸통 높이 (어깨~엉덩이 y 거리)
    torso_height = abs(hip_y - shoulder_y)

    # 몸통 너비 (어깨 좌우 거리)
    torso_width  = abs(kps[5][0] - kps[6][0])

    # 쓰러짐: 몸통이 가로로 누운 경우 (너비 > 높이 * 1.5)
    if torso_width > torso_height * 1.5:
        return True

    # 발목이 어깨보다 높은 경우 (y값이 작을수록 위)
    if valid[15] and valid[16]:
        ankle_y = (kps[15][1] + kps[16][1]) / 2
        if ankle_y < shoulder_y:
            return True

    return False

def process_frame(frame, frame_idx, pose_model, seg_model,
                  tracker: PersonTracker, cfg: Config):

    annotated = frame.copy()
    frame_rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)

    # YOLO Pose + ByteTrack
    results = pose_model.track(frame, persist=True,
                               tracker="bytetrack.yaml", verbose=False)

    person_boxes  = {}
    person_alerts = {}   # pid → result dict

    for r in results:
        if r.boxes is None or r.boxes.id is None: continue
        if r.keypoints is None: continue

        boxes_xyxy    = r.boxes.xyxy.cpu().numpy()
        confs         = r.boxes.conf.cpu().numpy()    # 추가
        track_ids     = r.boxes.id.cpu().numpy().astype(int)
        keypoints_all = r.keypoints.xy.cpu().numpy()

        for idx in range(len(track_ids)):
            conf = float(confs[idx])
            if conf < cfg.CONF_PERSON:
                continue
    
            pid = int(track_ids[idx])
            kps = keypoints_all[idx]
            box = boxes_xyxy[idx]
            
            # 관절 개수 필터
            valid_kps = np.sum(
                np.any(kps > 0, axis=1)
            )

            if valid_kps < 8:
                continue

            # print(
            #     f"PID={pid}, "
            #     f"CONF={conf:.3f}, "
            #     f"KP={valid_kps}"
            # )
            
            person_boxes[pid] = list(map(int, box[:4]))
            
            if tracker is not None:
                result = tracker.predict(pid, kps, box)
                person_alerts[pid] = result

    # YOLO Seg 마스크
    masks   = []

    seg_res = seg_model(frame, classes=[0], verbose=False)
    for r in seg_res:
        if r.masks is not None:
            for m in r.masks.data.cpu().numpy():
                rm = cv2.resize(m,(frame.shape[1],frame.shape[0]))
                masks.append(rm > 0.5)

    # 마스크 오버레이
    pid_list = list(person_boxes.keys())
    for i, mask in enumerate(masks):
        if mask is None: continue
        pid = pid_list[i] if i < len(pid_list) else -1
        res = person_alerts.get(pid)
        if res and res["is_alert"]:
            color = ALERT_COLOR
        elif res and res["prob"] > 0.35:
            color = MID_COLOR
        else:
            color = NORMAL_COLOR
        annotated = overlay_mask(annotated, mask.astype(bool), color)

    # Pose 스켈레톤
    # for r in results:
    #     annotated = r.plot(img=annotated)

    # 사람별 확률 + 경보 표시
    saved = False
    for pid, res in person_alerts.items():
        box = person_boxes.get(pid)
        if not box: continue
        x1,y1,x2,y2 = box
        prob = res["prob"]

        # ── 감지 종류 판단 ──────────────────────────────────
        kps = tracker.prev_kps.get(pid)
        fallen  = kps is not None and is_fallen(kps)
        # loiter  = prob >= cfg.LOITER_THRESHOLD and not fallen

        if fallen:
            label = "쓰러짐"
            color = (0, 0, 255)        # 빨강
            thick = 3
        # elif loiter:
        #     label = "배회 의심"
        #     color = (0, 140, 255)      # 주황
        #     thick = 2
        else:
            label = f"사람 ID:{pid}"
            color = (80, 200, 80)      # 초록
            thick = 1

        cv2.rectangle(annotated, (x1, y1), (x2, y2), color, thick)
        
        # 라벨 배경 + 텍스트
        full_text = f"{label}  ID:{pid}"
        tw, th = cv2.getTextSize(full_text, cv2.FONT_HERSHEY_SIMPLEX, 0.6, 2)[0]
        ly = max(y1 - 8, 30)
        cv2.rectangle(annotated, (x1, ly - th - 6), (x1 + tw + 8, ly + 4),
                      color, -1)
        annotated = draw_korean(annotated, full_text, x1 + 4, ly - th - 4,
                                (255, 255, 255))
        

    # ────────────────────────────────────────────────────────
    # 화재/연기 검사 및 연속성 검증 (보완 완료)
    # ────────────────────────────────────────────────────────
    SMOKE_ENABLED = False
    fire_results = []
    for fm in fire_models:
        fire_results.extend(fm(frame, verbose=False))

    # 1단계: 임계값 필터를 통과한 임시 후보 박스 수집
    temp_fire_boxes = []
    smoke_boxes_drawn = []

    for model_idx, r in enumerate(fire_results):
        if r.boxes is None:
            continue

        for box in r.boxes:
            cls  = int(box.cls[0])
            conf = float(box.conf[0])
            x1, y1, x2, y2 = map(int, box.xyxy[0])
            area = (x2 - x1) * (y2 - y1)

            if cls == 0:  # Fire
                # 디버깅 로그 활성화
                # print(f"[화재후보] conf={conf:.3f} area={area} box=({x1},{y1},{x2},{y2})")
                if conf < cfg.FIRE_CONF_THRESHOLD or area < cfg.FIRE_MIN_AREA:
                    continue
                temp_fire_boxes.append((x1, y1, x2, y2))
                
            elif cls == 1 and SMOKE_ENABLED: # Smoke
                if conf < cfg.SMOKE_CONF_THRESHOLD or area < cfg.FIRE_MIN_AREA:
                    continue
                smoke_boxes_drawn.append((x1, y1, x2, y2))

    # 2단계: 프레임 연속성 상태 판정 (디바운싱 메커니즘 적용)
    global smoke_count
    global fire_count
    global assault_count
    global detection_status
    global last_fire_boxes, last_fire_time
    global last_smoke_boxes, last_smoke_time
    
    fire_in_frame = len(temp_fire_boxes) > 0
    smoke_in_frame = SMOKE_ENABLED and len(smoke_boxes_drawn) > 0

    if fire_in_frame:
        fire_count += 1
    else:
        # 프레임이 순간 튀거나 놓치더라도 카운터를 즉시 0으로 밀지 않고 1씩 감소하여 유지력 강화
        fire_count = max(0, fire_count - 1)

    if smoke_in_frame:
        smoke_count += 1
    else:
        smoke_count = max(0, smoke_count - 1)

    # 연속 누적 프레임이 기준을 달성했는지 확인 (최초 확정 판정)
    fire_streak_ok  = fire_count >= cfg.FIRE_STREAK_NEED
    smoke_streak_ok = SMOKE_ENABLED and (smoke_count >= cfg.SMOKE_STREAK_NEED)

    now = time.time()

    # 3단계: 화재가 확정(streak 충족)되면 박스/시각을 "래치"해 두고,
    #         이후 프레임에서 탐지가 잠깐 끊겨도 HOLD_SECONDS 동안은
    #         마지막 박스 위치로 계속 표시 → 깜빡임 방지
    if fire_streak_ok and fire_in_frame:
        last_fire_boxes = temp_fire_boxes
        last_fire_time  = now

    has_fire = fire_streak_ok or (
        len(last_fire_boxes) > 0 and (now - last_fire_time) <= cfg.FIRE_HOLD_SECONDS
    )

    if smoke_streak_ok and smoke_in_frame:
        last_smoke_boxes = smoke_boxes_drawn
        last_smoke_time  = now

    has_smoke = smoke_streak_ok or (
        SMOKE_ENABLED and len(last_smoke_boxes) > 0
        and (now - last_smoke_time) <= cfg.SMOKE_HOLD_SECONDS
    )

    # hold 시간이 다 지나면 래치된 박스를 비워서 다음 화재에 영향 없도록 정리
    if has_fire and (now - last_fire_time) > cfg.FIRE_HOLD_SECONDS and not fire_in_frame:
        last_fire_boxes = []
        has_fire = False

    if has_smoke and (now - last_smoke_time) > cfg.SMOKE_HOLD_SECONDS and not smoke_in_frame:
        last_smoke_boxes = []
        has_smoke = False

    # 4단계: has_fire가 True인 동안은 (현재 프레임 탐지 여부와 무관하게)
    #         래치된 마지막 박스 위치로 안정적으로 렌더링
    if has_fire:
        for (x1, y1, x2, y2) in (temp_fire_boxes if fire_in_frame else last_fire_boxes): 
            color = (0, 0, 255) # Red
            label = f"🔥 화재 감지 ({fire_count}f)"
            cv2.rectangle(annotated, (x1, y1), (x2, y2), color, 3)
            tw, th = cv2.getTextSize(label, cv2.FONT_HERSHEY_SIMPLEX, 0.8, 2)[0]
            cv2.rectangle(annotated, (x1, y1 - th - 10), (x1 + tw + 8, y1), color, -1)
            annotated = draw_korean(annotated, label, x1 + 4, y1 - th - 8, (255, 255, 255))

    # 연기 박스 출력 (활성화 시 작동)
    if has_smoke:
        for (x1, y1, x2, y2) in (smoke_boxes_drawn if smoke_in_frame else last_smoke_boxes):
            color = (100, 100, 100)
            label = "💨 연기 감지"
            cv2.rectangle(annotated, (x1, y1), (x2, y2), color, 3)
            tw, th = cv2.getTextSize(label, cv2.FONT_HERSHEY_SIMPLEX, 0.8, 2)[0]
            cv2.rectangle(annotated, (x1, y1 - th - 10), (x1 + tw + 8, y1), color, -1)
            annotated = draw_korean(annotated, label, x1 + 4, y1 - th - 8, (255, 255, 255))

    # ── 인체/기타 감지 상태 연동 ──────────────────────────────────────
    for pid, res in person_alerts.items():
        kps = tracker.prev_kps.get(pid)
        if kps is not None and is_fallen(kps):
            res["is_alert"] = True
        else:
            res["is_alert"] = False
            
    has_alert = any(is_fallen(tracker.prev_kps[pid]) for pid in person_alerts if pid in tracker.prev_kps)
    # has_loiter = any(r["prob"] >= cfg.LOITER_THRESHOLD and not is_fallen(tracker.prev_kps.get(pid, np.zeros((17,2)))) for pid, r in person_alerts.items())

    # 폭행 판정
    assault_candidate = detect_assault(person_boxes, person_alerts, cfg)
    assault_count = assault_count + 1 if assault_candidate else max(0, assault_count - 1)
    has_assault   = assault_count >= cfg.ASSAULT_STREAK_NEED
    
    has_intrusion = len(person_alerts) > 0
    
    # 전역 대시보드 스태터스 갱신
    detection_status = {
        "pose_fall":   has_alert,
        #"pose_loiter": has_loiter,
        "fire":        has_fire,
        #"smoke":       has_smoke,
        "assault":     has_assault,
        "intrusion":   has_intrusion,
    }
      
    # HUD
    h,w = annotated.shape[:2]
    
    # 폭행 경보 오버레이
    # if has_assault:
    #     tw, th = cv2.getTextSize("폭행 의심", cv2.FONT_HERSHEY_SIMPLEX, 1.0, 2)[0]
    #     # cv2.rectangle(annotated, (w//2 - tw//2 - 10, 55),
    #     #                          (w//2 + tw//2 + 10, 55 + th + 10), (0, 0, 200), -1)
    #     annotated = draw_korean(annotated, "폭행 의심",
    #                             w//2 - tw//2, 55, (255, 255, 255))

    # 사람 경보 오버레이
    # if has_intrusion:
    #     tw, th = cv2.getTextSize("? 사람 감지", cv2.FONT_HERSHEY_SIMPLEX, 1.0, 2)[0]
    #     # cv2.rectangle(annotated, (w//2 - tw//2 - 10, 100),
    #     #                          (w//2 + tw//2 + 10, 100 + th + 10), (128, 0, 128), -1)
    #     annotated = draw_korean(annotated, "? 사람 감지",
    #                             w//2 - tw//2, 100, (255, 255, 255))
    
    ov  = annotated.copy()
    cv2.rectangle(ov,(0,0),(w,45),(15,15,15),-1)
    annotated = cv2.addWeighted(ov,0.65,annotated,0.35,0)

    alert_count = sum(1 for r in person_alerts.values() if r["is_alert"])
    hud_color   = ALERT_COLOR if alert_count > 0 else (200,200,200)
    status      = f"[ALERT] {alert_count}명" if alert_count>0 else "정상"

    cv2.putText(annotated,f"F:{frame_idx}",(10,30),
                cv2.FONT_HERSHEY_SIMPLEX,0.75,(200,200,200),2)
    # cv2.putText(annotated,status,(200,30),
    #             cv2.FONT_HERSHEY_SIMPLEX,0.85,hud_color,2)
    
    # 한글은 PIL 사용
    annotated = draw_korean(annotated, status, 200, 5, hud_color)
    
    cv2.putText(annotated,"YOLO-Seg",(w-150,30),
                cv2.FONT_HERSHEY_SIMPLEX,0.65,(180,180,255),2)

    return annotated


def get_all_videos(root_dir):

    videos = []

    for root, dirs, files in os.walk(root_dir):

        for f in files:

            if f.lower().endswith(".mp4"):

                videos.append(
                    os.path.join(root, f)
                )

    return sorted(videos)

def get_videos(root_dir):
    videos = []
    
    # 지정한 폴더 내의 파일/폴더 목록만 가져옴 (하위 폴더 안은 뒤지지 않음)
    for f in os.listdir(root_dir):
        # 파일 경로를 생성
        full_path = os.path.join(root_dir, f)
        
        # '파일'이 맞고, 확장자가 .mp4인 경우만 추가
        if os.path.isfile(full_path) and f.lower().endswith(".mp4"):
            videos.append(full_path)

    return sorted(videos)

def draw_korean(img, text, x, y, color):
    img_pil = Image.fromarray(img)

    draw = ImageDraw.Draw(img_pil)

    draw.text(
        (x, y),
        text,
        font=FONT,
        fill=(color[2], color[1], color[0])
    )

    return np.array(img_pil)

import time

def generate_frames():

    global latest_frame
    try:
        while True:

            if latest_frame is None:
                time.sleep(0.1)
                continue

            ret, buffer = cv2.imencode(
                '.jpg',
                latest_frame
            )

            if not ret:
                continue
            
            frame = buffer.tobytes()

            yield (
                b'--frame\r\n'
                b'Content-Type: image/jpeg\r\n\r\n'
                + frame +
                b'\r\n'
            )
    except GeneratorExit:
        # 클라이언트 연결 종료 시 정상 종료
        pass        


def load_font():
    global FONT

    BASE_DIR = os.path.dirname(
        os.path.abspath(__file__)
    )
        
    FONT_PATH = os.path.join(
        BASE_DIR,
        "..",
        "frontend",
        "fonts",
        "malgun.ttf"
    )
        
    if FONT is None:
        FONT = ImageFont.truetype(
            FONT_PATH,
            24
        )
        
import threading
# import uvicorn 

           
# ============================================================
# 메인
# ============================================================
# if __name__ == "__main__":

def run_ai_detection():    
    print("###### run_ai_detection 시작")
    
    load_font()
    
    global pose_model
    global seg_model
    global fire_models
    global tracker
    global cfg
    
    global latest_frame
    
    cfg    = Config()
    device = "cuda" if torch.cuda.is_available() else "cpu"
    print(f"디바이스: {device}")

    # 분류기 로드
    clf_path   = os.path.join(cfg.MODEL_DIR, f"{cfg.CLASSIFIER}.pkl")
    feat_path  = os.path.join(cfg.MODEL_DIR, "feat_cols.pkl")

    if not os.path.exists(clf_path):
        print(f"[오류] 분류기 없음: {clf_path}")
        print("       먼저 step1 → step2 실행 필요")
        exit(1)

    print(f"분류기 경로: {clf_path}")
    print("분류기 로드 시작")
    classifier = joblib.load(clf_path)
    feat_cols  = joblib.load(feat_path)
    print(f"분류기 로드 완료: {len(feat_cols)}개 특징")

    # 모델 로드
    print("YOLO Pose 모델 로드 시작")
    pose_model = YOLO(cfg.YOLO_POSE_MODEL)
    print("YOLO Pose 완료")
    print("YOLO Seg 모델 로드 시작")
    seg_model  = YOLO(cfg.YOLO_SEG_MODEL)
    print("YOLO Seg 완료")
    print("Fire 모델 로드 시작")
    fire_models = [YOLO(p) for p in cfg.YOLO_FIRE_MODELS]
    print("Fire 모델 완료")
    for m, p in zip(fire_models, cfg.YOLO_FIRE_MODELS):
        print(f"  - {p}: {m.names}")
    
    print("PersonTracker 초기화 시작")
    tracker = PersonTracker(cfg, feat_cols, classifier)
    print("PersonTracker 완료 → 스트림 시작")

    print("화재 모델 로드 완료")
    
    # print("LAST")
    # model = YOLO(r"models\fire_last.pt")
    # print(model.names)ai-video
    
    # ── 영상 소스 결정 ──────────────────────────────────────
    # if cfg.CCTV_URL:
    #     # 실시간 CCTV 스트림 모드 (라즈베리파이)
    #     print(f"CCTV 스트림 연결: {cfg.CCTV_URL}")
    #     _run_stream(cfg.CCTV_URL)
    # else:
    #     # 기존 mp4 파일 루프 모드
    #     video_list = get_all_videos(cfg.DATASET_DIR)
    #     print(f"\n발견된 영상 수 = {len(video_list)}\n")
    #     for video_path in video_list:
    #         _run_cap(video_path)

    if cfg.CCTV_URL:
        # 저장된 동영상 먼저 재생 후 → 실시간 CCTV 스트림 전환
        video_list = get_all_videos(cfg.DATASET_DIR)
        
        # # # 1. 현재 프로그램이 실행되는 위치(Current Working Directory)를 가져옵니다.
        # current_dir = os.getcwd()
        # # # 2. 현재 위치 뒤에 'data\abnormal\방화' 경로를 붙여줍니다.
        # target_dir = os.path.join(current_dir, "data", "abnormal", "폭행")
        # video_list = get_videos(target_dir)

        if video_list:
            print(f"\n저장 영상 재생 시작: {len(video_list)}개\n")
            for video_path in video_list:
                if not ai_running:
                    break
                reset_detection_state()   # ★ 영상 전환 시 이전 영상의 화재/연기/폭행 상태 초기화
                print(f"재생 중: {video_path}")
                _run_cap(video_path)
            print("\n저장 영상 재생 완료 → 실시간 CCTV 스트림 전환\n")

        print(f"CCTV 스트림 연결: {cfg.CCTV_URL}")
        _run_stream(cfg.CCTV_URL)
    else:
        # CCTV URL 없으면 저장 영상만 루프
        video_list = get_all_videos(cfg.DATASET_DIR)
        print(f"\n발견된 영상 수 = {len(video_list)}\n")
        for video_path in video_list:
            reset_detection_state()   # ★ 영상 전환 시 이전 영상의 화재/연기/폭행 상태 초기화
            _run_cap(video_path)
        
    cv2.destroyAllWindows()
 
    
def _run_cap(source):
    """VideoCapture 소스를 열어 프레임 처리 루프 실행"""
    global latest_frame
    cap = cv2.VideoCapture(source)
    if not cap.isOpened():
        print(f"열기 실패: {source}")
        return

    frame_idx = 0
    while ai_running:          # ← ai_running 플래그로 중지 가능
        ret, frame = cap.read()
        if not ret:
            break
        frame_idx += 1
        
        # tracker 초기화 완료 전까지 대기
        if tracker is None:
            time.sleep(0.1)
            continue
        
        result = process_frame(frame, frame_idx, pose_model, seg_model,
                               tracker, cfg)
        latest_frame = result.copy()

        # ── prob 실시간 로그 (확인 후 제거) ──
        # if frame_idx % 30 == 0:   # 30프레임마다 출력
        #     from ai_detect import detection_status
        #     for pid, r in tracker.pred_hist.items():
        #         avg = float(np.mean(r)) if r else 0.0
        #         print(f"  PID={pid} avg_prob={avg:.4f} "
        #               f"is_alert={tracker.alert_state.get(pid, False)}")
        #     print(f"  detection_status={detection_status}")
            
    cap.release()


def _run_stream(url):
    """스트림 URL 전용 ? 연결 끊기면 재시도"""
    global ai_running
    
    # tracker, pose_model 초기화 완료까지 대기 (최대 30초)
    waited = 0
    while ai_running and (tracker is None or pose_model is None):
        print(f"모델 초기화 대기 중... ({waited}s)")
        time.sleep(1)
        waited += 1
        if waited > 30:
            print("[오류] 모델 초기화 타임아웃")
            return
        
    while ai_running:
        _run_cap(url)
        if ai_running:
            print("스트림 재연결 시도 중...")
            time.sleep(3)
            
                
def start_ai():

    global ai_running

    if ai_running:
        print("AI already running")
        return

    ai_running = True
 
    threading.Thread(
        target=run_ai_detection,
        daemon=True
    ).start()
    
        
def stop_ai():

    global ai_running

    ai_running = False

    print("AI STOP")