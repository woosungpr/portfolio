""""
============================================================
Step 3. 실시간 감지 - YOLO Pose + 학습된 분류기
============================================================
"""

import os
import cv2
import math
import time
import joblib
import collections
import numpy as np
import torch
from ultralytics import YOLO

from PIL import Image
from PIL import ImageDraw
from PIL import ImageFont

from fastapi import FastAPI
from fastapi.responses import StreamingResponse

app = FastAPI()

try:
    from sam2.build_sam import build_sam2
    from sam2.sam2_image_predictor import SAM2ImagePredictor
    SAM2_AVAILABLE = True
except ImportError:
    SAM2_AVAILABLE = False

# ============================================================
# 설정
# ============================================================
class Config:

    DATASET_DIR = r"data\abnormal"

    YOLO_POSE_MODEL = "ml/model/yolov8m-pose.pt"
    YOLO_SEG_MODEL  = "ml/model/yolov8n-seg.pt"
    YOLO_FIRE_MODEL = "ml/model/fire_best.pt"
    
    SAM2_CHECKPOINT = "checkpoints/sam2_hiera_small.pt"
    SAM2_CONFIG     = "sam2_hiera_s.yaml"
    SAM2_MODE       = "bbox"

    MODEL_DIR  = "ml/model"
    CLASSIFIER = "xgboost"

    CONF_PERSON    = 0.50      # 추가
    CONF_THRESHOLD = 0.15 #0.10
    ALERT_DURATION = 3.0
    HISTORY_LEN    = 10

    SAVE_EVENTS = True
    SAVE_DIR    = "output/realtime_events"
    
# ============================================================
# 특징 추출 (step1과 동일 로직)
# ============================================================

KP = {
    "nose":0,
    "l_shoulder":5, "r_shoulder":6,
    "l_elbow":7,    "r_elbow":8,
    "l_wrist":9,    "r_wrist":10,
    "l_hip":11,     "r_hip":12,
    "l_knee":13,    "r_knee":14,
    "l_ankle":15,   "r_ankle":16,
}


def safe_angle(a, b, c) -> float:
    ax, ay = a[0]-b[0], a[1]-b[1]
    cx, cy = c[0]-b[0], c[1]-b[1]
    dot = ax*cx + ay*cy
    mag = math.hypot(ax,ay) * math.hypot(cx,cy)
    if mag < 1e-3: return 0.0
    return math.degrees(math.acos(max(-1.0, min(1.0, dot/mag))))


def extract_features(kps: np.ndarray, prev_kps=None) -> dict:
    valid = [(kps[i][0]>0 or kps[i][1]>0) for i in range(17)]
    all_x = [kps[i][0] for i in range(17) if valid[i]]
    all_y = [kps[i][1] for i in range(17) if valid[i]]

    x_min = min(all_x) if all_x else 0
    x_max = max(all_x) if all_x else 1
    y_min = min(all_y) if all_y else 0
    y_max = max(all_y) if all_y else 1
    x_range = (x_max-x_min) or 1
    y_range = (y_max-y_min) or 1

    feat = {}
    kp_names = ["nose","l_eye","r_eye","l_ear","r_ear",
                "l_shoulder","r_shoulder","l_elbow","r_elbow",
                "l_wrist","r_wrist","l_hip","r_hip",
                "l_knee","r_knee","l_ankle","r_ankle"]

    for i, name in enumerate(kp_names):
        if valid[i]:
            feat[f"{name}_x"] = (kps[i][0]-x_min)/x_range
            feat[f"{name}_y"] = (kps[i][1]-y_min)/y_range
        else:
            feat[f"{name}_x"] = -1.0
            feat[f"{name}_y"] = -1.0

    ls=kps[5]; rs=kps[6]; lh=kps[11]; rh=kps[12]
    if all(valid[i] for i in [5,6,11,12]):
        s_mid=((ls[0]+rs[0])/2,(ls[1]+rs[1])/2)
        h_mid=((lh[0]+rh[0])/2,(lh[1]+rh[1])/2)
        dx=h_mid[0]-s_mid[0]; dy=h_mid[1]-s_mid[1]
        feat["body_angle"] = abs(math.degrees(math.atan2(abs(dx),abs(dy)+1e-3)))
    else:
        feat["body_angle"] = -1.0

    w=x_max-x_min; h=y_max-y_min
    feat["body_aspect"]   = w/(h+1e-3)
    feat["body_height"]   = y_range/(x_range+1e-3)
    feat["shoulder_width"]= math.hypot(rs[0]-ls[0],rs[1]-ls[1])/(x_range+1e-3) if valid[5] and valid[6] else -1.0
    feat["center_y"]      = (sum(all_y)/len(all_y)-y_min)/(y_range+1e-3) if all_y else -1.0

    feat["head_shoulder_diff"] = (ls[1]-kps[0][1])/(y_range+1e-3) if valid[0] and valid[5] else -1.0

    feat["l_elbow_angle"] = safe_angle(kps[5],kps[7],kps[9])  if all(valid[i] for i in [5,7,9])  else -1.0
    feat["r_elbow_angle"] = safe_angle(kps[6],kps[8],kps[10]) if all(valid[i] for i in [6,8,10]) else -1.0
    feat["l_knee_angle"]  = safe_angle(kps[11],kps[13],kps[15]) if all(valid[i] for i in [11,13,15]) else -1.0
    feat["r_knee_angle"]  = safe_angle(kps[12],kps[14],kps[16]) if all(valid[i] for i in [12,14,16]) else -1.0

    if prev_kps is not None:
        lw=math.hypot(kps[9][0]-prev_kps[9][0], kps[9][1]-prev_kps[9][1])
        rw=math.hypot(kps[10][0]-prev_kps[10][0],kps[10][1]-prev_kps[10][1])
        feat["l_wrist_speed"]  = lw/(x_range+1e-3)
        feat["r_wrist_speed"]  = rw/(x_range+1e-3)
        feat["max_wrist_speed"]= max(lw,rw)/(x_range+1e-3)
    else:
        feat["l_wrist_speed"] = feat["r_wrist_speed"] = feat["max_wrist_speed"] = -1.0

    feat["ankle_y_diff"] = abs(kps[15][1]-kps[16][1])/(y_range+1e-3) if valid[15] and valid[16] else -1.0
    feat["bbox_aspect"]  = -1.0

    return feat


# ============================================================
# 슬라이딩 윈도우 예측 (연속 N프레임 이상 이상이면 경보)
# ============================================================

class PersonTracker:
    def __init__(self, cfg: Config, feat_cols, classifier):
        self.cfg        = cfg
        self.feat_cols  = feat_cols
        self.classifier = classifier
        self.prev_kps   = {}          # pid → kps
        self.pred_hist  = {}          # pid → deque of proba
        self.last_alert = {}          # pid → time
        self.alert_state= {}          # pid → bool

    def predict(self, pid: int, kps: np.ndarray, box) -> dict:
        prev = self.prev_kps.get(pid)
        feat = extract_features(kps, prev)
        self.prev_kps[pid] = kps.copy()

        # bbox aspect 추가
        bw = float(box[2]-box[0]); bh = float(box[3]-box[1])
        feat["bbox_aspect"] = bw/(bh+1e-3)

        # 특징 벡터 정렬
        x = np.array([feat.get(c,-1.0) for c in self.feat_cols], dtype=np.float32)
        x = np.where(x < 0, 0.0, x).reshape(1,-1)

        # 확률 예측
        try:
            proba = self.classifier.predict_proba(x)[0]
            # print("proba =", proba)
            prob_abnormal = proba[1] if len(proba) > 1 else proba[0]
        except:
            prob_abnormal = 0.0

        # 슬라이딩 윈도우
        if pid not in self.pred_hist:
            self.pred_hist[pid] = collections.deque(maxlen=self.cfg.HISTORY_LEN)
        self.pred_hist[pid].append(prob_abnormal)

        avg_prob = float(np.mean(self.pred_hist[pid]))
        is_alert = avg_prob >= self.cfg.CONF_THRESHOLD

        # print(
        #     f"PID={pid} "
        #     f"현재={prob_abnormal:.3f} "
        #     f"평균={avg_prob:.3f}"
        # )

        now = time.time()
        if is_alert:
            self.last_alert[pid]  = now
            self.alert_state[pid] = True
        elif pid in self.last_alert:
            if now - self.last_alert[pid] > self.cfg.ALERT_DURATION:
                self.alert_state[pid] = False

        # if avg_prob > 0.05:
            # print(
            #     f"[ALERT 후보] "
            #     f"PID={pid} "
            #     f"prob={avg_prob:.3f}"
            # )
    
        return {
            "pid":        pid,
            "prob":       avg_prob,
            "is_alert":   self.alert_state.get(pid, False),
            "feat":       feat,
        }


# ============================================================
# SAM2
# ============================================================

def init_sam2(cfg: Config, device: str):
    if not SAM2_AVAILABLE or not os.path.exists(cfg.SAM2_CHECKPOINT):
        return None
    try:
        m = build_sam2(cfg.SAM2_CONFIG, cfg.SAM2_CHECKPOINT, device=device)
        return SAM2ImagePredictor(m)
    except:
        return None


def sam2_segment(predictor, frame_rgb, boxes):
    if not predictor or not boxes: return []
    predictor.set_image(frame_rgb)
    out = []
    for box in boxes:
        try:
            masks, scores, _ = predictor.predict(
                point_coords=None, point_labels=None,
                box=np.array(box)[None,:], multimask_output=False)
            out.append(masks[np.argmax(scores)])
        except:
            out.append(None)
    return out


def overlay_mask(img, mask, color, alpha=0.40):
    # out = img.copy()
    # m   = mask.astype(bool)
    # out[m] = (out[m]*(1-alpha)+np.array(color)*alpha).astype(np.uint8)
    # cnts,_ = cv2.findContours(mask.astype(np.uint8),cv2.RETR_EXTERNAL,cv2.CHAIN_APPROX_SIMPLE)
    # cv2.drawContours(out,cnts,-1,color,2)
    # return out
    return img


# ============================================================
# 프레임 처리
# ============================================================

ALERT_COLOR  = (0, 0, 255)
NORMAL_COLOR = (80, 200, 80)
MID_COLOR    = (0, 165, 255)


def process_frame(frame, frame_idx, pose_model, seg_model,
                  sam2_predictor, tracker: PersonTracker, cfg: Config):

    annotated = frame.copy()
    frame_rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)

    # YOLO Pose + ByteTrack
    results = pose_model.track(frame, persist=True,
                               tracker="bytetrack.yaml", verbose=False)

    person_boxes  = {}
    person_alerts = {}   # pid → result dict

    for r in results:
        if r.boxes is None or r.boxes.id is None: continue
        if r.keypoints is None: continue

        boxes_xyxy    = r.boxes.xyxy.cpu().numpy()
        confs         = r.boxes.conf.cpu().numpy()    # 추가
        track_ids     = r.boxes.id.cpu().numpy().astype(int)
        keypoints_all = r.keypoints.xy.cpu().numpy()

        for idx in range(len(track_ids)):
            conf = float(confs[idx])
            if conf < cfg.CONF_PERSON:
                continue
    
            pid = int(track_ids[idx])
            kps = keypoints_all[idx]
            box = boxes_xyxy[idx]
            
            # 관절 개수 필터
            valid_kps = np.sum(
                np.any(kps > 0, axis=1)
            )

            if valid_kps < 8:
                continue

            # print(
            #     f"PID={pid}, "
            #     f"CONF={conf:.3f}, "
            #     f"KP={valid_kps}"
            # )
            
            person_boxes[pid] = list(map(int, box[:4]))

            result = tracker.predict(pid, kps, box)
            person_alerts[pid] = result

    # SAM2 / YOLO Seg
    masks   = []
    box_list = list(person_boxes.values())

    if sam2_predictor and cfg.SAM2_MODE == "bbox" and box_list:
        masks = sam2_segment(sam2_predictor, frame_rgb, box_list)
    else:
        seg_res = seg_model(frame, classes=[0], verbose=False)
        for r in seg_res:
            if r.masks is not None:
                for m in r.masks.data.cpu().numpy():
                    rm = cv2.resize(m,(frame.shape[1],frame.shape[0]))
                    masks.append(rm > 0.5)

    # 마스크 오버레이
    pid_list = list(person_boxes.keys())
    for i, mask in enumerate(masks):
        if mask is None: continue
        pid = pid_list[i] if i < len(pid_list) else -1
        res = person_alerts.get(pid)
        if res and res["is_alert"]:
            color = ALERT_COLOR
        elif res and res["prob"] > 0.35:
            color = MID_COLOR
        else:
            color = NORMAL_COLOR
        annotated = overlay_mask(annotated, mask.astype(bool), color)

    # Pose 스켈레톤
    # for r in results:
    #     annotated = r.plot(img=annotated)

    # 사람별 확률 + 경보 표시
    saved = False
    for pid, res in person_alerts.items():
        box = person_boxes.get(pid)
        if not box: continue
        x1,y1,x2,y2 = box
        prob = res["prob"]

        if res["is_alert"]:
            color = ALERT_COLOR
            cv2.rectangle(annotated,(x1,y1),(x2,y2),color,3)

            # 경보 배경
            text  = f"[ALERT] ID:{pid} 이상행동 {prob:.0%}"
            tw,th = cv2.getTextSize(text,cv2.FONT_HERSHEY_SIMPLEX,0.65,2)[0]
            ly    = max(y1-8, 30)
            cv2.rectangle(annotated,(x1,ly-th-6),(x1+tw+8,ly+4),(0,0,180),-1)
            # cv2.putText(annotated,text,(x1+4,ly),
            #             cv2.FONT_HERSHEY_SIMPLEX,0.65,(255,255,255),2)
            annotated = draw_korean(annotated, text, x1 + 4, ly - 25, (255,255,255) )

            # 이벤트 프레임 저장
            if cfg.SAVE_EVENTS and not saved:
                os.makedirs(cfg.SAVE_DIR,exist_ok=True)
                sname = f"f{frame_idx:06d}_pid{pid}_{prob:.2f}.jpg"
                cv2.imwrite(os.path.join(cfg.SAVE_DIR,sname),annotated)
                saved = True

        else:
            color = MID_COLOR if prob>0.35 else NORMAL_COLOR
            cv2.rectangle(annotated,(x1,y1),(x2,y2),color,1)
            cv2.putText(annotated,f"ID:{pid} {prob:.2f}",
                        (x1,y1-5),cv2.FONT_HERSHEY_SIMPLEX,0.5,color,1)

    # 화재검사
    fire_results = fire_model(
        frame,
        verbose=False
    )
    for r in fire_results:

        if r.boxes is None:
            continue

        for box in r.boxes:

            cls = int(box.cls[0])

            x1,y1,x2,y2 = map(int, box.xyxy[0])

            if cls == 0:   # fire
                color = (0,0,255)
                label = "FIRE"

            elif cls == 1:
                color = (128,128,128)
                label = "SMOKE"

            else:
                continue
    
            cv2.rectangle(
                annotated,
                (x1,y1),
                (x2,y2),
                color,
                3
            )

            cv2.putText(
                annotated,
                label,
                (x1,y1-10),
                cv2.FONT_HERSHEY_SIMPLEX,
                1,
                color,
                2
            )
            
    # HUD
    h,w = annotated.shape[:2]
    ov  = annotated.copy()
    cv2.rectangle(ov,(0,0),(w,45),(15,15,15),-1)
    annotated = cv2.addWeighted(ov,0.65,annotated,0.35,0)

    alert_count = sum(1 for r in person_alerts.values() if r["is_alert"])
    hud_color   = ALERT_COLOR if alert_count > 0 else (200,200,200)
    status      = f"[ALERT] {alert_count}명" if alert_count>0 else "정상"

    cv2.putText(annotated,f"F:{frame_idx}",(10,30),
                cv2.FONT_HERSHEY_SIMPLEX,0.75,(200,200,200),2)
    # cv2.putText(annotated,status,(200,30),
    #             cv2.FONT_HERSHEY_SIMPLEX,0.85,hud_color,2)
    # 한글은 PIL 사용
    annotated = draw_korean(annotated, status, 200, 5, hud_color)
    
    mode = "SAM2" if sam2_predictor else "YOLO-Seg"
    cv2.putText(annotated,mode,(w-150,30),
                cv2.FONT_HERSHEY_SIMPLEX,0.65,(180,180,255),2)

    return annotated


def get_all_videos(root_dir):

    videos = []

    for root, dirs, files in os.walk(root_dir):

        for f in files:

            if f.lower().endswith(".mp4"):

                videos.append(
                    os.path.join(root, f)
                )

    return sorted(videos)

def draw_korean(img, text, x, y, color):
    img_pil = Image.fromarray(img)

    draw = ImageDraw.Draw(img_pil)

    draw.text(
        (x, y),
        text,
        font=FONT,
        fill=(color[2], color[1], color[0])
    )

    return np.array(img_pil)

def generate_frames():

    global latest_frame

    while True:

        if latest_frame is None:
            continue

        _, buffer = cv2.imencode(
            '.jpg',
            latest_frame
        )

        frame = buffer.tobytes()

        yield (
            b'--frame\r\n'
            b'Content-Type: image/jpeg\r\n\r\n'
            + frame +
            b'\r\n'
        )

@app.get("/ai-video")
def ai_video():

    return StreamingResponse(
        generate_frames(),
        media_type=
        'multipart/x-mixed-replace; boundary=frame'
    )
            
# ============================================================
# 메인
# ============================================================
if __name__ == "__main__":
    cfg    = Config()
    device = "cuda" if torch.cuda.is_available() else "cpu"
    print(f"디바이스: {device}")

    # 분류기 로드
    clf_path   = os.path.join(cfg.MODEL_DIR, f"{cfg.CLASSIFIER}.pkl")
    feat_path  = os.path.join(cfg.MODEL_DIR, "feat_cols.pkl")

    if not os.path.exists(clf_path):
        print(f"[오류] 분류기 없음: {clf_path}")
        print("       먼저 step1 → step2 실행 필요")
        exit(1)

    print(f"분류기 로드: {clf_path}")
    classifier = joblib.load(clf_path)
    feat_cols  = joblib.load(feat_path)
    print(f"  특징 수: {len(feat_cols)}")

    # 모델 로드
    pose_model = YOLO(cfg.YOLO_POSE_MODEL)
    seg_model  = YOLO(cfg.YOLO_SEG_MODEL)
    sam2       = init_sam2(cfg, device)
   
    fire_model = YOLO(cfg.YOLO_FIRE_MODEL)

    print(fire_model.names)
    
    print("화재 모델 로드 완료")
    
    BASE_DIR = os.path.dirname(
        os.path.abspath(__file__)
    )

    FONT_PATH = os.path.join(
        BASE_DIR,
        "..",
        "frontend",
        "fonts",
        "malgun.ttf"
    )

    FONT = ImageFont.truetype(
        FONT_PATH,
        24
    )

    # print("LAST")
    # model = YOLO(r"models\fire_last.pt")
    # print(model.names)

    tracker = PersonTracker(cfg, feat_cols, classifier)
    
    video_list = get_all_videos(cfg.DATASET_DIR)

    print()
    print("발견된 영상 수 =", len(video_list))
    print()

    for video_path in video_list:

        print("=" * 60)
        print("처리중 :", video_path)
        print("=" * 60)

        cap = cv2.VideoCapture(video_path)

        if not cap.isOpened():
            print("열기 실패")
            continue

        frame_idx = 0

        while True:

            ret, frame = cap.read()

            if not ret:
                break

            frame_idx += 1

            result = process_frame(
                frame,
                frame_idx,
                pose_model,
                seg_model,
                sam2,
                tracker,
                cfg
            )

            cv2.imshow("AI Hub Abnormal behavior 감지", result)

            key = cv2.waitKey(1) & 0xFF

            if key == ord("q"):
                cap.release()
                cv2.destroyAllWindows()
                exit()

        cap.release()

    # cap = cv2.VideoCapture(
    #     "https://river-fruit-pages-morrison.trycloudflare.com/video"
    # )

    cv2.destroyAllWindows()