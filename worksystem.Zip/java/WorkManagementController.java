package com.gn.work.controller;

import java.io.ByteArrayOutputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.ContentDisposition;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.gn.work.service.WorkManagementService;
import com.gn.work.vo.JoinMemberVO;
import com.gn.work.vo.WorkFileVO;
import com.gn.work.vo.WorkManagementVO;

@Controller
public class WorkManagementController {
	
	private final WorkManagementService workManagementService;

	private static final Logger logger = LoggerFactory.getLogger(WorkManagementController.class);
	
    // 생성자를 통한 의존성 주입
    public WorkManagementController(WorkManagementService workManagementService) {
        this.workManagementService = workManagementService;
    }
	
    /**
     * 업무관리 월별
     */	
	@RequestMapping("createWorkMonthList")
	public String createWorkMonthList(HttpServletRequest request) {	
		
		HttpSession session = request.getSession();
		JoinMemberVO loginUser = (JoinMemberVO) session.getAttribute("loginUser");

		if (loginUser != null) {
		    String id = loginUser.getId(); // Assuming 'getId()' returns the 'id' field
		    request.setAttribute("empId", id); // Set 'id' as 'empId' in request
		    request.setAttribute("empName", loginUser.getName()); 
		}

		return "workManagement/createWorkMonthList";			
	}
	
    /**
     * 업무관리 일별
     */	
	@RequestMapping("createWorkDayList")
	public String createWorkDayList(HttpServletRequest request) {	
		System.out.println("################## workManagement/createWorkDayList");

	    // Retrieve query parameters using request.getParameter()
	    String empId = request.getParameter("empId");
	    String workDate = request.getParameter("workDate");
	    System.out.println("################## empId :" + empId + " workDate :" + workDate);

	    HttpSession session = request.getSession();
	    JoinMemberVO loginUser = (JoinMemberVO) session.getAttribute("loginUser");

	    if (loginUser != null) {
	        String id = loginUser.getId(); // Assuming 'getId()' returns the 'id' field
	        //request.setAttribute("empId", id); // Set 'id' as 'empId' in request
	        request.setAttribute("empName", loginUser.getName()); 
	        request.setAttribute("empId", empId); // Set the empId from query parameter
	        request.setAttribute("workDate", workDate); // Set the workDate from query parameter
	    }
	    
		return "workManagement/createWorkDayList";			
	}

    /**
     * 업무관리 일별 - 관리자
     */	
	@RequestMapping("createWorkDayListOfManage")
	public String createWorkMonthDetList(HttpServletRequest request) {	
		System.out.println("################## workManagement/createWorkDayListOfManage");

	    // Retrieve query parameters using request.getParameter()
	    String empId = request.getParameter("empId");
	    String empName = request.getParameter("empName");
	    String workDate = request.getParameter("workDate");
	    System.out.println("################## empId :" + empId + " empName :" + empName + " workDate :" + workDate);

	    //HttpSession session = request.getSession();
	    //JoinMemberVO loginUser = (JoinMemberVO) session.getAttribute("loginUser");

	    //if (loginUser != null) {
	        //String id = loginUser.getId(); // Assuming 'getId()' returns the 'id' field
	        //request.setAttribute("empId", id); // Set 'id' as 'empId' in request
	        request.setAttribute("empName", empName); 
	        request.setAttribute("empId", empId); // Set the empId from query parameter
	        request.setAttribute("workDate", workDate); // Set the workDate from query parameter
	    //}
	    
		return "workManagement/createWorkDayListOfManage";			
	}
	
    /**
     * 업무관리 월별
     */	
	@RequestMapping("createWorkList")
	public String createWorkList(HttpServletRequest request) {	
		
		HttpSession session = request.getSession();
		JoinMemberVO loginUser = (JoinMemberVO) session.getAttribute("loginUser");

		if (loginUser != null) {
		    String id = loginUser.getId(); // Assuming 'getId()' returns the 'id' field
		    request.setAttribute("empId", id); // Set 'id' as 'empId' in request
		    request.setAttribute("empName", loginUser.getName());
		    request.setAttribute("empIndex", loginUser.getEmp_index());
		}

		return "workManagement/createWorkList";			
	}
	
	 /**
     * 일일업무등록
     */	
	@RequestMapping("createWorkDaySav")
	public String createWorkDaySav(HttpServletRequest request) {	
		
	    // Retrieve query parameters using request.getParameter()
	    String empId = request.getParameter("empId");
	    String workDate = request.getParameter("workDate");
	    System.out.println("################## createWorkDaySav empId :" + empId + " workDate :" + workDate);

		HttpSession session = request.getSession();
		JoinMemberVO loginUser = (JoinMemberVO) session.getAttribute("loginUser");

		if (loginUser != null) {
		    String id = loginUser.getId(); // Assuming 'getId()' returns the 'id' field
		    request.setAttribute("empId", id); // Set 'id' as 'empId' in request
		    request.setAttribute("empName", loginUser.getName());
	        if(empId != null) { request.setAttribute("empId", empId);} // Set the empId from query parameter
	        if(workDate != null) { request.setAttribute("workDate", workDate);} // Set the workDate from query parameter		    
		}

		return "workManagement/createWorkDaySav";			
	}
	
	@PostMapping("workManagement/save")  // "/workManagement/save"로 매핑
	public ResponseEntity<Map<String, Object>> mergeWorkData(@RequestBody List<WorkManagementVO> workData) {		
        System.out.println("Received data: " + workData);
        if (workData == null || workData.isEmpty()) {
            // Change responseMap to Map<String, Object> to match the return type
            Map<String, Object> responseMap = new HashMap<>();
            responseMap.put("message", "No data received");
            responseMap.put("timestamp", LocalDateTime.now().toString()); // Include timestamp as Object

            return ResponseEntity.badRequest().body(responseMap);
        }        
        try {
            List<Integer> newIdxList = new ArrayList<>(); // Store generated IDX values

            for (WorkManagementVO work : workData) {
                System.out.println("Saving: " + work); // Debug each object
                // Add logic to save data to the database
                workManagementService.mergeWorkData(work);

                /*if (work.getGeneratedIdx() != -1) { // Retrieve the generated IDX
                    newIdxList.add(work.getGeneratedIdx());
                }*/
            }
            
            // Use HashMap for compatibility with Java 8
            Map<String, Object> responseMap = new HashMap<>();
            responseMap.put("message", "Data saved successfully");
            responseMap.put("newIdxList", newIdxList);
            
            return ResponseEntity.ok(responseMap);
        } catch (Exception e) {
            // Use HashMap for compatibility with Java 8
            Map<String, Object> responseMap = new HashMap<>();
            responseMap.put("message", "Failed to save data");
            
            e.printStackTrace(); // Log the exception for debugging
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(responseMap);
        }
    }
	
	@GetMapping("workManagement/getNextIdx")
    public ResponseEntity<Integer> getNextIdx() {
        try {
            int nextIdx = workManagementService.getNextIdx();
            return ResponseEntity.ok(nextIdx);
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }

	@GetMapping("workManagement/getNextPjtIdx")
    public ResponseEntity<Integer> getNextPjtIdx() {
        try {
            int nextIdx = workManagementService.getNextPjtIdx();
            return ResponseEntity.ok(nextIdx);
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }
	
	@PostMapping("workManagement/uploadFile")
	public ResponseEntity<String> uploadFile(@RequestParam(value= "file", required = false) MultipartFile file,
	                                        @RequestParam(value= "idx", required = false, defaultValue = "-1") Integer idx,
	                                        @RequestParam(value= "empId", required = false) String empId,
	                                        @RequestParam(value= "workDate", required = false) @DateTimeFormat(pattern = "yyyy-MM-dd")  Date workDate) {
	    try {
	    	if (file.isEmpty()) {
	            return ResponseEntity.badRequest().body("파일이 없습니다!");
	        }
	    	
	    	 String fileName = file.getOriginalFilename();
	         System.out.println("############## Uploaded File: " + fileName + " for idx: " + idx);
	         
	         System.out.println("업로드된 파일: " + file.getOriginalFilename());
	         System.out.println("idx: " + idx + ", empId: " + empId + ", workDate: " + workDate);
	        
	        // 각 파일을 개별적으로 저장
	        workManagementService.saveTaskFileForProject(file, idx, empId, workDate);
	        return ResponseEntity.ok("File uploaded successfully");
	    }catch (NumberFormatException e) {
	        return ResponseEntity.status(HttpStatus.BAD_REQUEST)
	                .body("Invalid idx parameter. Please provide a valid integer.");
	     } catch (Exception e) {
	         e.printStackTrace();
	         return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
	                .body("Failed to upload file: " + e.getMessage());
	     }

	}

	@PostMapping("workManagement/srchMonthWorkList")
    public ResponseEntity<List<WorkManagementVO>> srchMonthWorkList(@RequestBody Map<String, Object> params, HttpServletRequest request) {
        try {
            // 요청 파라미터에서 empId와 workDate 추출
        	String empIndex = (String) params.get("empIndex");
            String empId = (String) params.get("empId");
            String workDate = (String) params.get("workDate");

            String catSel   = (String) params.get("categorySelect");
            String kwd		= (String) params.get("keywordInput");
            String cplYn	= (String) params.get("cplYn");
            
            String resYn	= (String) params.get("resYn");//담당유무
            
            
            System.out.println("############## workManagement/srchMonthWorkList empIndex:"+empIndex+" empId:"+empId+" workDate:"+workDate+" catSel:"+catSel+" kwd:"+kwd+" cplYn:"+cplYn);
            
            Map<String, Object> map = new HashMap<>();
            map.put("empIndex",empIndex);
            map.put("empId",empId);
            map.put("workDate",workDate);
            map.put("categorySelect",catSel);
            map.put("keywordInput",kwd);
            map.put("cplYn",cplYn);
            
            // 서비스에서 데이터 조회
            List<WorkManagementVO> monthWorkList = workManagementService.srchMonthWorkList(map);

            HttpSession session = request.getSession();
    		JoinMemberVO loginUser = (JoinMemberVO) session.getAttribute("loginUser");

    		if (loginUser != null) {
    		    int emp_Index = loginUser.getEmp_index();
    		    System.out.println("############## workManagement/srchMonthWorkList emp_Index:"+emp_Index);
    		    request.setAttribute("empIndex", emp_Index); 
    		}
    		
            return ResponseEntity.ok(monthWorkList);
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }

	@PostMapping("workManagement/srchResWorkList")
    public ResponseEntity<List<WorkManagementVO>> srchResWorkList(@RequestBody Map<String, Object> params, HttpServletRequest request) {
        try {
            // 요청 파라미터에서 empId와 workDate 추출
        	String empIndex = (String) params.get("empIndex");
            String empId = (String) params.get("empId");
            String workDate = (String) params.get("workDate");

            String catSel   = (String) params.get("categorySelect");
            String kwd		= (String) params.get("keywordInput");
            String cplYn	= (String) params.get("cplYn");
            
            String resYn	= (String) params.get("resYn");//담당유무
            
            
            System.out.println("############## workManagement/srchResWorkList empIndex:"+empIndex+" empId:"+empId+" workDate:"+workDate+" catSel:"+catSel+" kwd:"+kwd+" cplYn:"+cplYn+" resYn:"+resYn);
            
            Map<String, Object> map = new HashMap<>();
            map.put("empIndex",empIndex);
            map.put("empId",empId);
            map.put("workDate",workDate);
            map.put("categorySelect",catSel);
            map.put("keywordInput",kwd);
            map.put("cplYn",cplYn);
            map.put("resYn",resYn);
            
            
            // 서비스에서 데이터 조회
            List<WorkManagementVO> monthWorkList = workManagementService.srchResWorkList(map);
            
            HttpSession session = request.getSession();
    		JoinMemberVO loginUser = (JoinMemberVO) session.getAttribute("loginUser");
    		if (loginUser != null) {
    		    int emp_Index = loginUser.getEmp_index();
    		    System.out.println("############## workManagement/srchResWorkList emp_Index:"+emp_Index);
    		    request.setAttribute("empIndex", emp_Index); 
    		}
    		
            return ResponseEntity.ok(monthWorkList);
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }
	
	@PostMapping("workManagement/srchDayWorkList")
    public ResponseEntity<List<WorkManagementVO>> srchDayWorkList(@RequestBody Map<String, Object> params) {
        try {
            // 요청 파라미터에서 empId와 workDate 추출
            String empId = (String) params.get("empId");
            String workDate = (String) params.get("workDate");

            Map<String, Object> map = new HashMap<>();
            map.put("empId",empId);
            map.put("workDate",workDate);
            
            // 서비스에서 데이터 조회
            List<WorkManagementVO> dayWorkList = workManagementService.srchDayWorkList(map);

            return ResponseEntity.ok(dayWorkList);
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }

	@PostMapping("workManagement/srchWorkList")
    public ResponseEntity<List<WorkManagementVO>> srchWorkList(@RequestBody Map<String, Object> params) {
        try {
            // 요청 파라미터에서 empId와 workDate 추출
            String empId = (String) params.get("empId");
            String workDate = (String) params.get("workDate");

            Map<String, Object> map = new HashMap<>();
            map.put("empId",empId);
            map.put("workDate",workDate);
            
            // 서비스에서 데이터 조회
            List<WorkManagementVO> workList = workManagementService.srchWorkList(map);

            return ResponseEntity.ok(workList);
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }

	@PostMapping("workManagement/deleteWork") // POST 요청 처리
    public ResponseEntity<String> deleteWorkData(@RequestBody Map<String, Object> requestBody) {
    	System.out.println("deleteWorkData Request Body: " + requestBody);

    	try {
            // Parse 'idx' from String to Integer
            int idx = Integer.parseInt((String) requestBody.get("idx")); // Convert String to Integer
            String delYn = (String) requestBody.get("delYn"); 
            
            // Perform your deletion logic
            System.out.println("Parsed idx: " + idx + " delYn=" + delYn);
            Map<String, Object> map = new HashMap();
            map.put("idx", idx);
            map.put("delYn", delYn);
            
            // 서비스 메서드 호출
            workManagementService.deleteWorkData(map);
            
            return ResponseEntity.ok("Row deleted successfully");
        } catch (NumberFormatException e) {
            // Handle case where the value cannot be parsed as an Integer
            e.printStackTrace();
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                                 .body("Invalid format for idx: " + e.getMessage());
        } catch (Exception e) {
            // Handle other errors
            e.printStackTrace();
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                                 .body("Error during deletion: " + e.getMessage());
        }
    }
	
	/*@PostMapping("workManagement/updateWorkOpinion")
	public ResponseEntity<Map<String, String>> updateWorkOpinion(@RequestBody Map<String, Object> requestBody) {
	    Map<String, String> response = new HashMap<>();
	    
	    try {
	        int idx = Integer.parseInt(requestBody.get("idx").toString());
	        String adminComment = requestBody.get("adminComment").toString();

	        // Debugging logs
	        System.out.println("Parsed idx: " + idx + ", adminComment: " + adminComment);

	        Map<String, Object> paramMap = new HashMap<>();
	        paramMap.put("idx", idx);
	        paramMap.put("adminComment", adminComment);

	        workManagementService.updateWorkOpinion(paramMap);

	        response.put("message", "Work Opinion updated successfully");
	        return ResponseEntity.ok(response);
	    } catch (Exception e) {
	    	e.printStackTrace();
	        response.put("error", "Error updating Work Opinion: " + e.getMessage());
	        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
	    }
	}*/


	@PostMapping("workManagement/updateWorkOpinion")
	public ResponseEntity<String> updateWorkOpinion(@RequestBody Map<String, Object> requestBody, HttpServletRequest request) {
	    System.out.println("updateWorkOpinion Request Body: " + requestBody);

	    try {
	        // Extract 'idx' safely from the map
	        int idx = Integer.parseInt(requestBody.get("idx").toString()); // Convert to Integer safely
	        String adminComment = requestBody.get("adminComment").toString(); // Ensure it's a String
	        int empIndex = Integer.parseInt(requestBody.get("commentWrtid").toString());
	        
	        // Debugging logs
	        System.out.println("Parsed idx: " + idx + ", adminComment: " + adminComment + ", empIndex:" + empIndex);

	        // Create map for service method
	        Map<String, Object> paramMap = new HashMap<>();
	        paramMap.put("idx", idx);
	        paramMap.put("adminComment", adminComment);
	        paramMap.put("commentWrtid", empIndex);	        
	        
	        /*
			HttpSession session = request.getSession();
			JoinMemberVO loginUser = (JoinMemberVO) session.getAttribute("loginUser");
			if (loginUser != null) {
				paramMap.put("commentWrtid", loginUser.getEmp_index()); 
			}
	        */
	        
	        // Call service method with map
	        workManagementService.updateWorkOpinion(paramMap);

	        return ResponseEntity.ok("Work Opinion updated successfully");

	    } catch (NumberFormatException e) {
	        // Handle invalid integer conversion
	        e.printStackTrace();
	        return ResponseEntity.status(HttpStatus.BAD_REQUEST)
	                             .body("Invalid format for idx: " + e.getMessage());
	    } catch (Exception e) {
	        // Handle other errors
	        e.printStackTrace();
	        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
	                             .body("Error during update Work Opinion: " + e.getMessage());
	    }
	}
	
	

    
	@PostMapping("workManagement/srchStage1List")
    public ResponseEntity<List<WorkManagementVO>> srchStage1List(@RequestBody Map<String, Object> params) {
        try {
            // 요청 파라미터에서 empId와 workDate 추출
            String stageCode = (String) params.get("stageCode");

            Map<String, Object> map = new HashMap<>();
            map.put("stageCode",stageCode);
            
            // 서비스에서 데이터 조회
            List<WorkManagementVO> stageList = workManagementService.srchStage1List(map);

            return ResponseEntity.ok(stageList);
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }
    
	@PostMapping("workManagement/srchStage2List")
    public ResponseEntity<List<WorkManagementVO>> srchStage2List(@RequestBody Map<String, Object> params) {
        try {
            // 요청 파라미터에서 empId와 workDate 추출
            String stageCode = (String) params.get("stageCode");

            Map<String, Object> map = new HashMap<>();
            map.put("stageCode",stageCode);
            
            // 서비스에서 데이터 조회
            List<WorkManagementVO> stageList = workManagementService.srchStage2List(map);

            return ResponseEntity.ok(stageList);
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }
	 
	@PostMapping("workManagement/updateWorkState")  
    public ResponseEntity<String> updateWorkState(@RequestBody List<WorkManagementVO> workData) {
        System.out.println("updateWorkState Received data: " + workData);
        if (workData == null || workData.isEmpty()) {
            return ResponseEntity.badRequest().body("No data received");
        }        
        try {
            
            for (WorkManagementVO work : workData) {
                System.out.println("Saving: " + work); // Debug each object
                // Add logic to save data to the database
                workManagementService.updateWorkState(work);
            }            
            return ResponseEntity.ok("Data saved successfully");
        } catch (Exception e) {
        	e.printStackTrace(); // Log the exception for debugging
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Failed to save data");
        }
    }

	@PostMapping("workManagement/deleteWorkFile")  
    public ResponseEntity<String> deleteWorkFile(@RequestBody List<WorkManagementVO> workData) {
        System.out.println("deleteWorkFile Received data: " + workData);
        if (workData == null || workData.isEmpty()) {
            return ResponseEntity.badRequest().body("No data received");
        }        
        try {
            
            for (WorkManagementVO work : workData) {
                System.out.println("Saving: " + work); // Debug each object
                // Add logic to save data to the database
                workManagementService.deleteWorkFile(work);
            }            
            return ResponseEntity.ok("file delete successfully");
        } catch (Exception e) {
        	e.printStackTrace(); // Log the exception for debugging
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Failed to file delete");
        }
    }
	
	@PostMapping("workManagement/srchPjtList")
    public ResponseEntity<List<WorkManagementVO>> srchPjtList(@RequestBody Map<String, Object> params) {
        try {
            // 요청 파라미터에서 empId와 workDate 추출
            //String stageCode = (String) params.get("stageCode");

            Map<String, Object> map = new HashMap<>();
            //map.put("stageCode",stageCode);
            
            // 서비스에서 데이터 조회
            List<WorkManagementVO> pjtList = workManagementService.srchPjtList(map);

            return ResponseEntity.ok(pjtList);
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }

	@PostMapping("workManagement/srchPmList")
    public ResponseEntity<List<WorkManagementVO>> srchPmList(@RequestBody Map<String, Object> params) {
        try {
            // 요청 파라미터에서 empId와 workDate 추출
            //String stageCode = (String) params.get("stageCode");

            Map<String, Object> map = new HashMap<>();
            //map.put("stageCode",stageCode);
            
            // 서비스에서 데이터 조회
            List<WorkManagementVO> pmList = workManagementService.srchPmList(map);

            return ResponseEntity.ok(pmList);
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }

	@PostMapping("workManagement/srchEmpList")
    public ResponseEntity<List<WorkManagementVO>> srchEmpList(@RequestBody Map<String, Object> params) {
        try {
            // 요청 파라미터에서 empId와 workDate 추출
            //String stageCode = (String) params.get("stageCode");

            Map<String, Object> map = new HashMap<>();
            //map.put("stageCode",stageCode);
            
            // 서비스에서 데이터 조회
            List<WorkManagementVO> empList = workManagementService.srchEmpList(map);

            return ResponseEntity.ok(empList);
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }

	/*
	 * 프로젝트관리
	*/
	@RequestMapping(value = "projectManagement", method = RequestMethod.GET)
	public String projectManagementMod(Locale locale) {
		logger.info("The client locale is {}.", locale);
		
		return "workManagement/projectManagement";			
	}

	/*
	 * 프로젝트관리
	*/
	@RequestMapping(value = "projectManagementList", method = RequestMethod.GET)
	public String projectManagementList(Locale locale) {
		logger.info("The client locale is {}.", locale);
		
		return "workManagement/projectManagementList";			
	}

	@PostMapping("workManagement/srchPjtManageList")
    public ResponseEntity<List<WorkManagementVO>> srchPjtManageList(@RequestBody Map<String, Object> params) {
        try {
            // 요청 파라미터에서 empId와 workDate 추출
            String category = (String) params.get("category");

            Map<String, Object> map = new HashMap<>();
            map.put("category",category);
            
            // 서비스에서 데이터 조회
            List<WorkManagementVO> pjtList = workManagementService.srchPjtManageList(map);

            return ResponseEntity.ok(pjtList);
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }
	
	
	@PostMapping("projectManagement/save")  // "/workManagement/save"로 매핑
	public ResponseEntity<Map<String, Object>> mergeProjectInfo(@RequestBody List<WorkManagementVO> pjtData) {		
        System.out.println("mergeProjectInfo Received data: " + pjtData);
        if (pjtData == null || pjtData.isEmpty()) {
            Map<String, Object> responseMap = new HashMap<>();
            responseMap.put("message", "No data received");
            
            return ResponseEntity.badRequest().body(responseMap);
        }        
        try {
            List<Integer> newIdxList = new ArrayList<>(); // Store generated IDX values

            for (WorkManagementVO work : pjtData) {
                System.out.println("Saving: " + work); // Debug each object
                // Add logic to save data to the database
                workManagementService.mergeProjectInfo(work);

                /*if (work.getGeneratedIdx() != -1) { // Retrieve the generated IDX
                    newIdxList.add(work.getGeneratedIdx());
                }*/
            }
            
            Map<String, Object> responseMap = new HashMap<>();
            responseMap.put("message", "Data saved successfully");
            responseMap.put("newIdxList", newIdxList);
            
            return ResponseEntity.ok(responseMap);
        } catch (Exception e) {
            Map<String, Object> responseMap = new HashMap<>();
            responseMap.put("message", "Failed to save data");
        	
            e.printStackTrace(); // Log the exception for debugging
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(responseMap);
        }
    }
	
	@PostMapping("workManagement/deleteProjectInfo") // POST 요청 처리
    public ResponseEntity<String> deleteProjectInfo(@RequestBody Map<String, Object> requestBody) {
    	System.out.println("Request Body: " + requestBody);

    	try {
            // Parse 'idx' from String to Integer
            int prjtId = Integer.parseInt((String) requestBody.get("prjtId")); // Convert String to Integer
            
            // Perform your deletion logic
            System.out.println("Parsed prjtId: " + prjtId);
        
            // 서비스 메서드 호출
            workManagementService.deleteProjectInfo(prjtId);
            
            return ResponseEntity.ok("Row deleted successfully");
        } catch (NumberFormatException e) {
            // Handle case where the value cannot be parsed as an Integer
            e.printStackTrace();
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                                 .body("Invalid format for idx: " + e.getMessage());
        } catch (Exception e) {
            // Handle other errors
            e.printStackTrace();
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                                 .body("Error during deletion: " + e.getMessage());
        }
    }
    
	/**
     * Endpoint to download a file by IDX.
     * 
     * @param idx       the work item's ID
     * @param fileName  the name of the file
     * @return ResponseEntity containing the file data
     */
	/*@GetMapping("workManagement/downloadFile")
	public ResponseEntity<byte[]> downloadFile(@RequestParam("idx") int idx,
	                                           @RequestParam("fileName") String fileName) {
	    System.out.println("### downloadFile 호출: idx=" + idx + ", fileName=" + fileName);

	    WorkFileVO workFile = workManagementService.getWorkFileByIdx(idx);

	    if (workFile == null || workFile.getTaskFile() == null) {
	        System.err.println("파일을 찾을 수 없음: idx=" + idx);
	        return ResponseEntity.status(HttpStatus.NOT_FOUND).body(null);
	    }

	    try (InputStream inputStream = workFile.getTaskFile()) {
	        byte[] fileData = inputStream.readAllBytes();

	        HttpHeaders headers = new HttpHeaders();
	        headers.setContentType(MediaType.APPLICATION_OCTET_STREAM);
	        headers.setContentDisposition(
	            ContentDisposition.builder("attachment")
	                .filename(fileName, StandardCharsets.UTF_8)
	                .build()
	        );

	        return ResponseEntity.ok().headers(headers).body(fileData);

	    } catch (Exception e) {
	        e.printStackTrace();
	        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(null);
	    }
	}*/

	/**
     * Endpoint to download a file by IDX.
     * 
     * @param idx       the work item's ID
     * @param fileName  the name of the file
     * @return ResponseEntity containing the file data
     */
	@GetMapping("workManagement/downloadFile")
	public ResponseEntity<byte[]> downloadFile(@RequestParam("idx") int idx,
	                                           @RequestParam("fileName") String fileName) {
	    System.out.println("### downloadFile 호출: idx=" + idx + ", fileName=" + fileName);

	    WorkFileVO workFile = workManagementService.getWorkFileByIdx(idx);

	    if (workFile == null || workFile.getTaskFile() == null) {
	        System.err.println("파일을 찾을 수 없음: idx=" + idx);
	        return ResponseEntity.status(HttpStatus.NOT_FOUND).body(null);
	    }

	    try (InputStream inputStream = workFile.getTaskFile()) {
	        byte[] fileData = toByteArray(inputStream); // Java 8 호환 방식

	        HttpHeaders headers = new HttpHeaders();
	        headers.setContentType(MediaType.APPLICATION_OCTET_STREAM);
	        headers.setContentDisposition(ContentDisposition.builder("attachment")
	                .filename(fileName, StandardCharsets.UTF_8)
	                .build());

	        return ResponseEntity.ok().headers(headers).body(fileData);

	    } catch (Exception e) {
	        e.printStackTrace();
	        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(null);
	    }
	}

	// Java 8 호환 유틸 메서드
	private byte[] toByteArray(InputStream input) throws IOException {
	    ByteArrayOutputStream buffer = new ByteArrayOutputStream();
	    byte[] data = new byte[4096];
	    int nRead;
	    while ((nRead = input.read(data, 0, data.length)) != -1) {
	        buffer.write(data, 0, nRead);
	    }
	    return buffer.toByteArray();
	}

	
    /**
     * 담당업무일지목록
     */	
	@RequestMapping("createWorkResList")
	public String createWorkResList(HttpServletRequest request) {	
		
		HttpSession session = request.getSession();
		JoinMemberVO loginUser = (JoinMemberVO) session.getAttribute("loginUser");

		if (loginUser != null) {
		    String id = loginUser.getId(); // Assuming 'getId()' returns the 'id' field
		    request.setAttribute("empId", id); // Set 'id' as 'empId' in request
		    request.setAttribute("empName", loginUser.getName());
		    request.setAttribute("empIndex", loginUser.getEmp_index());
		}

		return "workManagement/createWorkResList";			
	}
    
}
