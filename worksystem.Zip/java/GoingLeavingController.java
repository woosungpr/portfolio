package com.gn.work.controller;

import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.gn.work.service.BiztripService;
import com.gn.work.service.CalendarWorkService;
import com.gn.work.service.GoingLeavingService;
import com.gn.work.service.JoinMemberService;
import com.gn.work.service.VacationService;
import com.gn.work.vo.BiztripVO;
import com.gn.work.vo.CalendarWorkVO;
import com.gn.work.vo.GoingLeavingVO;
import com.gn.work.vo.JoinMemberVO;
import com.gn.work.vo.VacationVO;
import com.gn.work.vo.WorkManagementVO;

import org.springframework.ui.Model;


@Controller
public class GoingLeavingController {

    @Autowired
    private CalendarWorkService calendarWorkService;
    
    @Autowired
    private VacationService vacationService;
    
    @Autowired
    private BiztripService biztripService;
    
    @Autowired
	private JoinMemberService joinMemberService;
    
    @Autowired
	private GoingLeavingService goingLeavingService;
    
    
    /**
     * 출퇴근 화면 표시
     */	
	@RequestMapping("goingLeaving")
	public String goingLeavingView(HttpServletRequest request) {
		
		HttpSession session = request.getSession();
		JoinMemberVO loginUser = (JoinMemberVO) session.getAttribute("loginUser");

		// Get the attendDate from the session
		Date attendDate = loginUser.getAttend_date();
		
		// Format the date
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy년 M월 d일 H시 m분");
		String formattedDate = "";
		
		if(attendDate == null) {
			formattedDate = "";//formatter.format(new Date());
		}else {
			formattedDate = formatter.format(attendDate);
		}
		
		System.out.println("################### formattedDate:" + formattedDate + " request.getAttribute('empIndex'): " + request.getAttribute("empIndex"));
		
		if (loginUser != null) {
		    String id = loginUser.getId(); // Assuming 'getId()' returns the 'id' field
		    request.setAttribute("loginId", id); // Set 'id' as 'empId' in request
		    request.setAttribute("empName", loginUser.getName()); 
		    if(attendDate != null) {
		    	request.setAttribute("attendanceStatus", "출근");
		    }else {
		    	request.setAttribute("attendanceStatus", "");
		    }
		    
		    request.setAttribute("attendDate",formattedDate);
		}
		
		return "goingLeaving/calendarWork";			
	}
        
    /**
     * 출퇴근 데이터 취득 (모델 데이터 추가 후 페이지 리턴)
     */
	@PostMapping("work/getCalendarData")
	public ResponseEntity<Map<Integer,Map<String,List<CalendarWorkVO>>>> getCalendarData(@RequestParam int year, @RequestParam int month, @RequestParam String loginId) {
	System.out.println("################# work/getCalendarData year: "+year + " month: "+month + " loginId: "+loginId);	
	
	        Map<Integer, Map<String, List<CalendarWorkVO>>> calendarData = calendarWorkService.getCalendarWorkData(year, month, loginId);
	        
	        return ResponseEntity.ok(calendarData);
    }
	
	/*
	@RequestMapping(value = "work/getCalendarData", method = RequestMethod.POST) // 요청 방식 변경
	public Map<Integer, Map<Integer, CalendarWorkVO>> getCalendarData(
	            @RequestParam("year") Integer year, // required = true (POST 요청이므로 필수)
	            @RequestParam("month") Integer month) { // required = true (POST 요청이므로 필수)
System.out.println("################# work/getCalendarData year: "+year + " month: "+month);
        try {
            return calendarWorkService.getCalendarWorkData(year, month);
        } catch (Exception e) {
        	e.printStackTrace();
            // 예외 처리 및 로깅
            return new HashMap<>(); // 또는 예외에 따라 다른 응답 반환
        }
    }
	*/
	
	
    /**
     * 출퇴근 휴가 공유 데이터 취득
     */
	@PostMapping("work/getCalendarShareData")
	//public ResponseEntity<Map<Integer,Map<String,CalendarWorkVO>>> getCalendarShareData(@RequestParam int year, @RequestParam int month, @RequestParam int empIndex) {
	public ResponseEntity< Map<Integer, Map<String, List<CalendarWorkVO>>> > getCalendarShareData(@RequestBody Map<String, Object> param) {
			int year = (int) Double.parseDouble(param.get("year").toString());
			int month = (int) Double.parseDouble(param.get("month").toString());
		    //int empIndex = Integer.parseInt(param.get("empIndex").toString());
		
		    String empIndexStr = param.get("empIndex") != null ? param.get("empIndex").toString().trim() : "0";
		    int empIndex = empIndexStr.isEmpty() ? 0 : Integer.parseInt(empIndexStr);

	System.out.println("################# work/getCalendarShareData year: "+year + " month: "+month + " empIndex: "+empIndex);	
	
	        //Map<Integer, Map<String, CalendarWorkVO>> calendarData = calendarWorkService.getCalendarWorkShareData(year, month, empIndex);
		    Map<Integer, Map<String, List<CalendarWorkVO>>> calendarData = calendarWorkService.getCalendarWorkShareData(year, month, empIndex);
	
	        return ResponseEntity.ok(calendarData);
    }
	
    /**
     * 출장 공유 데이터 취득
     */
	@PostMapping("work/getCalendarBizShareData")
	public ResponseEntity< Map<Integer, Map<String, List<BiztripVO>>> > getCalendarBizShareData(@RequestBody Map<String, Object> param) {
			int year = (int) Double.parseDouble(param.get("year").toString());
			int month = (int) Double.parseDouble(param.get("month").toString());
		    //int empIndex = Integer.parseInt(param.get("empIndex").toString());
		
		    String empIndexStr = param.get("empIndex") != null ? param.get("empIndex").toString().trim() : "0";
		    int empIndex = empIndexStr.isEmpty() ? 0 : Integer.parseInt(empIndexStr);

	System.out.println("################# work/getCalendarBizShareData year: "+year + " month: "+month + " empIndex: "+empIndex);	
	
		    Map<Integer, Map<String, List<BiztripVO>>> calendarData = calendarWorkService.getCalendarBizShareData(year, month, empIndex);
	
	        return ResponseEntity.ok(calendarData);
    }
	
	  /**
     * 출퇴근-공유 화면 표시
     */	
	@RequestMapping("commuteVacation")
	public String commuteVacation(HttpServletRequest request) {
		
		HttpSession session = request.getSession();
		JoinMemberVO loginUser = (JoinMemberVO) session.getAttribute("loginUser");

		// Get the attendDate from the session
		Date attendDate = loginUser.getAttend_date();
		
		// Format the date
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy년 M월 d일 H시 m분");
		String formattedDate = "";
		
		if(attendDate == null) {
			formattedDate = "";//formatter.format(new Date());
		}else {
			formattedDate = formatter.format(attendDate);
		}
		
		System.out.println("################### formattedDate:" + formattedDate + " request.getAttribute('empIndex'): " + request.getAttribute("empIndex"));
		
		if (loginUser != null) {
		    String id = loginUser.getId(); // Assuming 'getId()' returns the 'id' field
		    request.setAttribute("loginId", id); // Set 'id' as 'empId' in request
		    request.setAttribute("empName", loginUser.getName()); 
		    if(attendDate != null) {
		    	request.setAttribute("attendanceStatus", "출근");
		    }else {
		    	request.setAttribute("attendanceStatus", "");
		    }
		    
		    request.setAttribute("attendDate",formattedDate);
		}
		
		return "goingLeaving/commuteVacation";			
	}
        
	
	/**
	 * 휴가신청 화면 표시
	 */
	@RequestMapping(value = "/vacationApply", method = RequestMethod.GET)
	public String vacationApply(@RequestParam(value = "applyId", required = false) String applyId, @RequestParam(value = "empIndex", required = false) int empIndex, Model model) {
			
		System.out.println(" ####################### vacationApply applyId= " + applyId+ " empIndex = " + empIndex);
		
	    // 날짜가 null이 아니면 모델에 추가
	    if (applyId != null && !applyId.isEmpty()) {
	        model.addAttribute("applyId", applyId);
	    }else {
	    	applyId = "0";
	    }

		 try {   
		    // 대행자 리스트
		    Map<String, Object> memberNameMap = new HashMap<>();
		    List<GoingLeavingVO> memberNameList = goingLeavingService.getDelegateList(memberNameMap);
		    //List<JoinMemberVO> memberNameList = joinMemberService.getMemberNameList(memberNameMap);
		    model.addAttribute("memberNameList", memberNameList);
	
		    Map<String, Object> paramMap = new HashMap<>();
		    paramMap.put("applyId", applyId);
		      
		    VacationVO vacationDetail = vacationService.getVacationDetails(paramMap);
		    
		    /*if (vacationDetail == null) {
		        System.out.println("vacationDetail 이 null입니다!");
		    } else if (vacationDetail.getStartDt() == null) {
		        System.out.println("StartDt 값이 설정되지 않았습니다!");
		    }*/
	
		    if(empIndex != 0) {
			    paramMap = new HashMap<>(); 
			    paramMap.put("empIndex", empIndex);		    
		  	    vacationService.updateRemainVacation(paramMap);
		    }
		    
		    model.addAttribute("vacationDetail", vacationDetail);
		} catch (Exception e) {
			e.printStackTrace();
		}
		 
	    return "goingLeaving/vacationApply"; // WEB-INF/views/goingLeaving/vacationApply.jsp 호출
	}
	
	/*
    @RequestMapping(value = "/vacationApply", method = RequestMethod.GET)
    public String vacationApply(Model model) {        
	    // 대행자 리스트
		Map<String, Object> memberNameMap = new HashMap<>();
		List<JoinMemberVO> memberNameList = joinMemberService.getMemberNameList(memberNameMap);
		model.addAttribute("memberNameList", memberNameList);
        return "goingLeaving/vacationApply"; // WEB-INF/views/goingLeaving/vacationApply.jsp 호출
    }*/

   
	/**
	 * 휴가신청
	 */	   
   @RequestMapping("/vacation")
   public ResponseEntity<Map<String, Object>> applyVacation(@RequestBody VacationVO vacationVO) {
       Map<String, Object> response = new HashMap<>();
       
       try {
           boolean result = vacationService.applyVacation(vacationVO);
           
           if(result) {
               response.put("success", true);
               response.put("message", "휴가 신청이 성공적으로 처리되었습니다.");
           } else {
               response.put("success", false);
               response.put("message", "휴가 신청 처리 중 오류가 발생했습니다.");
           }
           
           return ResponseEntity.ok(response);
       } catch (Exception e) {
           response.put("success", false);
           response.put("message", e.getMessage());
           return ResponseEntity.badRequest().body(response);
       }
   }
   
  /**
   * 휴가수정
   */	   
  @RequestMapping("/updatevacation")
  public ResponseEntity<Map<String, Object>> updateVacation(@RequestBody VacationVO vacationVO) {
      Map<String, Object> response = new HashMap<>();
      
      try {
          boolean result = vacationService.updateVacation(vacationVO);
          
          if(result) {
              response.put("success", true);
              response.put("message", "휴가 수정이 성공적으로 처리되었습니다.");
          } else {
              response.put("success", false);
              response.put("message", "휴가 수정 처리 중 오류가 발생했습니다.");
          }
          
          return ResponseEntity.ok(response);
      } catch (Exception e) {
          response.put("success", false);
          response.put("message", e.getMessage());
          return ResponseEntity.badRequest().body(response);
      }
  }
  
  /**
   * 휴가삭제
   */	   
  @RequestMapping("/deletevacation")
  public ResponseEntity<Map<String, Object>> deleteVacation(@RequestBody VacationVO vacationVO) {
      Map<String, Object> response = new HashMap<>();
      
      try {
          boolean result = vacationService.deleteVacation(vacationVO);
          
          if(result) {
              response.put("success", true);
              response.put("message", "휴가 삭제가 성공적으로 처리되었습니다.");
          } else {
              response.put("success", false);
              response.put("message", "휴가 삭제 처리 중 오류가 발생했습니다.");
          }
          
          return ResponseEntity.ok(response);
      } catch (Exception e) {
          response.put("success", false);
          response.put("message", e.getMessage());
          return ResponseEntity.badRequest().body(response);
      }
  }
   
	/**
	 * 출장신청 화면 표시
	 */	
   @RequestMapping(value = "/biztripApply", method = RequestMethod.GET)
   public String biztripApply(@RequestParam(value = "applyId", required = false) String applyId, Model model) {
	    // 날짜가 null이 아니면 모델에 추가
	    if (applyId != null && !applyId.isEmpty()) {
	        model.addAttribute("applyId", applyId);
	    }else {
	    	applyId = "0";
	    }
       
	    // 대행자 리스트
		Map<String, Object> memberNameMap = new HashMap<>();
		List<GoingLeavingVO> memberNameList = goingLeavingService.getDelegateList(memberNameMap);
		//List<JoinMemberVO> memberNameList = joinMemberService.getMemberNameList(memberNameMap);
		model.addAttribute("memberNameList", memberNameList);
		
		Map<String, Object> paramMap = new HashMap<>();
	    paramMap.put("applyId", applyId);
	      
	    BiztripVO biztripDetail = biztripService.getBiztripDetails(paramMap);
	    
		// vacationDetail.getSDate() 값이 null이 아닌지 로그로 확인
		//System.out.println("StartDt: " + biztripDetail.getStartDt());
	
	    /*if (biztripDetail == null) {
	        System.out.println("biztripDetail 이 null입니다!");
	    } else if (biztripDetail.getStartDt() == null) {
	        System.out.println("StartDt 값이 설정되지 않았습니다!");
	    }*/
	    
	    model.addAttribute("biztripDetail", biztripDetail);
		    
		    
        return "goingLeaving/biztripApply"; // WEB-INF/views/goingLeaving/biztripApply.jsp 호출
   }

   
	/**
	 * 출장신청
	 */	   
  @RequestMapping("/biztrip")
  public ResponseEntity<Map<String, Object>> applyBiztrip(@RequestBody BiztripVO biztripVO) {
      Map<String, Object> response = new HashMap<>();
      
      try {
          boolean result = biztripService.applyBiztrip(biztripVO);
          
          if(result) {
              response.put("success", true);
              response.put("message", "출장 신청이 성공적으로 처리되었습니다.");
          } else {
              response.put("success", false);
              response.put("message", "출장 신청 처리 중 오류가 발생했습니다.");
          }
          
          return ResponseEntity.ok(response);
      } catch (Exception e) {
          response.put("success", false);
          response.put("message", e.getMessage());
          return ResponseEntity.badRequest().body(response);
      }
  }

	 /**
	 * 출장신청
	 */	   
	@RequestMapping("/updatebiztrip")
	public ResponseEntity<Map<String, Object>> updateBiztrip(@RequestBody BiztripVO biztripVO) {
	    Map<String, Object> response = new HashMap<>();
	    
	    try {
	        boolean result = biztripService.updateBiztrip(biztripVO);
	        
	        if(result) {
	            response.put("success", true);
	            response.put("message", "출장 수정이 성공적으로 처리되었습니다.");
	        } else {
	            response.put("success", false);
	            response.put("message", "출장 수정 처리 중 오류가 발생했습니다.");
	        }
	        
	        return ResponseEntity.ok(response);
	    } catch (Exception e) {
	        response.put("success", false);
	        response.put("message", e.getMessage());
	        return ResponseEntity.badRequest().body(response);
	    }
	}
 
	@RequestMapping("/deletebiztrip")
	public ResponseEntity<Map<String, Object>> deleteBiztrip(@RequestBody BiztripVO biztripVO) {
	    Map<String, Object> response = new HashMap<>();
	    
	    try {
	        boolean result = biztripService.deleteBiztrip(biztripVO);
	        
	        if(result) {
	            response.put("success", true);
	            response.put("message", "출장 삭제가 성공적으로 처리되었습니다.");
	        } else {
	            response.put("success", false);
	            response.put("message", "출장 삭제 처리 중 오류가 발생했습니다.");
	        }
	        
	        return ResponseEntity.ok(response);
	    } catch (Exception e) {
	        response.put("success", false);
	        response.put("message", e.getMessage());
	        return ResponseEntity.badRequest().body(response);
	    }
	}

	/**
	* 휴가신청목록 - 관리
	*/	
	@RequestMapping("vacationList")
	public String vacationList(HttpServletRequest request) {
	   System.out.println("############################### vacationList");

	  //Map<String, Object> paramMap = new HashMap<>();
      //List<VacationVO> vacationList = vacationService.getVacationList(paramMap);
      //model.addAttribute("vacationList", vacationList);
		   
	   return "goingLeaving/vacationList"; 
	}

  /**
	* 휴가신청 - 관리
   */	
  @RequestMapping(value = "vacationAppManage", method = RequestMethod.GET)
  //public String vacationAppManage(Model model) {
  public String vacationAppManage(@RequestParam("applyId") int apply_Id, @RequestParam("empIndex") int emp_Index,Model model) {	  
	   
	 System.out.println("############################### vacationAppManage - apply_Id: " + apply_Id + " emp_Index: " + emp_Index);
	 model.addAttribute("apply_Id", apply_Id);  // 모델에 저장
	 model.addAttribute("emp_Index", emp_Index);
	 
     return "goingLeaving/vacationAppManage"; // WEB-INF/views/goingLeaving/vacationApply.jsp 호출
  }

  @GetMapping("getVacationList")  
  @ResponseBody
  public List<VacationVO> getVacationList(@RequestParam("searchDate") String searchDate) {
	  System.out.println("############################### getVacationList searchDate="+searchDate);
	  Map<String, Object> paramMap = new HashMap<>();
	  paramMap.put("searchDate", searchDate);
	  
      return vacationService.getVacationList(paramMap);
  }
  
  /*
  @GetMapping("/getVacationList")
  public String getVacationList(Model model) {
	  Map<String, Object> paramMap = new HashMap<>();
      List<VacationVO> vacationList = vacationService.getVacationList(paramMap);
      model.addAttribute("vacationList", vacationList);
      return "vacationList"; // Corresponds to your view (vacationList.jsp or .html)
  }*/

  
  @PostMapping("getVacationDetails")
  @ResponseBody // Ensures JSON is returned instead of a view
  public VacationVO getVacationDetails(@RequestBody Map<String, Object> param) {
      System.out.println("############################### getVacationDetails  ");
      
      Object applyIdObj = param.get("applyId");

      if (applyIdObj == null || applyIdObj.toString().trim().isEmpty()) {
          throw new IllegalArgumentException("applyId 값이 비어있습니다.");
      }

      int applyId;
      try {
    	  applyId = Integer.parseInt(applyIdObj.toString().trim());
      } catch (NumberFormatException e) {
          throw new IllegalArgumentException("applyId는 정수여야 합니다.");
      }

      System.out.println("applyId: " + applyId);
      
      Map<String, Object> paramMap = new HashMap<>();
      paramMap.put("applyId", applyId);
      
      return vacationService.getVacationDetails(paramMap);
  }
 
  
	@PostMapping("updateVacationAppr")   
	public ResponseEntity<Map<String, Object>> updateVacationAppr(@RequestBody Map<String, Object> param) {		
      System.out.println("updateVacationAppr Received data: " + param);
      
      if (param == null || param.isEmpty()) {
          Map<String, Object> responseMap = new HashMap<>();
          responseMap.put("message", "No data received");
          
          return ResponseEntity.badRequest().body(responseMap);
      }        
      try {
         
    	  System.out.println("applyId class: " + param.get("applyId").getClass().getName());

    	  if (param.containsKey("applyId")) {
    		    param.put("applyId", Long.valueOf(param.get("applyId").toString()));
   		  }

    	  vacationService.updateVacationAppr(param);
          
          Map<String, Object> responseMap = new HashMap<>();
          responseMap.put("message", "Data saved successfully");
          
          return ResponseEntity.ok(responseMap);
      } catch (Exception e) {
          Map<String, Object> responseMap = new HashMap<>();
          responseMap.put("message", "Failed to save data");
      	
          e.printStackTrace(); // Log the exception for debugging
          return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(responseMap);
      }
	}
	
	
	 /**
	 * 출장신청 - 관리
	 */	
	 @RequestMapping("biztripList")
	 public String biztripList(HttpServletRequest request) {
		System.out.println("############################### biztripList");
	    /*
		Map<String, Object> memberNameMap = new HashMap<>();
		List<JoinMemberVO> memberNameList = joinMemberService.getMemberNameList(memberNameMap);
		model.addAttribute("memberNameList", memberNameList);
	   	*/
		   
	     return "goingLeaving/biztripList"; // WEB-INF/views/goingLeaving/biztripList.jsp 호출
	 }

	  /**
		* 출가신청 - 관리
	   */	
	  @RequestMapping(value = "biztripAppManage", method = RequestMethod.GET)
	  public String biztripAppManage(@RequestParam("applyId") int apply_Id, @RequestParam("empIndex") int emp_Index,Model model) {	  
		   
		 System.out.println("############################### biztripAppManage - apply_Id: " + apply_Id + " emp_Index: " + emp_Index);
		 model.addAttribute("apply_Id", apply_Id);  // 모델에 저장
		 model.addAttribute("emp_Index", emp_Index);
		 
	     return "goingLeaving/biztripAppManage";
	  }

	  @GetMapping("getBiztripList")  
	  @ResponseBody
	  public List<BiztripVO> getBiztripList(@RequestParam("searchDate") String searchDate) {
		  System.out.println("############################### getBiztripList searchDate=" + searchDate);
		  Map<String, Object> paramMap = new HashMap<>();
		  paramMap.put("searchDate", searchDate);
		  
	      return biztripService.getBiztripList(paramMap);
	  }
	 
	  @PostMapping("getBiztripDetails")
	  @ResponseBody // Ensures JSON is returned instead of a view
	  public BiztripVO getBiztripDetails(@RequestBody Map<String, Object> param) {
	      System.out.println("############################### getBiztripDetails  ");
	      
	      Object applyIdObj = param.get("applyId");

	      if (applyIdObj == null || applyIdObj.toString().trim().isEmpty()) {
	          throw new IllegalArgumentException("applyId 값이 비어있습니다.");
	      }

	      int applyId;
	      try {
	    	  applyId = Integer.parseInt(applyIdObj.toString().trim());
	      } catch (NumberFormatException e) {
	          throw new IllegalArgumentException("applyId는 정수여야 합니다.");
	      }

	      System.out.println("applyId: " + applyId);
	      
	      Map<String, Object> paramMap = new HashMap<>();
	      paramMap.put("applyId", applyId);
	      
	      return biztripService.getBiztripDetails(paramMap);
	  }
	 
	  
		@PostMapping("updateBiztripAppr")   
		public ResponseEntity<Map<String, Object>> updateBiztripAppr(@RequestBody Map<String, Object> param) {		
	      System.out.println("updateBiztripAppr Received data: " + param);
	      
	      if (param == null || param.isEmpty()) {
	          Map<String, Object> responseMap = new HashMap<>();
	          responseMap.put("message", "No data received");
	          
	          return ResponseEntity.badRequest().body(responseMap);
	      }        
	      try {
	         
	    	  System.out.println("applyId class: " + param.get("applyId").getClass().getName());

	    	  if (param.containsKey("applyId")) {
	    		    param.put("applyId", Long.valueOf(param.get("applyId").toString()));
	   		  }

	    	  biztripService.updateBiztripAppr(param);
	          
	          Map<String, Object> responseMap = new HashMap<>();
	          responseMap.put("message", "Data saved successfully");
	          
	          return ResponseEntity.ok(responseMap);
	      } catch (Exception e) {
	          Map<String, Object> responseMap = new HashMap<>();
	          responseMap.put("message", "Failed to save data");
	      	
	          e.printStackTrace(); // Log the exception for debugging
	          return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(responseMap);
	      }
	  }
		
		/*	
		@PostMapping("updateRemainVacation")   
		public ResponseEntity<Map<String, Object>> updateRemainVacation(@RequestBody Map<String, Object> param) {		
	      System.out.println("updateRemainVacation Received data: " + param);
	      
	      if (param == null || param.isEmpty()) {
	          Map<String, Object> responseMap = new HashMap<>();
	          responseMap.put("updateRemainVacation message", "No data received");
	          
	          return ResponseEntity.badRequest().body(responseMap);
	      }        
	      try {
	         
	    	  System.out.println("updateRemainVacation empIndex class: " + param.get("empIndex").getClass().getName());

	    	  if (param.containsKey("empIndex")) {
	    		    param.put("empIndex", Long.valueOf(param.get("empIndex").toString()));
	   		  }

	    	  vacationService.updateRemainVacation(param);
	          
	          Map<String, Object> responseMap = new HashMap<>();
	          responseMap.put("message", "updateRemainVacation Data saved successfully");
	          
	          return ResponseEntity.ok(responseMap);
	      } catch (Exception e) {
	          Map<String, Object> responseMap = new HashMap<>();
	          responseMap.put("message", "updateRemainVacation Failed to save data");
	      	
	          e.printStackTrace(); // Log the exception for debugging
	          return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(responseMap);
	      }
		}
		*/
		
}
