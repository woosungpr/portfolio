window.addEventListener("load", function() {
	setTimeout(scrollTo, 0, 0, 0, 1);
}, false);

window.addEventListener("orientationchange", function() {
	setTimeout(scrollTo, 0, 0, 0, 1);
}, false);