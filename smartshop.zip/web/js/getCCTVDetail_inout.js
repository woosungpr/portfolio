//검색
function fncSubmit(){

  if(document.getElementById("timeself").value == 'T'){//time 
	  if(!checkData()){
		  return;
	  }
	  getTimeInout(); //검색
  }
  
  if(document.getElementById("timeself").value == 'S'){// self
	  if(!checkSLData()){
		  return;
	  }
	  if(!checkSRData()){
		  return;
	  }
	  getLSelfInout();//좌측조회
	  getRSelfInout();//우측조회
  }

}

// Time 일경우 
function getTimeInout(){

  var serial_no = $("#serial_no").val();
  var display_type = $("#display_type").val();
  var mdhcho = $("#mdhcho").val();
  var timeself = $("#timeself").val();
  var hstartdate = $("#hstartdate").val();
  var hstarttime = $("#hstarttime").val();
  var henddate = $("#henddate").val();
  var hendtime = $("#hendtime").val();
  var dstartdate = $("#dstartdate").val();
  var denddate = $("#denddate").val();
  var mstartyear = $("#mstartyear").val();
  var mstartmonth = $("#mstartmonth").val();
  var mendyear = $("#mendyear").val();
  var mendmonth = $("#mendmonth").val();
  var User_ID   = $("#User_ID").val();

  var tableyn = $("#tableonyn").val();//표
  var graphyn = $("#graphonyn").val();//그래프
  
  var acturl = "";
  
  if(tableyn == 'Y') acturl = "./action/getCCTVInOutAction.jsp";
  if(graphyn == 'Y') acturl = "./action/getCCTVInOutGraphAction.jsp";
  

  $.ajax({
    type : "post",
    url : acturl,
    data : {"serial_no":serial_no,"display_type":display_type
      ,"mdhcho":mdhcho,"timeself":timeself,"hstartdate":hstartdate
      ,"hstarttime":hstarttime,"henddate":henddate,"hendtime":hendtime
      ,"dstartdate":dstartdate,"denddate":denddate,"mstartyear":mstartyear
      ,"mstartmonth":mstartmonth,"mendyear":mendyear,"mendmonth":mendmonth
      ,"User_ID":User_ID},
      
    dataType : "html",
    async : false,
    success : function(result) {
      //alert(result);
      if(tableyn == 'Y'){//표일 경우
	      if(mdhcho == 'H') $("#timelabel").text("시간");
	      if(mdhcho == 'D') $("#timelabel").text("일자");
	      if(mdhcho == 'M') $("#timelabel").text("년월");

	      document.getElementById("timetab_grid").style.display = "";
	      document.getElementById("selftab_grid").style.display = "none";
      	  document.getElementById("chart_div").style.display = "none";
      	  document.getElementById("chart_div_sl").style.display = "none";
      	  document.getElementById("chart_div_sr").style.display = "none";
      	  $("#timetab_tbl").html(result);
      	  document.getElementById("excel_val").value = result;
      }
      
      if(graphyn == 'Y'){//그래프일 경우
    	  $("#chart_div").html(result);
    	  var strdata = document.getElementById("strdata").value;
    	  var vaxistitle = document.getElementById("vaxistitle").value;
    	  var haxistitle = document.getElementById("haxistitle").value;
    	  
	      document.getElementById("timetab_grid").style.display = "none";
	      document.getElementById("selftab_grid").style.display = "none";
      	  document.getElementById("chart_div").style.display = "";
      	  document.getElementById("chart_div_sl").style.display = "none";
      	  document.getElementById("chart_div_sr").style.display = "none";
    	  
    	  drawVisualization(strdata,vaxistitle,haxistitle,'chart_div');//그래프 그리기
      }
      //alert($("#timelabel").text());
      //$("#othertab_tbl").css('height', '10px');
    },

    error : function(e) {
      alert(e.responseText);
    }
  });
}

//좌측 self 일경우 
function getLSelfInout(){

  var serial_no = $("#serial_no").val();
  var display_type = $("#display_type").val();
  var mdhcho = $("#smdhcho").val();
  var timeself = $("#timeself").val();
  var hstartdate = $("#shstartdate").val();
  var hstarttime = $("#shstarttime").val();
  var henddate = $("#shenddate").val();
  var hendtime = $("#shendtime").val();
  var dstartdate = $("#sdstartdate").val();
  var denddate = $("#sdenddate").val();
  var mstartyear = $("#smstartyear").val();
  var mstartmonth = $("#smstartmonth").val();
  var mendyear = $("#smendyear").val();
  var mendmonth = $("#smendmonth").val();
  var User_ID   = $("#User_ID").val();

  var tableyn = $("#tableonyn").val();//표
  var graphyn = $("#graphonyn").val();//그래프
  
  var acturl = "";
  
  if(tableyn == 'Y') acturl = "./action/getCCTVInOutAction.jsp";
  if(graphyn == 'Y') acturl = "./action/getCCTVInOutGraphAction.jsp";
  
  $.ajax({
    type : "post",
    url : acturl,
    data : {"serial_no":serial_no,"display_type":display_type
      ,"mdhcho":mdhcho,"timeself":timeself,"hstartdate":hstartdate
      ,"hstarttime":hstarttime,"henddate":henddate,"hendtime":hendtime
      ,"dstartdate":dstartdate,"denddate":denddate,"mstartyear":mstartyear
      ,"mstartmonth":mstartmonth,"mendyear":mendyear,"mendmonth":mendmonth
      ,"User_ID":User_ID,"sLR":'L'},
      
    dataType : "html",
    async : false,
    success : function(result) {
      //alert(result);
    	if(tableyn == 'Y'){//표일 경우	
	      if(mdhcho == 'H') $("#sltimelabel").text("시간");
	      if(mdhcho == 'D') $("#sltimelabel").text("일자");
	      if(mdhcho == 'M') $("#sltimelabel").text("년월");

	      document.getElementById("timetab_grid").style.display = "none";
	      document.getElementById("selftab_grid").style.display = "";
      	  document.getElementById("chart_div").style.display = "none";
      	  document.getElementById("chart_div_sl").style.display = "none";
      	  document.getElementById("chart_div_sr").style.display = "none";
      	  
	      $("#lselftab_tbl").html(result);
	      document.getElementById("lexcel_val").value = result;
    	}
      
      
      if(graphyn == 'Y'){//그래프일 경우
    	  $("#chart_div_sl").html(result);
    	  var strdata = document.getElementById("lstrdata").value;
    	  var vaxistitle = document.getElementById("lvaxistitle").value;
    	  var haxistitle = document.getElementById("lhaxistitle").value;
    	  
	      document.getElementById("timetab_grid").style.display = "none";
	      document.getElementById("selftab_grid").style.display = "none";
      	  document.getElementById("chart_div").style.display = "none";
      	  document.getElementById("chart_div_sl").style.display = "";
      	  document.getElementById("chart_div_sr").style.display = "";
    	  
    	  drawVisualizationsLR(strdata,vaxistitle,haxistitle,'chart_div_sl');//그래프 그리기
      }

    },

    error : function(e) {
      alert(e.responseText);
    }
  });
}


//우측 self 일경우 
function getRSelfInout(){

  var serial_no = $("#serial_no").val();
  var display_type = $("#display_type").val();
  var mdhcho = $("#smdhcho").val();
  var timeself = $("#timeself").val();
  var hstartdate = $("#shstartdate1").val();
  var hstarttime = $("#shstarttime1").val();
  var henddate = $("#shenddate1").val();
  var hendtime = $("#shendtime1").val();
  var dstartdate = $("#sdstartdate1").val();
  var denddate = $("#sdenddate1").val();
  var mstartyear = $("#smstartyear1").val();
  var mstartmonth = $("#smstartmonth1").val();
  var mendyear = $("#smendyear1").val();
  var mendmonth = $("#smendmonth1").val();
  var User_ID   = $("#User_ID").val();

  var tableyn = $("#tableonyn").val();//표
  var graphyn = $("#graphonyn").val();//그래프
  
  var acturl = "";
  
  if(tableyn == 'Y') acturl = "./action/getCCTVInOutAction.jsp";
  if(graphyn == 'Y') acturl = "./action/getCCTVInOutGraphAction.jsp";

  
  $.ajax({
    type : "post",
    url : acturl,
    data : {"serial_no":serial_no,"display_type":display_type
      ,"mdhcho":mdhcho,"timeself":timeself,"hstartdate":hstartdate
      ,"hstarttime":hstarttime,"henddate":henddate,"hendtime":hendtime
      ,"dstartdate":dstartdate,"denddate":denddate,"mstartyear":mstartyear
      ,"mstartmonth":mstartmonth,"mendyear":mendyear,"mendmonth":mendmonth
      ,"User_ID":User_ID,"sLR":'R'},
      
    dataType : "html",
    async : false,
    success : function(result) {
      //alert(result);
      
	  	if(tableyn == 'Y'){//표일 경우	
		      if(mdhcho == 'H') $("#srtimelabel").text("시간");
		      if(mdhcho == 'D') $("#srtimelabel").text("일자");
		      if(mdhcho == 'M') $("#srtimelabel").text("년월");
	
		      document.getElementById("timetab_grid").style.display = "none";
		      document.getElementById("selftab_grid").style.display = "";
	      	  document.getElementById("chart_div").style.display = "none";
	      	  document.getElementById("chart_div_sl").style.display = "none";
	      	  document.getElementById("chart_div_sr").style.display = "none";
	      	  
		      $("#rselftab_tbl").html(result);
		      document.getElementById("rexcel_val").value = result;
	  	}
	    
	    if(graphyn == 'Y'){//그래프일 경우
	  	  $("#chart_div_sr").html(result);
	  	  var strdata = document.getElementById("rstrdata").value;
	  	  var vaxistitle = document.getElementById("rvaxistitle").value;
	  	  var haxistitle = document.getElementById("rhaxistitle").value;
	  	  
	      document.getElementById("timetab_grid").style.display = "none";
	      document.getElementById("selftab_grid").style.display = "none";
      	  document.getElementById("chart_div").style.display = "none";
      	  document.getElementById("chart_div_sl").style.display = "";
      	  document.getElementById("chart_div_sr").style.display = "";
      	  
	  	  drawVisualizationsLR(strdata,vaxistitle,haxistitle,'chart_div_sr');//그래프 그리기
	    }


    },

    error : function(e) {
      alert(e.responseText);
    }
  });
}

//시간, 일, 년월  선택
function setTimeRadio(param) {
	
	if(param == 'time'){
		
		document.getElementById("timeOn").style.display = "";
		document.getElementById("timeOff").style.display = "none";
		document.getElementById("dayOn").style.display = "none";
		document.getElementById("dayOff").style.display = "";
		document.getElementById("monthOn").style.display = "none";
		document.getElementById("monthOff").style.display = "";
		
		document.all.timeonyn.value = "Y";
		document.all.dayonyn.value = "N";
		document.all.monthonyn.value = "N";
	}
	
	//alert('param = ' + param);
	if(param == 'day'){
		//alert('dayOn = ' + document.getElementById("dayOn"));		
		document.getElementById("timeOn").style.display = "none";
		document.getElementById("timeOff").style.display = "";
		document.getElementById("dayOn").style.display = "";
		document.getElementById("dayOff").style.display = "none";
		document.getElementById("monthOn").style.display = "none";
		document.getElementById("monthOff").style.display = "";

		document.all.timeonyn.value  = "N";
		document.all.dayonyn.value   = "Y";
		document.all.monthonyn.value = "N";
	}

	
	if(param == 'month'){
		document.getElementById("timeOn").style.display = "none";
		document.getElementById("timeOff").style.display = "";
		document.getElementById("dayOn").style.display = "none";
		document.getElementById("dayOff").style.display = "";
		document.getElementById("monthOn").style.display = "";
		document.getElementById("monthOff").style.display = "none";

		document.all.timeonyn.value  = "N";
		document.all.dayonyn.value   = "N";
		document.all.monthonyn.value = "Y";
	}

	// SELF
	if(param == 'stime'){
		
		document.getElementById("stimeOn").style.display = "";
		document.getElementById("stimeOff").style.display = "none";
		document.getElementById("sdayOn").style.display = "none";
		document.getElementById("sdayOff").style.display = "";
		document.getElementById("smonthOn").style.display = "none";
		document.getElementById("smonthOff").style.display = "";
		
		document.all.stimeonyn.value = "Y";
		document.all.sdayonyn.value = "N";
		document.all.smonthonyn.value = "N";
	}
	
	//alert('param = ' + param);
	if(param == 'sday'){
		//alert('dayOn = ' + document.getElementById("dayOn"));		
		document.getElementById("stimeOn").style.display = "none";
		document.getElementById("stimeOff").style.display = "";
		document.getElementById("sdayOn").style.display = "";
		document.getElementById("sdayOff").style.display = "none";
		document.getElementById("smonthOn").style.display = "none";
		document.getElementById("smonthOff").style.display = "";

		document.all.stimeonyn.value  = "N";
		document.all.sdayonyn.value   = "Y";
		document.all.smonthonyn.value = "N";
	}

	
	if(param == 'smonth'){
		document.getElementById("stimeOn").style.display = "none";
		document.getElementById("stimeOff").style.display = "";
		document.getElementById("sdayOn").style.display = "none";
		document.getElementById("sdayOff").style.display = "";
		document.getElementById("smonthOn").style.display = "";
		document.getElementById("smonthOff").style.display = "none";

		document.all.stimeonyn.value  = "N";
		document.all.sdayonyn.value   = "N";
		document.all.smonthonyn.value = "Y";
	}

}

//표, 그래프 선택
function setDispRadio(param) {
	
	if(param == 'table'){
		
		document.getElementById("tableon").style.display = "";
		document.getElementById("tableoff").style.display = "none";
		document.getElementById("graphon").style.display = "none";
		document.getElementById("graphoff").style.display = "";
		
		document.all.tableonyn.value = "Y";
		document.all.graphonyn.value = "N";
		
		document.getElementById("imgExcel").style.display = "";		
	}
	
	//alert('param = ' + param);
	if(param == 'graph'){
		//alert('dayOn = ' + document.getElementById("dayOn"));		
		document.getElementById("tableon").style.display = "none";
		document.getElementById("tableoff").style.display = "";
		document.getElementById("graphon").style.display = "";
		document.getElementById("graphoff").style.display = "none";
		
		//if(document.getElementById("timeself").value == 'T'){
		//	document.getElementById("chart_div").style.display = "";
		//}
		
		document.all.tableonyn.value = "N";
		document.all.graphonyn.value = "Y";
		
		document.getElementById("imgExcel").style.display = "none";
	}

	setDispGrid();
	setDispGrap();
	
}

//하단 그리드 표시 유무
function setDispGrid(){

	if(document.all.tableonyn.value == 'Y' && document.getElementById("timeself").value == 'T'){
		document.getElementById("timetab_grid").style.display = "";
		document.getElementById("selftab_grid").style.display = "none";
		document.getElementById("selftab_grid_r").style.display = "none";		
		//alert('1');
	}

	if(document.all.tableonyn.value == 'Y' && document.getElementById("timeself").value == 'S'){
		document.getElementById("timetab_grid").style.display = "none";
		document.getElementById("selftab_grid").style.display = "";
		document.getElementById("selftab_grid_r").style.display = "";
		//alert('2');
	}

	if(document.all.graphonyn.value == 'Y'){
		document.getElementById("timetab_grid").style.display = "none";
		document.getElementById("selftab_grid").style.display = "none";
		document.getElementById("selftab_grid_r").style.display = "none";
		//alert('3');
	}

}


//하단 그래프 표시 유무
function setDispGrap(){

	if(document.all.tableonyn.value == 'Y'){
		document.getElementById("chart_div").style.display = "none";
		document.getElementById("chart_div_sl").style.display = "none";
		document.getElementById("chart_div_sr").style.display = "none";
		//alert('4');
	}

	if(document.all.graphonyn.value == 'Y' && document.getElementById("timeself").value == 'T' ){
		document.getElementById("chart_div").style.display = "";
		document.getElementById("chart_div_sl").style.display = "none";
		document.getElementById("chart_div_sr").style.display = "none";
		//alert('7');
	}

	if(document.all.graphonyn.value == 'Y' && document.getElementById("timeself").value == 'S' ){
		document.getElementById("chart_div").style.display = "none";
		document.getElementById("chart_div_sl").style.display = "";
		document.getElementById("chart_div_sr").style.display = "";
		//alert('6');
	}

}

//time, self 선택
function changCond(param){
	
	if(param == 'time'){
		//alert('dayOn = ' + document.getElementById("dayOn"));		
		document.getElementById("timetab").style.display = "";
		//document.getElementById("timetab_grid").style.display = "";
		document.getElementById("selftab").style.display = "none";
		//document.getElementById("selftab_grid").style.display = "none";
		//document.getElementById("selftab_grid_r").style.display = "none";
		
		document.getElementById("timeself").value = "T"; //time 일경우
	}
	

	if(param == 'self'){
		//alert('dayOn = ' + document.getElementById("dayOn"));
		document.getElementById("timetab").style.display = "none";
		//document.getElementById("timetab_grid").style.display = "none";
		document.getElementById("selftab").style.display = "";
		//document.getElementById("selftab_grid").style.display = "";
		//document.getElementById("selftab_grid_r").style.display = "";
		
		document.getElementById("timeself").value = "S"; //self 일경우
	}

	setDispGrid();
	setDispGrap();
}

//시간 차이
function checkTimeDiff(sdt,sti,edt,eti){
	
	var stmp = sdt;//document.getElementById("hstartdate").value;
	var etmp = sti;//document.getElementById("hstarttime").value;
	var ymd = stmp.split("-");

	var sDt = new Date(Number(ymd[0]),Number(ymd[1])-1,Number(ymd[2]),Number(etmp));
	
	//alert(ymd[0]+ymd[1]+ymd[2]+etmp);
	
	stmp = edt;//document.getElementById("henddate").value;
	etmp = eti;//document.getElementById("hendtime").value;
	ymd = stmp.split("-");
	
	var eDt = new Date(Number(ymd[0]),Number(ymd[1])-1,Number(ymd[2]),Number(etmp));

	//alert(ymd[0]+ymd[1]+ymd[2]+etmp);
	//alert(eDt.getTime() + ' ' + sDt.getTime());
	
	var dtmp  = eDt.getTime()/60000; //분
	var dtmp1 = sDt.getTime()/60000; //분
	
	var htmp = (dtmp-dtmp1) / 60; //시
	
	//alert('dtmp = ' + dtmp + ' dtmp1 = ' + dtmp1 + ' htmp = ' + htmp);
	
	if(htmp > 24){
		alert('24 시간 이내로 조회가 가능합니다.');
		return false;
	}
	
	return true;
}

//일수 차이
function checkDayDiff(stime,etime){
	
	var stmp = stime;//document.getElementById("dstartdate").value;
	var etmp = "00";
	var ymd = stmp.split("-");

	var sDt = new Date(Number(ymd[0]),Number(ymd[1])-1,Number(ymd[2]),Number(etmp));
	
	//alert(ymd[0]+ymd[1]+ymd[2]+etmp);
	
	stmp = etime;//document.getElementById("denddate").value;
	etmp = "24";
	ymd = stmp.split("-");
	
	var eDt = new Date(Number(ymd[0]),Number(ymd[1])-1,Number(ymd[2]),Number(etmp));

	//alert(ymd[0]+ymd[1]+ymd[2]+etmp);
	//alert(eDt.getTime() + ' ' + sDt.getTime());
	
	var dtmp  = eDt.getTime()/60000; //분
	var dtmp1 = sDt.getTime()/60000; //분
	
	var htmp = (dtmp-dtmp1) / 60; //시
	
	htmp = htmp / 24; //일
	
	//alert('dtmp = ' + dtmp + ' dtmp1 = ' + dtmp1 + ' htmp = ' + htmp);
	
	if(htmp > 30){
		alert('30일 이내로 조회가 가능합니다.');
		return false;
	}
	
	return true;
}

//개월수 차이
function checkMonthDiff(syy,smm,eyy,emm){
	
	var stmp = syy;//document.getElementById("mstartyear").value;
	var etmp = smm;//document.getElementById("mstartmonth").value;

	var strtYear = parseInt(stmp); 
	var strtMonth = parseInt(etmp); 

	stmp = eyy;//document.getElementById("mendyear").value;
	etmp = emm;//document.getElementById("mendmonth").value;

	var endYear = parseInt(stmp); 
	var endMonth = parseInt(etmp); 

	var month = 0;

	if(endYear > strtYear){
		month = (endYear - strtYear)* 12 + (endMonth - strtMonth) + 1; 
	}else{
		month = (endYear - strtYear)* 12 + (endMonth - strtMonth); 
	}

	
	if(month > 12){
		alert('12개월 이내로 조회가 가능합니다.');
		return false;
	}
	
	return true;
}


//TIME 조회조건
function checkData(){
	var timeyn  = document.all.timeonyn.value;
	var dayyn   = document.all.dayonyn.value;
	var monthyn = document.all.monthonyn.value;
	var stime   = "";
	var etime   = "";
	
	var rtn    = true;
	//var f    = document.searchForm;
	//alert('timeyn = ' + timeyn);
	
	if(timeyn == 'Y'){
		if(document.getElementById("hstartdate").value == ''){
			alert('시작 일시를  입력하세요.');
			document.getElementById("hstartdate").focus();
			return false;
		}

		if(document.getElementById("henddate").value == ''){
			alert('종료 일시를  입력하세요.');
			document.getElementById("henddate").focus();
			return false;
		}
		
		stime = document.getElementById("hstartdate").value + document.getElementById("hstarttime").value;
		etime = document.getElementById("henddate").value + document.getElementById("hendtime").value;
		
		if(stime > etime){
			alert('시작일시는 종료 일시보다 클 수 없습니다.');
			document.getElementById("hstartdate").focus();
			return false;
		}
		
		if(! checkTimeDiff(stime.substring(0, 10),stime.substring(10, 12),etime.substring(0, 10),etime.substring(10, 12)) ){
			document.getElementById("hstartdate").focus();
			return false;
		}
		
		document.getElementById("mdhcho").value = "H";
	}

	if(dayyn == 'Y'){
		if(document.getElementById("dstartdate").value == ''){
			alert('시작일을  입력하세요.');
			document.getElementById("dstartdate").focus();
			return false;
		}

		if(document.getElementById("denddate").value == ''){
			alert('종료일을  입력하세요.');
			document.getElementById("denddate").focus();
			return false;
		}

		stime = document.getElementById("dstartdate").value;
		etime = document.getElementById("denddate").value;
		
		if(stime > etime){
			alert('시작일자는 종료 일자보다 클 수 없습니다.');
			document.getElementById("dstartdate").focus();
			return false;
		}

		if(!checkDayDiff(stime,etime)){
			document.getElementById("dstartdate").focus();
			return false;
		}
		
		document.getElementById("mdhcho").value = "D";
	}

	
	if(monthyn == 'Y'){
		if(document.getElementById("mstartyear").value == ''){
			alert('시작년을  입력하세요.');
			document.getElementById("mstartyear").focus();
			return false;
		}

		if(document.getElementById("mstartmonth").value == ''){
			alert('시작월을  입력하세요.');
			document.getElementById("mstartmonth").focus();
			return false;
		}

		if(document.getElementById("mendyear").value == ''){
			alert('종료년을  입력하세요.');
			document.getElementById("mendyear").focus();
			return false;
		}

		if(document.getElementById("mendmonth").value == ''){
			alert('종료월을  입력하세요.');
			document.getElementById("mendmonth").focus();
			return false;
		}

		stime = document.getElementById("mstartyear").value+document.getElementById("mstartmonth").value;
		etime = document.getElementById("mendyear").value+document.getElementById("mendmonth").value;
		
		if(stime > etime){
			alert('시작년월은 종료년월보다 클 수 없습니다.');
			document.getElementById("mstartyear").focus();
			return false;
		}
		
		if(!checkMonthDiff(stime.substring(0, 4),stime.substring(4, 6),etime.substring(0, 4),etime.substring(4, 6))){
			document.getElementById("mstartyear").focus();
			return false;
		}
		
		document.getElementById("mdhcho").value = "M";
	}

	return rtn;
}


//SELF 좌측 조회조건 체크
function checkSLData(){
	
	var timeyn  = document.all.stimeonyn.value;
	var dayyn   = document.all.sdayonyn.value;
	var monthyn = document.all.smonthonyn.value;
	var stime	= "";
	var etime	= "";
	
	var rtn    = true;
	//var f 	   = document.searchForm;
	
	//alert('timeyn = ' + timeyn);
	
	if(timeyn == 'Y'){
		if(document.getElementById("shstartdate").value == ''){
			alert('시작 일시를  입력하세요.');
			document.getElementById("shstartdate").focus();
			return false;
		}

		if(document.getElementById("shenddate").value == ''){
			alert('종료 일시를  입력하세요.');
			document.getElementById("shenddate").focus();
			return false;
		}
		
		stime = document.getElementById("shstartdate").value+document.getElementById("shstarttime").value;
		etime = document.getElementById("shenddate").value+document.getElementById("shendtime").value;
		
		if(stime > etime){
			alert('시작일시는 종료 일시보다 클 수 없습니다.');
			document.getElementById("shstartdate").focus();
			return false;
		}

		if(! checkTimeDiff(stime.substring(0, 10),stime.substring(10, 12),etime.substring(0, 10),etime.substring(10, 12)) ){
			document.getElementById("shstartdate").focus();
			return false;
		}

		document.getElementById("smdhcho").value = "H";
	}

	if(dayyn == 'Y'){
		if(document.getElementById("sdstartdate").value == ''){
			alert('시작일을  입력하세요.');
			document.getElementById("sdstartdate").focus();
			return false;
		}

		if(document.getElementById("sdenddate").value == ''){
			alert('종료일을  입력하세요.');
			document.getElementById("sdenddate").focus();
			return false;
		}
		
		stime = document.getElementById("sdstartdate").value;
		etime = document.getElementById("sdenddate").value;
		
		if(stime > etime){
			alert('시작일자는 종료 일자보다 클 수 없습니다.');
			document.getElementById("sdstartdate").focus();
			return false;
		}
		
		if(!checkDayDiff(stime,etime)){
			document.getElementById("sdstartdate").focus();
			return false;
		}
		
		document.getElementById("smdhcho").value = "D";
	}

	
	if(monthyn == 'Y'){
		if(document.getElementById("smstartyear").value == ''){
			alert('시작년을  입력하세요.');
			document.getElementById("smstartyear").focus();
			return false;
		}

		if(document.getElementById("smstartmonth").value == ''){
			alert('시작월을  입력하세요.');
			document.getElementById("smstartmonth").focus();
			return false;
		}

		if(document.getElementById("smendyear").value == ''){
			alert('종료년을  입력하세요.');
			document.getElementById("smendyear").focus();
			return false;
		}

		if(document.getElementById("smendmonth").value == ''){
			alert('종료월을  입력하세요.');
			document.getElementById("smendmonth").focus();
			return false;
		}

		stime = document.getElementById("smstartyear").value+document.getElementById("smstartmonth").value;
		etime = document.getElementById("smendyear").value+document.getElementById("smendmonth").value;
		
		if(stime > etime){
			alert('시작년월은 종료년월보다 클 수 없습니다.');
			document.getElementById("smstartyear").focus();
			return false;
		}

		if(!checkMonthDiff(stime.substring(0, 4),stime.substring(4, 6),etime.substring(0, 4),etime.substring(4, 6))){
			document.getElementById("smstartyear").focus();
			return false;
		}
		
		document.getElementById("smdhcho").value = "M";
	}

	return rtn;
}


//SELF 우측 조회조건 체크
function checkSRData(){
	
	var timeyn  = document.all.stimeonyn.value;
	var dayyn   = document.all.sdayonyn.value;
	var monthyn = document.all.smonthonyn.value;
	var stime	= "";
	var etime	= "";
	
	var rtn    = true;
	//var f 	   = document.searchForm;
	
	//alert('timeyn = ' + timeyn);
	
	if(timeyn == 'Y'){
		if(document.getElementById("shstartdate1").value == ''){
			alert('시작 일시를  입력하세요.');
			document.getElementById("shstartdate1").focus();
			return false;
		}

		if(document.getElementById("shenddate1").value == ''){
			alert('종료 일시를  입력하세요.');
			document.getElementById("shenddate1").focus();
			return false;
		}
		
		stime = document.getElementById("shstartdate1").value+document.getElementById("shstarttime1").value;
		etime = document.getElementById("shenddate1").value+document.getElementById("shendtime1").value;
		
		if(stime > etime){
			alert('시작일시는 종료 일시보다 클 수 없습니다.');
			document.getElementById("shstartdate1").focus();
			return false;
		}

		if(! checkTimeDiff(stime.substring(0, 10),stime.substring(10, 12),etime.substring(0, 10),etime.substring(10, 12)) ){
			document.getElementById("shstartdate1").focus();
			return false;
		}

		document.getElementById("smdhcho").value = "H";
	}

	if(dayyn == 'Y'){
		if(document.getElementById("sdstartdate1").value == ''){
			alert('시작일을  입력하세요.');
			document.getElementById("sdstartdate1").focus();
			return false;
		}

		if(document.getElementById("sdenddate1").value == ''){
			alert('종료일을  입력하세요.');
			document.getElementById("sdenddate1").focus();
			return false;
		}
		
		stime = document.getElementById("sdstartdate1").value;
		etime = document.getElementById("sdenddate1").value;
		
		if(stime > etime){
			alert('시작일자는 종료 일자보다 클 수 없습니다.');
			document.getElementById("sdstartdate1").focus();
			return false;
		}
		
		if(!checkDayDiff(stime,etime)){
			document.getElementById("sdstartdate1").focus();
			return false;
		}
		
		document.getElementById("smdhcho").value = "D";
	}

	
	if(monthyn == 'Y'){
		if(document.getElementById("smstartyear1").value == ''){
			alert('시작년을  입력하세요.');
			document.getElementById("smstartyear1").focus();
			return false;
		}

		if(document.getElementById("smstartmonth1").value == ''){
			alert('시작월을  입력하세요.');
			document.getElementById("smstartmonth1").focus();
			return false;
		}

		if(document.getElementById("smendyear1").value == ''){
			alert('종료년을  입력하세요.');
			document.getElementById("smendyear1").focus();
			return false;
		}

		if(document.getElementById("smendmonth1").value == ''){
			alert('종료월을  입력하세요.');
			document.getElementById("smendmonth1").focus();
			return false;
		}

		stime = document.getElementById("smstartyear1").value+document.getElementById("smstartmonth1").value;
		etime = document.getElementById("smendyear1").value+document.getElementById("smendmonth1").value;
		
		if(stime > etime){
			alert('시작년월은 종료년월보다 클 수 없습니다.');
			document.getElementById("smstartyear1").focus();
			return false;
		}
		
		if(!checkMonthDiff(stime.substring(0, 4),stime.substring(4, 6),etime.substring(0, 4),etime.substring(4, 6))){
			document.getElementById("smstartyear1").focus();
			return false;
		}
		
		document.getElementById("smdhcho").value = "M";
	}

	return rtn;
}

//장치수정 이동
function goDeviceReg(pid,sid){
    document.frm.action = "./setDeviceReg.jsp";
    document.frm.prod_id.value = pid;
    document.frm.service_id.value = sid;
    document.frm.method="post";
    document.frm.submit();
}

//메인화면 이동
function goDashboard(uid,lid){
    document.frm.action = "./dashboard.jsp";
    document.frm.user_id.value = uid;
    document.frm.login_id.value = lid;
    document.frm.method="post";
    document.frm.submit();
}		

//엑셀파일 다운로드
function fncExcel(){
	var frm = document.excelfrm;
	frm.action = "./action/getExcelCCTVDetail_inout.jsp";
	document.getElementById("tiself").value = document.getElementById("timeself").value;
	//alert(document.getElementById("tiself").value );
	frm.method = "post";
	frm.target = "ifr";
	frm.submit();	
	 
}