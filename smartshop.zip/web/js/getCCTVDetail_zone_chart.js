  google.load('visualization', '1', {packages: ['corechart']});

  function drawVisualization(grdata,vAxisTitle,haxistitle,divparam) {
	
	//alert('strdata = ' + $("#strdata").val());
	//alert('1 grdata = ' + grdata);
	//alert('2 grdata = ' + eval("["+grdata+"]"));
	//alert(' vAxisTitle = ' + vAxisTitle);
	
	grdata = eval("["+grdata+"]");
	
    // Create and populate the data table.
	var data = google.visualization.arrayToDataTable(
		grdata		                                                  
    );
    //alert('data = ' + data);
    // Create and draw the visualization.
    new google.visualization.BarChart(document.getElementById(divparam)).
        draw(data,
             {title:"CCTV ZONE 통계 - "+haxistitle,
              width:850, height:530,
              chartArea: {'width': '70%', 'height': '70%'},
              vAxis: {title: vAxisTitle,titleTextStyle:{color: 'black', fontName: '돋움체'}},
              hAxis: {title: "Man",titleTextStyle:{color: 'black', fontName: '돋움체'}}}
        );
    
  }

  function drawVisualizationsLR(grdata,vAxisTitle,haxistitle,divparam) {
		
		//alert('strdata = ' + $("#strdata").val());
		//alert('1 grdata = ' + grdata);
		//alert('2 grdata = ' + eval("["+grdata+"]"));
		//alert(' vAxisTitle = ' + vAxisTitle);
		
		grdata = eval("["+grdata+"]");
		
	    // Create and populate the data table.
		var data = google.visualization.arrayToDataTable(
			grdata		                                                  
	    );
	    //alert('data = ' + data);
	    // Create and draw the visualization.
	    new google.visualization.BarChart(document.getElementById(divparam)).
	        draw(data,
	             {title:"CCTV ZONE 통계 - "+haxistitle,
	              width:420, height:530,
	              chartArea: {'width': '60%', 'height': '60%'},
	              //legend: { position: 'top' } 
	              vAxis: {title: vAxisTitle,titleTextStyle:{color: 'black', fontName: '돋움체'}},
	              hAxis: {title: "Man",titleTextStyle:{color: 'black', fontName: '돋움체'}}}
	        );
	    
	  }

  //google.setOnLoadCallback(drawinit);
