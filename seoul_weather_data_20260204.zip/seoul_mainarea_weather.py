import os, requests, xml.etree.ElementTree as ET, pymysql
from flask import Flask, jsonify, send_from_directory
from dotenv import load_dotenv
from tqdm import tqdm
from concurrent.futures import ThreadPoolExecutor # 멀티스레딩을 위한 모듈

current_dir = os.path.dirname(os.path.abspath(__file__))
app = Flask(__name__, static_folder=os.path.join(current_dir, 'static'))

def MydbConnect(database, port=3306):
    load_dotenv()
    return pymysql.connect(
        host=os.getenv('DB_HOST'),
        port=port,
        user=os.getenv('DB_USER'),
        password=os.getenv('DB_PASSWORD'),
        database=database
    )

def get_citydata(api_key, poi_data):
    # 멀티스레딩을 위해 인자를 튜플로 받음 (areacd, areanm)
    areacd, areanm = poi_data
    url = f"http://openapi.seoul.go.kr:8088/{api_key}/xml/citydata/0/1/{areacd}"
    
    try:
        response = requests.get(url, timeout=5) # 타임아웃 설정 권장
        if response.status_code == 200:
            root = ET.fromstring(response.content)
            lng, lat = None, None
            for prk in root.findall(".//PRK_STTS"):
                if prk.findtext("LNG") and prk.findtext("LAT"):
                    lng, lat = float(prk.findtext("LNG")), float(prk.findtext("LAT"))
                    break
            
            weather_info = {}
            for weather in root.findall(".//WEATHER_STTS"):
                if weather.findtext("WEATHER_TIME"):
                    weather_info = {
                        "time": weather.findtext("WEATHER_TIME"),
                        "temp": weather.findtext("TEMP"),
                        "humidity": weather.findtext("HUMIDITY"),
                        "wind_dirct": weather.findtext("WIND_DIRCT"),
                        "wind_spd": weather.findtext("WIND_SPD"),
                        "pcp_msg": weather.findtext("PCP_MSG"),
                    }
                    break
            
            if lng and lat:
                return {"name": areanm, "lng": lng, "lat": lat, "weather": weather_info}
    except Exception as e:
        print(f"Error fetching {areacd}: {e}")
    
    return None

@app.route("/weather_data.json")
def weather_data():
    conn = MydbConnect("testdb")
    cursor = conn.cursor()
    # 120개 데이터를 모두 가져오도록 변경 (LIMIT 제거 또는 확장)
    cursor.execute("SELECT areacd, areanm FROM arealist;")
    rows = cursor.fetchall()
    conn.close()

    api_key = os.getenv("DATA_API_KEY")
    results = []

    print(f"\n[데이터 수집 시작 - 총 {len(rows)}개 지역]")

    # 멀티스레딩 실행: max_workers는 한 번에 보낼 요청 수 (10~20 적당)
    with ThreadPoolExecutor(max_workers=10) as executor:
        # get_citydata 함수에 (api_key, row) 형태의 인자를 전달
        # list(tqdm(...))을 사용해 진행 상황 표시
        fetch_tasks = [executor.submit(get_citydata, api_key, row) for row in rows]
        
        for future in tqdm(fetch_tasks, desc="멀티스레딩 수집 중"):
            res = future.result()
            if res:
                results.append(res)

    return jsonify(results)

@app.route("/")
@app.route("/seoul_mainarea_weather.html")
def index():
    return send_from_directory(app.static_folder, "seoul_mainarea_weather.html")

# if __name__ == "__main__":
#     app.run(port=8000, debug=True)
if __name__ == "__main__":
    app.run(host="0.0.0.0", port=8000, debug=True)
